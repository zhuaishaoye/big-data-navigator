const { careerArticle, learningArticle } = require("./career-learning-renderers");

const FAMILY_COPY = {
  modeling: {
    section: "模型判断记录",
    evidence: "业务过程、粒度、业务键、历史有效期",
    decision: "先确认一行事实代表什么，再判断字段和表结构是否够用",
    failure: "事实粒度混用",
    actions: ["画业务过程关系", "声明事实粒度", "核对维度历史", "评审模型契约"]
  },
  finance: {
    section: "风险与账务核对底稿",
    evidence: "业务编号、账务日期、风险状态、处置记录",
    decision: "先统一合同、账户、余额与报告时点，再解释指标变化",
    failure: "业务日期与账务日期混用",
    actions: ["核对合同与账户", "对齐时点和范围", "复算风险暴露", "追踪处置证据"]
  },
  manufacturing: {
    section: "现场与批次追溯记录",
    evidence: "设备事件、工单、批次、检验和放行记录",
    decision: "先还原生产时间线和批次关系，再判断效率或质量结论",
    failure: "工单、设备与批次断链",
    actions: ["校准设备时钟", "关联工单批次", "复核质量结果", "追踪放行与返工"]
  },
  retail: {
    section: "用户行为与经营核对",
    evidence: "页面版本、身份、事件、订单和退款",
    decision: "先固定用户、会话、商品和归因窗口，再比较转化与收益",
    failure: "曝光、点击和成交口径不一致",
    actions: ["固定页面与人群", "回查事件链路", "区分自然与策略", "核对退款和利润"]
  },
  healthcare: {
    section: "临床时间线与安全复核",
    evidence: "患者主索引、就诊、医嘱、检验和临床确认",
    decision: "先保证患者身份、临床时序和授权范围，再讨论指标",
    failure: "患者身份或临床时间错配",
    actions: ["核对患者主索引", "重建诊疗时间线", "复核临床状态", "检查隐私审计"]
  },
  education: {
    section: "学习过程与评价记录",
    evidence: "学籍、课程版本、学习事件、作业和评价",
    decision: "先区分学习过程、课程完成与评价结果，再判断教学效果",
    failure: "课程版本与学生身份错配",
    actions: ["确认学籍身份", "绑定课程版本", "校验学习事件", "复核评价口径"]
  },
  logistics: {
    section: "履约节点与异常记录",
    evidence: "订单、运单、包裹、节点和异常原因",
    decision: "先统一对象关系与承诺时间，再拆分履约阶段",
    failure: "订单与运单关系断裂",
    actions: ["核对单号关系", "重建节点时序", "拆分等待与运输", "复盘异常闭环"]
  },
  real_estate: {
    section: "项目、房源与回款台账",
    evidence: "项目、房源、面积、签约、回款和交付",
    decision: "先区分开发、销售、回款与运营阶段，再计算经营指标",
    failure: "面积或销售阶段口径混用",
    actions: ["固定项目房源", "核对面积版本", "区分签约回款", "追踪交付运营"]
  },
  energy: {
    section: "量测、调度与结算核对",
    evidence: "计量点、时区、负荷、电量、交易和结算",
    decision: "先统一计量点、单位与时区，再分析效率、成本和碳数据",
    failure: "计量点或结算周期错配",
    actions: ["核对计量主数据", "校验时序质量", "做电量平衡", "追踪交易结算"]
  },
  agriculture: {
    section: "地块、批次与环境记录",
    evidence: "地块边界、作物、环境、农事、采收和批次",
    decision: "先对齐空间、季节和批次，再判断产量与品质影响",
    failure: "地块面积或传感器缺失口径不清",
    actions: ["核对地块边界", "补齐传感器质量码", "关联农事批次", "复核产量折算"]
  },
  internet_business: {
    section: "平台供需与单元经济",
    evidence: "供给、需求、交易、补贴、收入和留存",
    decision: "先区分自然需求、平台激励和履约成本，再判断增长质量",
    failure: "规模增长掩盖单位亏损",
    actions: ["固定平台边界", "拆分新老供需", "还原补贴去向", "计算净贡献"]
  },
  governance: {
    section: "规则、责任与审计证据",
    evidence: "资产编号、责任人、规则版本、审批和审计日志",
    decision: "先明确责任和适用范围，再判断规则是否真正执行",
    failure: "责任边界与规则版本不清",
    actions: ["登记资产责任", "确认规则版本", "检查执行证据", "闭环审计问题"]
  },
  engineering: {
    section: "链路、版本与故障复盘",
    evidence: "输入分区、任务版本、延迟、质量和回滚记录",
    decision: "先确认输入就绪和数据契约，再讨论容量与性能",
    failure: "上游成功但数据未就绪",
    actions: ["固定输入版本", "验证任务幂等", "定位延迟瓶颈", "演练回滚重放"]
  },
  ai: {
    section: "模型任务与证据评估",
    evidence: "样本来源、提示词、模型、检索、引用和人工复核",
    decision: "先把任务输出写成可检查契约，再判断模型是否可用",
    failure: "离线指标无法代表真实任务",
    actions: ["定义任务边界", "隔离评估样本", "分层评估错误", "保留拒答与回退"]
  },
  analytics: {
    section: "业务问题与证据链",
    evidence: "对象、基线、分母、分组、实验和行动记录",
    decision: "先固定决策问题和比较基线，再解释指标变化",
    failure: "总体平均掩盖分层差异",
    actions: ["写明决策问题", "固定对象口径", "拆解变化来源", "绑定行动复盘"]
  },
  project: {
    section: "目标、里程碑与验收证据",
    evidence: "范围、基线、质量门禁、灰度和采用记录",
    decision: "先说明谁要用结果做什么决定，再确定交付范围",
    failure: "上线被误当成业务验收",
    actions: ["确认目标非目标", "锁定验收样例", "安排灰度回滚", "记录采用与价值"]
  },
  default: {
    section: "业务对象与证据记录",
    evidence: "对象主键、事件时间、状态、指标版本和责任记录",
    decision: "先确认对象、时间和状态，再讨论图表、工具与规模",
    failure: "对象和时点定义不一致",
    actions: ["列对象样本", "统一时间语义", "复算关键指标", "记录行动责任"]
  }
};

function hash(value) {
  let result = 2166136261;
  for (const char of String(value)) {
    result ^= char.codePointAt(0);
    result = Math.imul(result, 16777619);
  }
  return result >>> 0;
}

function pick(items, profile, salt) {
  return items[hash(`${profile.relativePath}:${profile.title}:${salt}`) % items.length];
}

function slug(value) {
  const ascii = String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
  return ascii || `topic_${hash(value).toString(36)}`;
}

function table(headers, rows) {
  const clean = (value) => String(value).replaceAll("|", "\\|").replaceAll("\n", " ");
  return [
    `| ${headers.join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${row.map(clean).join(" | ")} |`)
  ].join("\n");
}

function fence(language, value) {
  return `\`\`\`${language}\n${value.trim()}\n\`\`\``;
}

function list(items) {
  return items.map((item) => `- ${item}`).join("\n");
}

function sourceList(definition, profile) {
  const note = pick([
    "公开资料只用于校准方法和术语。文中的组织名称、系统边界、数据规模和效果均为脱敏复合示例，不对应任何单一企业事实。",
    "下列资料用于解释通用方法，不能替代所在机构的制度、监管口径和当前系统版本。所有场景均经过合并和脱敏处理。",
    "落地前应回到本单位的数据字典、流程图、审批记录和监管要求逐项核对。本文示例不构成生产事实或合规结论。",
    "方法来源与业务现场必须同时核对，尤其是版本、时间、权限和责任边界。案例中的数字只用于说明判断过程。"
  ], profile, "sources-note");
  return `## 公开方法与核对边界

${definition.sources.map(([name, url]) => `- [${name}](${url})`).join("\n")}

${note}`;
}

function abstract(profile, plan, lead) {
  return `# ${profile.title}

> [!abstract] ${plan.definition.label}
> ${lead} ${plan.definition.focus}`;
}

function enterpriseModelingArticle(profile, plan) {
  const d = plan.definition;
  const matrixRows = [
    ["会员注册", "一行一次注册或身份绑定", "客户、日期、渠道、会员等级", "订单、营销、服务"],
    ["订单支付", "一行一个订单商品行的支付分摊", "客户、商品、日期、渠道、活动", "履约、财务、售后"],
    ["库存快照", "一行一个 SKU 在仓库日终的可售状态", "商品、仓库、日期、库存状态", "供应、销售、履约"],
    ["服务工单", "一行一次工单状态变化", "客户、服务类型、日期、责任组织", "质量、客服、产品"],
    ["财务入账", "一行一条会计分录", "会计期间、法人、科目、成本中心", "对账、监管、经营"]
  ];
  const modelYaml = `model_contract:
  domain: customer_transaction
  business_process: order_payment
  grain: one row per order_line_payment_allocation
  business_key: [order_line_id, payment_id]
  event_time: paid_at
  load_time: ingested_at
  dimensions:
    customer: {key: customer_sk, scd_type: 2, effective_columns: [valid_from, valid_to]}
    product: {key: product_sk, scd_type: 2, effective_columns: [valid_from, valid_to]}
    organization: {key: org_sk, scd_type: 2, effective_columns: [valid_from, valid_to]}
  measures:
    paid_amount: {additive: true, currency: CNY}
    allocated_discount: {additive: true, currency: CNY}
  quality_rules:
    - unique: [order_line_id, payment_id]
    - accepted_values: {status: [success, reversed]}
    - expression: paid_amount >= 0
  change_policy:
    compatibility_window_days: 30
    downstream_impact_required: true
    rollback_model_version: required`;
  const grainSql = `WITH fact_candidates AS (
  SELECT
    order_id,
    order_line_id,
    payment_id,
    paid_at,
    paid_amount,
    allocated_discount,
    payment_status
  FROM dwd_order_payment_allocation
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
), grain_check AS (
  SELECT
    order_line_id,
    payment_id,
    COUNT(*) AS row_count,
    SUM(paid_amount) AS paid_amount,
    SUM(allocated_discount) AS allocated_discount
  FROM fact_candidates
  GROUP BY order_line_id, payment_id
)
SELECT *
FROM grain_check
WHERE row_count <> 1
   OR paid_amount < 0
   OR allocated_discount > paid_amount;`;
  return `${abstract(profile, plan, "企业级建模的交付物不是一张大而全的 ER 图，而是一套让业务过程、事实粒度、维度历史、指标语义和变更责任能够跨域复用的共同规则。")}

## 一、企业模型为什么会在跨域分析时失真

部门模型经常在各自系统内“正确”，到了集团口径却对不上。原因通常不是 SQL 写错，而是同一个对象在不同业务过程里承担了不同含义：

${table(
    ["冲突", "现场表现", "建模层根因", "应有决策"],
    [
      ["业务过程混淆", "订单、支付、退款、履约被合成一张宽表", "一行数据同时代表多种事件", "按业务过程拆事实，并用业务键关联"],
      ["事实粒度混用", "订单头优惠复制到每个订单行后金额翻倍", "一行代表的业务含义不唯一", "声明粒度并明确分摊与尾差"],
      ["维度历史被覆盖", "组织调整后过去业绩被重算到新部门", "维度只保存最新状态", "使用 SCD 和业务生效时间"],
      ["业务键不稳定", "源系统换号、合并、拆分后关系断裂", "把源系统编号当企业主键", "企业对象 ID 与源标识分离"],
      ["模型契约缺失", "上游直接删字段，下游看板次日失败", "字段只有类型，没有语义和兼容规则", "契约、版本和影响分析同时发布"]
    ]
  )}

## 二、三层模型：概念、逻辑、物理各管什么

${table(
    ["层次", "要产出什么", "必须回答", "评审不通过的样子"],
    [
      ["概念模型", "业务域、核心对象、业务过程、关键关系", "企业到底在管理哪些对象与事件", "只有系统表名，没有业务对象"],
      ["逻辑模型", "事实粒度、维度、业务键、历史规则、指标语义", "同一业务问题如何稳定表达", "字段齐全，但不知道一行代表什么"],
      ["物理模型", "表、分区、排序、索引、存储、生命周期", "在目标引擎上如何可靠实现", "为了性能牺牲业务含义且无说明"]
    ]
  )}

三层模型之间要有映射。物理表可以重建，业务对象的含义不能随引擎变化；报表可以新增，但不能绕过逻辑模型修改共享口径。

## 三、从业务能力走到事实粒度

企业建模通常从业务能力盘点开始，但不能停在能力清单。要继续追问：哪一次业务事件推动了状态变化，事件产生哪些事实，事实的一行是什么：

${table(
    ["业务过程", "事实粒度", "事实字段", "一致性维度", "禁止混算"],
    matrixRows
  )}

事实粒度必须能被业务人员复述。例如“一行是一笔支付”仍然含糊，需要回答：支付尝试还是支付成功、是否包含退款、金额是订单分摊还是支付流水。只要这些条件不清，后续按渠道、商品或客户汇总都可能重复或遗漏。

## 四、总线矩阵与一致性维度

总线矩阵的用途是显示业务过程与一致性维度的关系，并暴露跨域缺口。它不是一张装饰性表格。矩阵中的每个交叉点都应有责任人、状态和优先级：

${table(
    ["治理对象", "企业级规则", "历史处理", "验收证据"],
    [
      ["客户", "自然人、企业、账户、会员身份分层识别", "合并、拆分、解绑保留有效期", "同一客户跨域可回查，不能只因手机号相同就合并"],
      ["商品", "商品、SKU、组合装和生产批次分层", "类目、规格、上下架按时间版本化", "历史订单不被当前类目覆盖"],
      ["组织", "法人、业务单元、部门、门店分别定义", "组织调整保存生效区间", "业务归属与管理归属可同时解释"],
      ["时间", "发生、生效、入账、可见和计算时间分开", "时区、关账和迟到数据规则明确", "跨期样本能按规则解释"],
      ["渠道", "流量来源、成交渠道和履约渠道分开", "归因窗口与优先级版本化", "多渠道不重复计算"
      ]
  ])}

一致性维度不等于字段名一样，而是定义、主键、粒度和历史归属都能复用。一个“客户 ID”在会员、交易、风控和财务中可能分别代表自然人、账户或合同主体，不能直接 Join。

## 五、代理键、业务键与缓慢变化维

业务键来自业务世界，代理键服务于数据模型。代理键不应承载业务含义，业务键也不能因为源系统变更就消失。推荐保留：

- 企业对象 ID：跨系统稳定，用于维度复用。
- 源系统标识：保留来源系统、源主键和匹配置信度。
- 代理键：事实表关联维度版本时使用。
- 生效与失效时间：表达维度状态从何时开始、何时结束。
- 变更原因和审计标识：支持合并、拆分、纠错和历史追溯。

SCD 类型 2 的核心不只是多两列时间，而是事实在业务发生时应关联当时的维度版本。门店从华东调整到华南后，“按当时组织看历史”和“按当前组织看历史”是两个问题，可以同时提供，但不能悄悄覆盖。

## 六、一份可执行的模型契约

模型契约应同时描述粒度、键、时间、维度、指标、质量规则和变更策略。下面是一份脱敏 YAML 示例：

${fence("yaml", modelYaml)}

契约进入代码仓库后，应随模型发布自动生成版本、血缘和影响清单。删除字段、改变粒度、修改指标分子分母都属于破坏性变更，不能只在群里通知。

## 七、模型质量如何写成 SQL

发布前至少要验证唯一性、粒度、金额平衡和状态合法性。下面是一个脱敏事实表检查：

${fence("sql", grainSql)}

真实项目还要补充分区完整性、维度匹配率、来源与目标行数对账、历史有效期重叠、业务键重复和下游指标回归。质量规则失败时应阻断发布，而不是先上线再观察。

## 八、企业实施路线与评审门

${table(
    ["阶段", "关键动作", "参与角色", "退出条件"],
    [
      ["业务域盘点", "画能力、过程、事件和状态，收集真实单据", "业务专家、数据架构师、一线操作人员", "每个核心过程能指向真实业务问题"],
      ["逻辑模型设计", "声明粒度、业务键、维度历史和指标语义", "模型开发、指标负责人、下游应用", "评审能指出一行数据的边界"],
      ["物理实现", "确定分区、存储、性能和访问策略", "数据开发、平台、安全", "性能与权限测试通过"],
      ["契约与质量", "登记版本、规则、责任人和影响清单", "数据治理、质量、审计", "破坏性变更可阻断"],
      ["灰度发布", "新旧模型并行、样本对账、下游联调", "发布经理、业务、下游团队", "差异有解释且可回滚"],
      ["运营复盘", "观察复用、争议、成本和变更", "数据委员会、领域负责人", "历史问题进入模型规则而非临时补丁"]
    ]
  )}

## 九、五个建模现场

### 现场一：会员历史等级无法还原

某多业态零售集团的会员团队只用最新等级覆盖标签。分析历史复购时，高等级会员看起来一直很高，实际是升级后的状态回写了过去。修复时建立会员等级 SCD，事实按下单时的会员版本关联，并保留升级、降级、合并和注销原因。

### 现场二：保单批改改变了理赔归属

某保险数据团队把当前保单版本直接关联全部赔付。批改后保额和责任范围变化，历史赔付被错误归到新责任。正确方案是识别保单、批单和责任生效事件，赔付按责任发生时点找到有效版本。

### 现场三：采购、入库和发票粒度不同

某制造集团把采购订单行、入库批次和发票行直接连接，金额随一对多关系放大。模型评审决定分别保留三个业务过程，通过订单行和收货关系桥接；无法直接分摊的差异进入对账事实，而不是硬塞进主表。

### 现场四：客户身份合并破坏历史

平台把手机号相同视为同一客户，合并后历史订单全部迁移。家庭成员共用手机号、换号和渠道匿名身份导致误合并。修复后引入企业对象、源标识、匹配置信度和有效期，合并与拆分都可审计。

### 现场五：共享模型字段引发口径争议

业务要求增加“有效订单”字段，但销售、履约和财务对“有效”的定义不同。最终没有增加含糊布尔字段，而是拆分支付、取消、退款和履约状态，由指标语义层组合出场景口径。

## 十、完成企业级建模的验收标准

另一位同事拿到模型后，应能回答：业务过程是什么、事实粒度是什么、业务键如何稳定、维度历史如何关联、指标如何复算、破坏性变更影响谁、失败后如何回滚。不能用“表已经建完”代替这些证据。

${sourceList(d, profile)}`;
}

function financeRiskArticle(profile, plan) {
  const d = plan.definition;
  const riskSql = `WITH exposure_base AS (
  SELECT
    e.report_date,
    e.facility_id,
    e.customer_id,
    e.exposure_type,
    e.on_balance_amount,
    e.off_balance_amount,
    e.guarantee_value,
    e.rating_grade,
    e.pd,
    e.lgd,
    e.limit_amount,
    e.rule_version
  FROM risk_exposure_daily e
  WHERE e.report_date = DATE '2026-09-30'
    AND e.accounting_scope = 'CONSOLIDATED'
), exposure_calc AS (
  SELECT
    *,
    on_balance_amount + off_balance_amount AS gross_exposure,
    GREATEST(on_balance_amount + off_balance_amount - guarantee_value, 0) AS mitigated_exposure,
    (on_balance_amount + off_balance_amount) * pd * lgd AS expected_loss
  FROM exposure_base
)
SELECT
  rating_grade,
  exposure_type,
  SUM(gross_exposure) AS gross_exposure,
  SUM(mitigated_exposure) AS mitigated_exposure,
  SUM(expected_loss) AS expected_loss,
  SUM(CASE WHEN gross_exposure > limit_amount THEN gross_exposure - limit_amount ELSE 0 END) AS excess_amount,
  COUNT(DISTINCT rule_version) AS rule_versions
FROM exposure_calc
GROUP BY rating_grade, exposure_type;`;
  const backtestPy = `from dataclasses import dataclass

@dataclass(frozen=True)
class RatingObservation:
    customer_id: str
    observation_date: str
    rating_grade: str
    pd: float
    default_12m: int

def migrate_grade(current: str, target: str) -> bool:
    order = ["AAA", "AA", "A", "BBB", "BB", "B", "CCC", "D"]
    return order.index(target) > order.index(current)

def migration_summary(rows: list[RatingObservation]) -> dict:
    eligible = [r for r in rows if r.observation_date <= "2025-09-30"]
    if not eligible:
        raise ValueError("没有可用于时点回溯的评级样本")
    observed_defaults = sum(r.default_12m for r in eligible)
    predicted_defaults = sum(r.pd for r in eligible)
    migration_count = sum(
        migrate_grade(r.rating_grade, "D")
        for r in eligible
        if r.default_12m == 1
    )
    return {
        "sample_size": len(eligible),
        "observed_defaults": observed_defaults,
        "predicted_defaults": round(predicted_defaults, 2),
        "downgrade_defaults": migration_count,
        "pd_bias": round((predicted_defaults - observed_defaults) / max(len(eligible), 1), 6),
    }`;
  return `${abstract(profile, plan, "金融风险管理不是把“不良率”换一个图表，而是把风险对象、暴露、违约定义、评级时点、缓释、限额、资本和处置动作放在同一条可回溯证据链上。")}

## 一、风险口径先分成六层

${table(
    ["口径层", "要回答的问题", "常见错误", "可核对证据"],
    [
      ["风险对象", "客户、交易对手、合同、账户还是组合", "客户与借据混算", "对象主键和关系图"],
      ["风险暴露", "表内、表外、本金、利息和市值如何处理", "风险暴露等于会计余额", "余额与表外登记"],
      ["违约定义", "逾期天数、重组、破产或交叉违约如何组合", "只按 90 天逾期判断", "违约定义版本与事件"],
      ["评级时点", "使用了哪个时点可得的信息", "模型使用未来财务数据", "评级日期和数据快照"],
      ["缓释与限额", "担保品、净额结算和限额如何生效", "担保品重复缓释", "逐笔关联和有效期"],
      ["组合与资本", "并表范围、风险加权和压力情景是什么", "不同报告口径混算", "范围版本、RWA 与情景参数"]
    ]
  )}

## 二、信用风险：PD、LGD、EAD 与预期损失

信用风险分析至少需要区分四个概念：

- **PD（违约概率）**：在给定观察期和适用对象下发生违约的概率。
- **LGD（违约损失率）**：违约后考虑回收和缓释后的经济损失比例。
- **EAD（违约风险暴露）**：违约发生时可能存在的敞口，包括已用额度和潜在提款。
- **预期损失**：常用近似为 \`PD × LGD × EAD\`，但必须与内部模型和监管口径核对。

评级模型要严格区分观察点、表现期和数据可得时点。若模型在 2026 年评级时使用 2027 年才披露的财务数据，就是时间穿越。回溯验证应冻结当时的客户、合同、财务和宏观变量版本。

## 三、市场、流动性与操作风险不能共用一张表

${table(
    ["风险类型", "核心对象", "关键度量", "典型现场问题"],
    [
      ["市场风险", "头寸、价格、曲线、风险因子", "VaR、敏感度、久期、止损", "行情快照和估值时点不一致"],
      ["流动性风险", "现金流、资产变现、融资来源", "流动性覆盖率、现金流缺口、集中度", "合同到期日与实际现金流错配"],
      ["操作风险", "事件、损失、控制、责任人", "事件频率、损失金额、控制失效", "同一事件拆成多个工单重复统计"],
      ["信用风险", "客户、合同、暴露、评级", "PD、LGD、EAD、不良、迁徙", "客户和借据口径混用"],
      ["集中度风险", "交易对手、行业、地区、产品", "单一客户、行业和担保品集中度", "集团客户未按关系树合并"]
    ]
  )}

风险数据集市不能只复制业务系统余额。它需要把合同、账户、交易、估值、担保、评级和处置按对象与时间组织起来，并保留“业务发生、风险计量、会计入账、监管报告”四种时间语义。

## 四、限额、预警与处置要形成闭环

限额不是月末跑一张超限名单。它应包含：

1. 限额对象：客户、集团、行业、产品、交易台或组合。
2. 限额类型：金额、比例、敞口、止损、久期、集中度或流动性。
3. 生效区间：审批时间、生效时间、失效时间和临时调整。
4. 监控频率：实时、日终、周度或月度。
5. 处置动作：降额、追加担保、停止新增、对冲、上报或强制平仓。
6. 关闭证据：责任人、处理时间、业务结果和复核结论。

预警模型命中率高并不等于有效。要区分“规则命中”“人工确认风险”“实际损失事件”三层，计算预警准确率、漏报率和处置后改善，而不是只看红色告警数量。

## 五、压力测试与资本口径

压力测试应明确情景、传导链路、时间跨度、静态与动态资产负债表以及管理动作。常见情景包括利率上移、信用利差扩大、房价下跌、失业率上升、流动性收紧和多因素叠加。

风险加权资产（RWA）和资本充足率需要区分监管口径、会计口径和管理口径。并表范围、风险缓释、资产分类和模型参数任一变化，都可能造成指标波动。分析时必须先判断是业务变化、参数变化还是范围变化。

## 六、脱敏 SQL：暴露、预期损失与限额超限

${fence("sql", riskSql)}

这段 SQL 只展示组合核对思路。实际生产还要补充币种折算、表外信用转换系数、净额结算协议、担保品折扣、减值阶段和监管规则版本。

## 七、脱敏 Python：评级回溯验证

${fence("python", backtestPy)}

回溯验证不能只比较预测违约率和实际违约率。还应检查区分能力、评级迁徙、样本稳定性、过度集中、模型偏差和人工覆盖。对低违约组合，单年样本可能不足，需要更长观察期和置信区间。

## 八、五个实际工作现场

### 现场一：市场风险限额突然升高

某银行日终限额占用显著上升。团队先拆成头寸、价格、曲线和限额版本四类影响，发现新增交易只解释一部分，另一部分来自估值曲线切换。处理动作包括冻结新模型版本、并行重估、确认审批记录，再决定是否回溯调整限额。

### 现场二：集团客户授信重复计算

同一集团下多家成员企业在不同分行授信。客户号不同，担保关系也存在交叉。风险团队建立集团关系树、实际控制关系和有效期，先计算集团口径，再保留单一客户口径。两种口径可以并存，但报告必须标明范围。

### 现场三：担保品缓释被重复使用

一笔担保品同时支持多个合同，系统分别按全额扣减暴露。修复时建立担保品分配事实，记录可分配价值、占用金额、优先级和生效期；同一押品不得超过可缓释价值，跨合同分配必须可审计。

### 现场四：操作风险事件被拆成多个工单

一次系统故障引发多笔损失和多个工单。按工单统计会高估事件数、低估单事件影响。数据团队建立风险事件主键，将关联工单、损失、客户影响和修复措施归并，同时保留每个工单的处置时间线。

### 现场五：压力测试结果无法解释

压力情景下资本充足率下降幅度与业务预期不符。复核发现静态资产负债表假设与新增业务计划冲突，汇率和利率情景传导也不同步。最终把情景假设、组合变化、损失传导和管理动作拆开重跑。

## 九、风险模型与报表的运行检查

${table(
    ["检查项", "通过标准", "异常时动作"],
    [
      ["暴露完整性", "表内、表外、应计和缓释前金额可平衡", "停止发布并回溯接口与总账"],
      ["评级时点", "评级数据不晚于观察点", "隔离受影响样本并重跑模型"],
      ["限额版本", "审批、生效和失效时间连续", "恢复上一有效版本并通知业务"],
      ["预警处置", "每条高风险预警有责任人和关闭证据", "升级至风险委员会"],
      ["压力测试", "情景、组合、参数和管理动作可复现", "冻结结论并补充敏感性分析"],
      ["监管报送", "口径、范围、币种和版本一致", "按报送差错流程处理"]
    ]
  )}

${sourceList(d, profile)}`;
}

function webHeatmapArticle(profile, plan) {
  const d = plan.definition;
  const sql = `WITH page_scope AS (
  SELECT
    session_id,
    anonymous_id,
    user_id,
    page_id,
    page_version,
    device_type,
    viewport_width,
    viewport_height,
    client_ts,
    event_name,
    x_ratio,
    y_ratio,
    scroll_depth,
    element_id,
    is_visible
  FROM ods_web_event
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
    AND page_id = 'product_detail'
    AND page_version IN ('v3', 'v4')
), session_scope AS (
  SELECT *,
    ROW_NUMBER() OVER (
      PARTITION BY session_id, page_version, element_id
      ORDER BY client_ts
    ) AS first_click_rank
  FROM page_scope
  WHERE is_visible = 1
)
SELECT
  page_version,
  device_type,
  element_id,
  COUNT(DISTINCT session_id) AS sessions,
  COUNT(DISTINCT CASE WHEN event_name = 'exposure' THEN session_id END) AS exposed_sessions,
  COUNT(DISTINCT CASE WHEN event_name = 'click' AND first_click_rank = 1 THEN session_id END) AS clicked_sessions,
  COUNT(DISTINCT CASE WHEN event_name = 'click' AND first_click_rank = 1 THEN session_id END)
    * 1.0 / NULLIF(COUNT(DISTINCT CASE WHEN event_name = 'exposure' THEN session_id END), 0) AS session_click_rate,
  AVG(CASE WHEN event_name = 'scroll' THEN scroll_depth END) AS avg_scroll_depth
FROM session_scope
GROUP BY page_version, device_type, element_id
HAVING COUNT(DISTINCT session_id) >= 100;`;
  return `${abstract(profile, plan, "页面热力图展示的是曝光、点击和滚动在页面坐标上的分布，不是用户动机本身。只有把页面版本、设备、区域、样本量和业务结果一起核对，热区才有解释价值。")}

## 一、热力图最容易产生哪些“假热点”

${table(
    ["现象", "可能原因", "不能直接得出的结论", "下一步验证"],
    [
      ["首屏很亮", "曝光高、停留自然、视觉焦点强", "用户喜欢或准备购买", "结合滚动、加购、停留和访谈"],
      ["按钮点击异常多", "误触、重复点击、加载无反馈", "按钮吸引力强", "按设备、坐标和点击间隔拆分"],
      ["某区域颜色深", "样本只来自少数会话", "该区域普遍受欢迎", "设置最小会话数并做置信区间"],
      ["移动端热区偏右", "屏幕尺寸、缩放和坐标未归一化", "用户视线偏右", "转换相对页面和相对元素坐标"],
      ["新版旧版差异明显", "页面结构、版本或投放人群变化", "改版一定有效", "检查页面版本、流量分配和实验设计"]
    ]
  )}

## 二、数据模型：曝光、点击、滚动、会话与页面版本

热力图至少需要三类事件：

- **曝光事件**：元素进入可视区域并达到最短时长，表示有机会被看到。
- **点击事件**：记录页面、元素、相对坐标、设备、页面版本和点击时间。
- **滚动事件**：记录最大滚动深度或分段到达，帮助区分首屏热度和后续内容。

页面版本必须进入事件模型。如果 v3 和 v4 的 DOM 结构不同，却共用一个区域编码，颜色会叠加到错误位置。坐标建议同时保留：

1. 相对视口坐标；
2. 相对页面文档坐标；
3. 相对元素内部坐标；
4. 页面滚动偏移和缩放比例；
5. 元素 ID 与内容版本。

## 三、从原始点击到可解释区域指标

${table(
    ["处理步骤", "关键规则", "失败样本", "验收"],
    [
      ["会话边界", "超时、跨端、登录前后如何归并", "同一用户被拆成多个会话", "会话数量和业务访问日志可对账"],
      ["页面版本", "版本 ID 与发布时间绑定", "新旧 DOM 混算", "同一区域坐标误差在阈值内"],
      ["曝光", "可视比例和停留阈值", "一闪而过被计为曝光", "曝光会话不超过访问会话"],
      ["点击去重", "同会话同区域短间隔只保留一次", "加载失败导致连点", "点击率不因连点虚高"],
      ["坐标归一化", "按视口、页面和元素分别转换", "不同屏幕尺寸错位", "桌面与移动端区域可分层比较"],
      ["样本门槛", "每层最少会话数和最小曝光数", "低样本热点被放大", "低样本显示“数据不足”"]
    ]
  )}

## 四、脱敏 SQL：按页面版本和设备比较区域点击

${fence("sql", sql)}

查询结果应同时展示样本量。没有曝光分母的点击次数不能叫点击率；只有页面上文、没有元素曝光的点击坐标也不能直接归到某个按钮。

## 五、怎样解释热力图：四层证据

1. **注意力层**：用户看到了哪里，停留和滚动如何分布。
2. **交互层**：哪些区域被点击、输入、悬停或误触。
3. **任务层**：用户是否找到价格、规格、库存、购买入口或帮助信息。
4. **结果层**：加购、提交、支付、退出和客服问题是否发生变化。

如果首屏主图热区最亮，但滚动到达率低、加购没有变化，只能说明主图获得注意力，不能说明它促成购买。相反，某个帮助入口点击多，可能意味着页面说明不清，而不是功能受欢迎。

## 六、实验和定性研究如何补足因果

热力图适合发现问题，不适合单独证明因果。建议将区域指标与 A/B 测试、可用性访谈、会话回放和业务漏斗结合：

- 热图发现“规格按钮点击多但支付转化低”，再通过访谈确认用户找不到尺码说明。
- 实验只改变按钮位置或文案，保持流量、商品和活动不变。
- 同时观察支付转化、退款率、客服咨询和页面性能，防止单一指标改善带来副作用。
- 对移动端、桌面端、新老用户和不同流量来源分层，避免总体平均掩盖差异。

## 七、四个工作现场

### 现场一：内容电商详情页主图热区很亮

某内容电商详情页优化中，主图区域获得大量曝光和点击。团队没有直接得出“主图最重要”，而是继续查看滚动、加购和退出。结果显示用户点击主要是在切换图片，规格说明仍在首屏以下，真正阻碍购买的是信息顺序。改版把规格摘要上移后，通过实验观察加购和支付。

### 现场二：SaaS 表单移动端点击异常

某 SaaS 表单在桌面端点击集中且转化正常，移动端同一区域点击更多、完成率更低。按设备拆分后发现输入框高度过小，大量点击落在边框附近。修复触控尺寸和键盘类型后，错误点击下降，完成时长缩短。

### 现场三：新旧页面版本被混合统计

某在线教育课程页导航改版后，历史热图突然出现两个相近热点。排查发现页面区域编码未升级，旧版和新版事件落在同一坐标。团队回填页面版本，停止混合展示，并重新采集实验流量。

### 现场四：低曝光区域出现假热点

某本地生活商家页的“立即咨询”区域颜色很亮，但总曝光不足。数据分析师增加最小样本门槛，按设备和新老用户分层后确认只是少数会话反复点击。最终页面将该结论标为“数据不足”，没有据此改版。

## 八、上线前的数据质量清单

${table(
    ["规则", "通过条件", "失败处理"],
    [
      ["页面版本完整", "有效曝光中版本缺失率低于阈值", "暂停热点解读并补版本字段"],
      ["曝光与点击平衡", "点击会话不高于曝光会话", "检查埋点触发顺序和去重"],
      ["坐标合法", "坐标位于页面或元素边界内", "隔离异常设备与缩放比例"],
      ["设备分层", "桌面、平板和手机分别有样本量", "低样本层不展示结论"],
      ["元素映射", "区域 ID 与 DOM 和内容版本一致", "更新区域字典并重算"],
      ["实验隔离", "新旧版本流量和人群可比", "停止因果表述，只保留描述性结论"]
    ]
  )}

${sourceList(d, profile)}`;
}

function analysisHeatmapArticle(profile, plan) {
  const d = plan.definition;
  const sql = `WITH task_session AS (
  SELECT
    session_id,
    user_id,
    page_id,
    page_version,
    device_type,
    task_id,
    MAX(CASE WHEN event_name = 'page_view' THEN 1 ELSE 0 END) AS entered,
    MAX(CASE WHEN event_name = 'click' THEN 1 ELSE 0 END) AS clicked,
    MAX(CASE WHEN event_name = 'form_submit' THEN 1 ELSE 0 END) AS submitted,
    MAX(CASE WHEN event_name = 'task_success' THEN 1 ELSE 0 END) AS succeeded,
    MAX(scroll_depth) AS max_scroll_depth,
    COUNT(CASE WHEN event_name = 'rage_click' THEN 1 END) AS rage_click_cnt,
    MIN(event_time) AS started_at,
    MAX(event_time) AS ended_at
  FROM dwd_user_behavior_event
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
    AND page_id IN ('account_open', 'claim_submit', 'report_export')
  GROUP BY
    session_id, user_id, page_id, page_version,
    device_type, task_id
)
SELECT
  page_id,
  page_version,
  device_type,
  COUNT(*) AS sessions,
  AVG(max_scroll_depth) AS avg_scroll_depth,
  SUM(CASE WHEN max_scroll_depth >= 0.75 THEN 1 ELSE 0 END)
    * 1.0 / NULLIF(COUNT(*), 0) AS deep_scroll_rate,
  SUM(rage_click_cnt) * 1.0 / NULLIF(COUNT(*), 0) AS rage_clicks_per_session,
  SUM(succeeded) * 1.0 / NULLIF(SUM(entered), 0) AS task_success_rate,
  APPROX_PERCENTILE(
    TIMESTAMP_DIFF(ended_at, started_at, SECOND),
    0.95
  ) AS p95_task_seconds
FROM task_session
GROUP BY page_id, page_version, device_type
HAVING COUNT(*) >= 200;`;
  return `${abstract(profile, plan, "分析型热力图不是“哪里颜色深就看哪里”，而是把页面位置与用户任务、滚动深度、重复点击、完成率和停留时长共同解释。它适合提出可用性问题，最终结论仍要回到任务结果和实验证据。")}

## 一、先区分三类热力图问题

${table(
    ["分析问题", "适合看的信号", "容易出现的误判", "补充证据"],
    [
      ["用户有没有看到", "元素曝光率、可见时长、滚动到达", "把页面加载当成曝光", "视口比例与停留阈值"],
      ["用户是否看懂", "重复点击、返回操作、字段报错", "把焦急点击当成偏好", "录屏、访谈和任务完成率"],
      ["用户是否完成任务", "提交率、成功率、处理时长", "只看点击率不看最终结果", "漏斗、错误码和客服工单"],
      ["不同人群是否一致", "设备、新老客、渠道、角色分层", "总体平均值掩盖少数群体", "分层样本量与置信区间"],
      ["改版是否有效", "同期对照、灰度版本、护栏指标", "把季节性变化当成改版收益", "实验设计与上线回滚记录"]
    ]
  )}

## 二、分析粒度：热区必须绑定一个任务

同一坐标在“浏览”和“办理”任务中的含义不同。分析前先登记页面任务卡：

| 卡片字段 | 示例 | 用途 |
| --- | --- | --- |
| 页面与版本 | 开户申请页 v4.2 | 防止 DOM 改版后坐标错位 |
| 用户角色 | 新客、老客、企业经办人 | 区分不同使用熟练度 |
| 任务目标 | 完成资料填写并提交 | 将点击与结果关联 |
| 关键区域 | 身份证上传、协议、下一步 | 建立元素 ID 对照 |
| 失败动作 | 返回、重复点击、校验报错 | 识别困惑和阻塞 |
| 业务护栏 | 提交质量、后续退回率 | 防止只追求页面完成率 |

没有任务信息的“页面热度”只能用于探索。分析师应至少回答：用户在做什么、卡在哪一步、卡住后有没有替代路径。

## 三、从坐标事件到任务诊断

${table(
    ["处理层", "计算方式", "质量门槛", "异常解释"],
    [
      ["元素曝光", "元素可见面积达到 50% 且持续 1 秒", "曝光会话不超过访问会话", "首屏预加载导致虚假曝光"],
      ["有效点击", "同会话同元素 800ms 内只计一次", "点击必须有可见曝光", "加载慢引发连续点击"],
      ["滚动深度", "取会话内最大页面可见比例", "区分文档滚动与局部容器滚动", "弹窗阻断或锚点跳转"],
      ["任务完成", "提交成功且有业务受理编号", "成功事件晚于进入事件", "前端提示成功但后端失败"],
      ["异常信号", "返回、刷新、重复点击、校验错误", "与任务时间窗绑定", "用户主动比较而非受阻"]
    ]
  )}

## 四、分析 SQL：把页面热点和任务结果合并

${fence("sql", sql)}

这张表适合做第一轮分层，不应直接形成改版结论。下一步要按元素 ID 下钻具体区域，并抽取成功与失败会话各 20 条做行为回放。

## 五、三个分析方法

### 方法一：任务漏斗法

把“进入页面 → 首次有效点击 → 关键字段完成 → 提交 → 业务成功”拆成同一批会话。若页面中部很热但提交率不升，热区可能只是帮助信息或误触，并未推动任务。

### 方法二：异常密度法

比较每千次会话的重复点击、返回、字段报错和客服入口点击。异常密度高的区域不一定是“热门功能”，也可能代表用户找不到下一步。重点看异常前后 10 秒内的操作序列。

### 方法三：分层对照法

按新老用户、设备、角色和流量来源分层。总体转化稳定，可能同时存在桌面端提升和移动端下降。只有各层都展示样本量，才能判断改版对谁有效。

## 六、工作现场：开户流程的“假热门”

某互联网券商的开户页面改版后，协议区域点击量最高。业务第一反应是把协议做得更醒目，但分析师把会话分成“首次开户、补资料、重新提交”三组后发现：

- 首次开户用户点击协议多，是为了确认费率；
- 补资料用户点击协议，是因为不知道需要重新确认条款；
- 移动端重复点击集中在勾选框，实际是触控区域偏小。

团队没有只放大协议，而是调整步骤提示、扩大勾选触控区，并让补资料场景直接展示变化条款。实验同时观察提交率、人工退回率和平均处理时长，避免页面点击增加但业务质量下降。

## 七、如何写结论

一份可信的热力图分析应写成：

> 在【时间窗】和【页面版本】内，【分层对象】的【任务指标】相对基线变化【幅度】。【区域】同时出现【热区信号】与【异常信号】，抽检【样本数】后判断最可能的阻塞是【原因】。建议由【责任人】调整【具体元素】，并用【任务完成率】、【错误率】和【处理时长】验证。

结论中要明确“描述性发现”和“因果判断”的边界。没有实验或充分定性证据时，不要写成“因为用户喜欢，所以提升了转化”。

${sourceList(d, profile)}`;
}

function trustBusinessArticle(profile, plan) {
  const d = plan.definition;
  const sql = `WITH project_scope AS (
  SELECT
    t.project_id,
    t.project_code,
    t.contract_id,
    t.trust_account_id,
    t.client_id,
    t.beneficiary_id,
    t.subscription_amount,
    t.received_amount,
    t.valuation_date,
    t.net_asset_value,
    t.distribution_amount,
    t.project_status,
    t.contract_version
  FROM trust_project_snapshot t
  WHERE t.valuation_date = DATE '2026-09-30'
), subscription_recon AS (
  SELECT
    project_id,
    SUM(CASE WHEN flow_type = 'SUBSCRIPTION' THEN amount ELSE 0 END) AS cash_received,
    SUM(CASE WHEN flow_type = 'REFUND' THEN amount ELSE 0 END) AS refunded,
    SUM(CASE WHEN flow_type = 'DISTRIBUTION' THEN amount ELSE 0 END) AS distributed
  FROM trust_cash_flow
  WHERE accounting_date <= DATE '2026-09-30'
  GROUP BY project_id
)
SELECT
  p.project_id,
  p.project_status,
  p.subscription_amount,
  s.cash_received,
  s.refunded,
  p.subscription_amount - (s.cash_received - s.refunded) AS subscription_gap,
  p.net_asset_value,
  p.distribution_amount,
  s.distributed,
  p.contract_version
FROM project_scope p
LEFT JOIN subscription_recon s USING (project_id);`;
  return `${abstract(profile, plan, "信托业务的数据主线不是“产品列表”，而是委托人、受托人、受益人、信托项目、合同、账户、信托财产、估值、分配和信息披露之间的全生命周期关系。")}

## 一、先把信托业务中的主体和财产分开

${table(
    ["对象", "业务含义", "稳定标识", "常见混淆"],
    [
      ["委托人", "设立信托并交付财产的主体", "客户 ID + 适当性档案", "委托人与付款人、受益人不区分"],
      ["受托人", "依法管理和处分信托财产的机构", "机构与责任团队", "把销售渠道当成受托责任主体"],
      ["受益人", "按合同享有受益权的主体", "受益权登记 ID", "只保留姓名或手机号"],
      ["信托项目", "一组信托财产和合同安排", "项目编号", "项目与产品、账户混用"],
      ["信托合同", "约定当事人、财产、分配和费用的法律文件", "合同 ID + 版本", "签章版本与业务版本不一致"],
      ["信托账户", "资金收付、估值和核算的载体", "账户 ID + 币种", "项目账户和客户账户混用"],
      ["信托财产", "受托管理的现金、证券、股权或不动产", "资产 ID + 权属证明", "把管理规模直接当净资产"]
    ]
  )}

## 二、生命周期：从合同成立到终止清算

${table(
    ["阶段", "关键动作", "主要证据", "风险点"],
    [
      ["适当性与反洗钱", "核验客户、资金来源、受益人和授权", "身份资料、风险测评、审批", "受益人与付款关系不清"],
      ["方案与合同", "确认财产范围、期限、费用、分配和退出", "合同版本、法律意见、审批", "合同版本和系统要素不一致"],
      ["成立与募集", "登记项目、认购、到账和成立条件", "认购单、银行流水、成立通知", "在途资金被当作实收"],
      ["投资运作", "划付、交易、持有、估值和风险监控", "指令、成交、持仓、估值表", "估值日和交易时点错配"],
      ["收益分配", "按受益权比例计算并划付", "分配计划、复核、付款回单", "受益权变更后仍用旧比例"],
      ["信息披露", "向授权对象披露净值、报告和重大事项", "披露版本、发送记录", "披露对象或内容越权"],
      ["终止清算", "处置财产、结算费用、分配剩余财产", "清算报告、税务和销户记录", "账户已销但分配未完成"]
    ]
  )}

## 三、认购、实收与项目规模为什么要分开

“成立规模”可能是合同约定或募集目标，“实收信托资金”是实际到账，“项目净资产”是估值后的财产结果。三者不能互相替代。常见核对关系包括：

- 认购金额 - 撤单 - 退款 = 有效认购。
- 有效认购与银行到账逐笔匹配，在途资金单独列示。
- 实收资金进入信托账户后，投资划付、费用和收益继续改变净资产。
- 分配金额以受益权登记、合同比例和可分配收益为基础。

如果只在项目表存一个“规模”字段，后续无法解释募集差异、客户退款、份额变化和分配依据。

## 四、估值、净值与分配的证据链

${table(
    ["指标", "计算基础", "必须固定的口径", "异常检查"],
    [
      ["信托资产总值", "底层资产市值、现金和应收应付", "估值日、价格源、汇率", "资产清单与托管对账"],
      ["信托负债", "费用、税费、应付分配和其他负债", "计提时间和审批", "重复计提、跨期入账"],
      ["信托净资产", "资产总值 - 负债", "估值版本和币种", "净资产不能为负而无说明"],
      ["单位净值", "净资产 / 受益权份额", "份额登记日和精度", "申赎、分配导致份额变化"],
      ["可分配收益", "合同约定与实现/未实现收益规则", "费用、税和亏损弥补顺序", "超额分配、分配对象错误"]
    ]
  )}

估值结果要带估值日、数据截止时间、价格版本、汇率版本和审核状态。分配任务必须读取已批准的估值和受益权版本，不能直接取“最新净值”而不校验生效时间。

## 五、脱敏 SQL：认购、到账、分配三方核对

${fence("sql", sql)}

查询结果中的 \`subscription_gap\` 不能自动解释为欠款，还要区分在途、退款处理中、认购撤销和账务映射错误。生产实现还应加入币种、份额精度、费用和关联交易检查。

## 六、信息披露与隐私控制

信托数据包含高敏感客户、财产和受益关系。权限应按“角色 + 项目 + 用途 + 期限”控制：

1. 财富顾问只能查看本人获授权客户和必要字段。
2. 运营人员按项目处理资金、估值和分配。
3. 合规与审计可查看审批和操作日志，但敏感字段仍按最小化原则展示。
4. 对外披露前经过模板、对象、数据范围和审批校验。
5. 导出、转发、下载和批量查询进入审计日志。

## 七、四个工作现场

### 现场一：受益权变更后分配仍使用旧比例

某家族信托完成受益权变更，但月度分配任务仍读取旧合同版本。排查发现合同、权益登记和分配计划之间没有统一生效时间。修复后分配任务必须读取“分配日有效”的受益权版本，并在运行前检查合同、登记和账户状态。

### 现场二：成立规模与银行流水不一致

某资产服务信托项目成立规模高于实际到账。逐笔核对后区分出在途资金、客户撤单和重复回单。项目状态在募集期内可以保留目标规模，但对外报告应清楚展示有效认购、实收资金和在途金额。

### 现场三：净值波动引发客户质疑

客户认为同一项目净值在短时间内变化过大。运营团队拆分底层资产价格、费用计提和估值版本，发现部分资产价格日期不同。修复后统一估值日和数据截止时间，对无法及时取得的估值标记状态，而不是静默沿用旧价。

### 现场四：多个渠道重复营销同一客户

财富管理团队发现同一客户被不同渠道频繁联系。简单按手机号合并会带来隐私和归属争议，最终采用客户、联系人、渠道关系和授权范围分层模型，营销去重与客户服务互不越权。

## 八、项目验收清单

${table(
    ["验收项", "可检查证据", "不合格表现"],
    [
      ["主体关系", "委托人、受托人、受益人、付款人和授权关系可回查", "只按姓名或手机号识别"],
      ["合同版本", "合同要素、版本、签章和生效时间一致", "系统要素无来源"],
      ["资金对账", "认购、到账、退款、投资划付逐笔平衡", "只对总额"],
      ["估值版本", "估值日、价格源、汇率和审核状态完整", "覆盖历史估值无审计"],
      ["分配准确", "受益权比例、税费和付款回单一致", "分配任务绕过审批"],
      ["信息披露", "对象、模板、数据范围和发送记录可追溯", "超出授权披露"],
      ["终止清算", "资产处置、债务、税费和剩余分配闭环", "销户但分配未完成"]
    ]
  )}

${sourceList(d, profile)}`;
}

function icuArticle(profile, plan) {
  const d = plan.definition;
  const sql = `WITH icu_stay AS (
  SELECT
    s.icu_stay_id,
    s.patient_id,
    s.encounter_id,
    s.department_code,
    s.bed_id,
    s.intime,
    s.outtime,
    s.admission_source,
    s.discharge_disposition,
    s.ventilator_flag,
    s.stay_version
  FROM clinical_icu_stay s
  WHERE s.intime >= TIMESTAMP '2026-10-01 00:00:00'
    AND s.intime <  TIMESTAMP '2026-11-01 00:00:00'
), vital_window AS (
  SELECT
    icu_stay_id,
    MIN(CASE WHEN vital_code = 'MAP' THEN value_num END) AS min_map,
    MAX(CASE WHEN vital_code = 'TEMP' THEN value_num END) AS max_temp,
    MIN(CASE WHEN vital_code = 'SPO2' THEN value_num END) AS min_spo2,
    COUNT(DISTINCT vital_code) AS vital_types
  FROM clinical_vital_sign
  WHERE recorded_at >= TIMESTAMP '2026-10-01 00:00:00'
  GROUP BY icu_stay_id
)
SELECT
  s.department_code,
  COUNT(DISTINCT s.icu_stay_id) AS icu_stays,
  COUNT(DISTINCT s.patient_id) AS patients,
  AVG(EXTRACT(EPOCH FROM (s.outtime - s.intime)) / 3600.0) AS avg_icu_hours,
  SUM(CASE WHEN s.ventilator_flag = 1 THEN 1 ELSE 0 END) AS ventilated_stays,
  SUM(CASE WHEN v.min_spo2 < 90 OR v.min_map < 65 THEN 1 ELSE 0 END) AS physiologic_alert_stays,
  COUNT(DISTINCT s.stay_version) AS stay_versions
FROM icu_stay s
LEFT JOIN vital_window v USING (icu_stay_id)
GROUP BY s.department_code;`;
  return `${abstract(profile, plan, "ICU 数据平台的价值不是多做大屏，而是让患者身份、重症就诊、生命体征、医嘱、检验、感染、转出和临床复核形成连续时间线，同时守住隐私和患者安全边界。")}

## 一、ICU 数据的第一原则：患者安全高于指标完整性

重症数据具有高频、强时序、多设备和高风险特征。任何自动指标都不能绕过临床确认。数据团队首先要明确：

- 这是患者身份问题、临床状态问题、设备采集问题，还是计费编码问题。
- 异常是真实病情变化、治疗方案变化，还是记录延迟和单位错误。
- 哪个角色有权确认、处置和关闭告警。
- 数据缺失时系统应显示“未知”，不能用零值或正常值填补。

## 二、患者、就诊与 ICU stay 要分层

${table(
    ["对象", "含义", "主键", "常见错误"],
    [
      ["患者", "跨院区、跨时间的自然人主索引", "patient_id / EMPI", "同名或同手机号直接合并"],
      ["就诊", "一次门诊、急诊或住院服务", "encounter_id", "把多次住院合成一次"],
      ["ICU stay", "患者在 ICU 的一次连续停留", "icu_stay_id", "转床或短暂离科被拆成多次 ICU"],
      ["床位", "空间资源，不等于患者", "bed_id + 时间", "床位号变化被当成患者变化"],
      ["医嘱", "开立、审核、执行和停止的事件链", "order_id + version", "开立即视为已执行"],
      ["检验", "样本、结果、单位和参考区间", "specimen_id + result_id", "单位不统一直接比较"],
      ["院感事件", "监测定义下的感染事件", "infection_event_id", "把阳性检验结果直接等同院感"]
    ]
  )}

## 三、生命体征的时序与质量

生命体征来自监护仪、护理记录和人工补录，时间频率和单位可能不同。建模时要保留：

1. 采集时间、设备时间、入库时间和临床确认时间。
2. 指标编码、单位、数值、文本值和质量码。
3. 设备来源、患者关联和采集频率。
4. 缺失、伪差、断开、校准和人工修正标记。

平均动脉压、血氧、体温和心率不能用简单日汇总代替临床过程。评估时应使用时间窗、最低值、持续时间和处理后的趋势，并明确窗口长度。

## 四、医嘱、检验和执行的闭环

${table(
    ["环节", "数据证据", "判断问题", "停止或升级条件"],
    [
      ["医嘱开立", "医生、时间、剂量、频次和状态", "是否针对正确患者", "患者或药物不匹配立即停止"],
      ["药师审核", "审核结果、意见和修改", "是否存在禁忌或相互作用", "高风险组合转人工"],
      ["护理执行", "执行时间、剂量、途径和签名", "是否按医嘱执行", "漏执行或超剂量升级"],
      ["检验结果", "样本、结果、单位和危急值", "是否达到临床阈值", "危急值按制度通知"],
      ["临床复核", "确认人、结论和后续动作", "自动规则是否适用", "不确定结果不得自动关闭"]
    ]
  )}

自动预警的作用是帮助发现，不是替代医生。错误患者、危急值、药物过敏和生命支持设备等高危信息必须经过双人核对或明确的人工确认路径。

## 五、脱敏 SQL：ICU stay 与生命体征窗口

${fence("sql", sql)}

这个查询只做质量分析，不能直接用于临床决策。真实系统需要结合诊断、治疗、设备状态和临床确认，并对每个指标设置本地验证过的阈值。

## 六、院感、转出与质量指标

院感事件要基于监测定义，通常需要综合检验、培养、影像、抗菌药物和临床判断。单独的阳性结果不能直接判定感染。

转出分析要区分：

- ICU 转普通病房；
- 转其他医院；
- 医嘱离院；
- 死亡；
- 自动出院或其他状态。

这些状态不能合并为“转出率”。平均 ICU 时长也应处理仍在院、转科、死亡和超长停留样本，否则分母会产生偏差。

## 七、隐私、权限与审计

${table(
    ["控制", "要求", "证据"],
    [
      ["最小权限", "按科室、角色、患者关系和用途授权", "权限矩阵与审批"],
      ["访问目的", "急诊、诊疗、质控、科研分别登记", "访问日志与用途码"],
      ["去标识化", "科研和统计按规则脱敏", "映射表隔离与审批"],
      ["导出控制", "批量导出、截图和下载受控", "导出审计与水印"],
      ["数据保留", "按制度和诉讼保全要求管理", "生命周期规则"],
      ["异常访问", "监测非工作时段、超范围和高频查询", "告警与处置记录"]
    ]
  )}

## 八、四个临床数据现场

### 现场一：同一患者多次 ICU 停留被合并

某多院区数据平台按住院号汇总 ICU 时长，患者转出后再次入科被算成一次连续停留。修复后使用 ICU stay 主键，保留每次入科、出科、转床和转出原因，患者级指标再按规则聚合。

### 现场二：监护仪断线被当成生命体征正常

某质量报表在设备断线期间没有记录，却被后续脚本填补为正常值。临床复核发现异常被掩盖。修复后增加设备连接状态和质量码，缺失值保持未知，并对长时间断线发出数据质量告警。

### 现场三：医嘱开立与执行状态混淆

某分析把医嘱开立数量计为实际治疗量，导致药物使用被高估。重建链路后区分开立、审核、执行、暂停和取消，护理执行时间成为治疗事件的依据。

### 现场四：院感阳性结果被直接计入事件

检验阳性触发大量“院感”标记，但多数没有临床诊断和监测定义。感染管理团队把检验、培养、影像、用药和病例复核结合，保留规则版本与人工判定，避免错误对外报告。

## 九、ICU 数据平台的验收条件

${table(
    ["验收项", "通过标准", "失败表现"],
    [
      ["患者主索引", "跨院区身份置信度和人工合并可追溯", "同名即合并"],
      ["临床时序", "入科、医嘱、执行、检验和转出顺序合理", "未来时间或倒序事件"],
      ["设备质量", "断线、伪差和校准状态可见", "缺失当正常"],
      ["高危告警", "通知、确认和处置闭环", "只发消息无人负责"],
      ["隐私审计", "谁在何时为何访问可追踪", "批量导出无记录"],
      ["指标解释", "分母、排除项和临床确认清楚", "自动结果替代诊断"]
    ]
  )}

${sourceList(d, profile)}`;
}

function sixSigmaArticle(profile, plan) {
  const d = plan.definition;
  const sql = `WITH measurement_system AS (
  SELECT
    part_id,
    operator_id,
    trial_no,
    measured_value,
    reference_value,
    measurement_date
  FROM qms_msa_study
  WHERE measurement_date BETWEEN DATE '2026-09-01' AND DATE '2026-09-30'
), part_summary AS (
  SELECT
    part_id,
    AVG(measured_value) AS avg_measured,
    MAX(measured_value) - MIN(measured_value) AS repeatability_range,
    MAX(reference_value) AS reference_value
  FROM measurement_system
  GROUP BY part_id
)
SELECT
  COUNT(*) AS parts,
  AVG(ABS(avg_measured - reference_value)) AS mean_bias,
  AVG(repeatability_range) AS average_range,
  STDDEV_SAMP(avg_measured - reference_value) AS reproducibility_sd
FROM part_summary;`;
  const python = `from statistics import mean, pstdev

def capability_summary(values: list[float], lsl: float, usl: float) -> dict:
    if len(values) < 30:
        raise ValueError("能力分析至少需要稳定的过程样本")
    center = mean(values)
    sigma = pstdev(values)
    if sigma == 0:
        raise ValueError("标准差为零，检查测量分辨率")
    return {
        "mean": round(center, 4),
        "sigma_within": round(sigma, 4),
        "cp": round((usl - lsl) / (6 * sigma), 3),
        "cpk": round(min(usl - center, center - lsl) / (3 * sigma), 3),
        "out_of_spec_rate": round(
            sum(v < lsl or v > usl for v in values) / len(values), 4
        ),
    }`;
  return `${abstract(profile, plan, "六西格玛是一套用数据和统计方法减少波动、提升过程能力的管理方法。它的核心不是背 DMAIC 五个字母，而是把客户要求、测量系统、过程稳定性、根因验证和改善效果连成证据链。")}

## 一、六西格玛与“拍脑袋优化”的区别

${table(
    ["判断", "普通改善", "六西格玛改善"],
    [
      ["问题定义", "良率低，需要提升", "明确缺陷、客户要求、范围、基线和目标"],
      ["测量", "直接使用现有报表", "先做操作定义、MSA 和数据完整性检查"],
      ["分析", "凭经验选原因", "用分层、图分析和假设检验验证"],
      ["改善", "同时改很多参数", "控制变量，通过 DOE 或试验确认"],
      ["控制", "上线后靠人盯", "控制图、反应计划、责任和再验证"],
      ["收益", "只说效果显著", "基线与改善后同口径比较，含副作用"]
    ]
  )}

## 二、DMAIC 每一步的交付物

${table(
    ["阶段", "核心问题", "关键工具", "退出证据"],
    [
      ["Define 定义", "什么问题、对谁重要、边界是什么", "SIPOC、VOC、项目章程", "缺陷定义、基线、目标、团队"],
      ["Measure 测量", "当前表现如何，测量可信吗", "流程图、MSA、能力分析", "数据采集计划与测量系统合格"],
      ["Analyze 分析", "哪些少数原因真正影响结果", "分层、假设检验、回归、FMEA", "根因证据与候选关系"],
      ["Improve 改善", "哪个方案在约束下最有效", "DOE、试点、方案评估", "验证后的参数、流程和风险控制"],
      ["Control 控制", "如何保持并发现回退", "控制图、SOP、防错、审计", "控制计划、反应计划和责任人"]
    ]
  )}

## 三、MSA：先证明测量系统可用

测量系统分析通常关注重复性、再现性、偏倚、线性和稳定性。若量具分辨率不足或不同操作员测量差异很大，后面的 Cp/Cpk 再漂亮也可能只是噪声。

${table(
    ["项目", "要回答什么", "常见失败"],
    [
      ["重复性", "同一人同一量具反复测量是否一致", "量具分辨率太低"],
      ["再现性", "不同操作员或设备之间是否一致", "培训和装夹方式不同"],
      ["偏倚", "平均值与参考值的系统差异", "校准或零点错误"],
      ["线性", "不同量程内偏倚是否稳定", "只用中间量程验证"],
      ["稳定性", "测量系统随时间是否漂移", "长期未做标准件复核"]
    ]
  )}

## 四、SPC 与过程能力

控制图先判断过程是否稳定，再计算能力。过程不稳定时直接算 Cp/Cpk 容易把特殊原因混入普通波动。

- \`Cp\` 反映规格宽度与过程波动的关系。
- \`Cpk\` 同时考虑过程中心和规格上下限距离。
- \`Ppk\` 常基于总体波动，解释时需与采样和稳定状态一致。
- 规格限来自客户或工程要求，不能为了结果好看随意修改。

## 五、DOE：用最少试验识别关键因子

DOE 适用于多个因子同时影响结果、且交互作用可能存在的场景。实施顺序通常是：

1. 明确响应变量和测量误差。
2. 选择温度、压力、速度、材料等可控因子及水平。
3. 通过筛选试验识别主要因子。
4. 用响应面或优化设计寻找最佳区域。
5. 做验证运行，确认预测与实测一致。
6. 把有效参数纳入控制计划和变更管理。

## 六、脱敏 SQL：MSA 数据检查

${fence("sql", sql)}

## 七、脱敏 Python：计算 Cp/Cpk 与超规格率

${fence("python", python)}

代码只展示基础计算。真实分析还应确认过程稳定、分布假设、样本独立性、量具误差和规格来源。

## 八、五个实际现场

### 现场一：良率改善项目先被 MSA 拦住

某精密加工团队准备调整切削参数，MSA 显示同一样件重复测量波动接近规格宽度的三分之一。团队先修复量具分辨率和装夹方式，再重新采集数据，避免把测量噪声当成工艺改善。

### 现场二：控制图发现特殊原因

某注塑过程平均值长期稳定，但连续点出现趋势。进一步检查发现原料批次变化与烘干时间调整同时发生。团队没有直接重算控制限，而是隔离批次并验证烘干参数。

### 现场三：Cpk 高但客户仍投诉

某电子组件 Cpk 看似合格，客户投诉却上升。复核发现只控制了出货尺寸，没有覆盖批次均匀性和长期漂移，规格也并非客户真实功能要求。团队重新定义关键特性并增加可靠性验证。

### 现场四：DOE 找到交互作用

某涂装工艺单独优化温度和速度都有效，组合后却出现缺陷。通过 2×2 试验发现交互作用显著，最终选择更稳健的参数窗口，而不是只取单因子最优值。

### 现场五：改善后三个月回退

项目上线后指标改善，但三个月后回退。控制阶段没有明确标准件复核、参数权限和异常反应计划。修复后将关键参数锁定、变更审批和控制图反应写入班组 SOP。

## 九、项目验收与常见误区

${table(
    ["误区", "为什么危险", "正确做法"],
    [
      ["只做工具培训", "没有业务问题和项目收益", "以真实缺陷和客户要求立项"],
      ["跳过 MSA", "测量误差污染分析", "先证明测量系统适合任务"],
      ["过程不稳定仍算能力", "Cp/Cpk 无解释基础", "先消除特殊原因"],
      ["一次改多个参数", "无法区分有效因子", "设计试验并控制变量"],
      ["只报平均改善", "波动、边界和副作用被忽略", "同时看分布、能力、成本和风险"],
      ["控制阶段无责任人", "改善很快回退", "控制计划、反应计划和审计"]
    ]
  )}

${sourceList(d, profile)}`;
}

function evSupplyChainArticle(profile, plan) {
  const d = plan.definition;
  const sql = `WITH cell_batch AS (
  SELECT
    c.cell_batch_id,
    c.supplier_id,
    c.cell_model,
    c.production_date,
    c.capacity_ah,
    c.internal_resistance_mohm,
    c.incoming_inspection_result,
    c.inspection_rule_version
  FROM supply_cell_batch c
  WHERE c.production_date BETWEEN DATE '2026-07-01' AND DATE '2026-09-30'
), module_pack AS (
  SELECT
    m.module_id,
    m.pack_id,
    m.vehicle_vin,
    b.cell_batch_id,
    b.supplier_id,
    b.cell_model,
    m.assembly_time,
    m.end_of_line_result
  FROM manufacturing_module m
  JOIN manufacturing_cell_binding b USING (module_id)
), traceability AS (
  SELECT
    p.vehicle_vin,
    p.pack_id,
    p.module_id,
    p.cell_batch_id,
    p.supplier_id,
    p.cell_model,
    p.end_of_line_result,
    COUNT(DISTINCT p.cell_batch_id) OVER (PARTITION BY p.pack_id) AS batches_per_pack
  FROM module_pack p
)
SELECT
  supplier_id,
  cell_model,
  COUNT(DISTINCT vehicle_vin) AS affected_vehicles,
  COUNT(DISTINCT pack_id) AS affected_packs,
  SUM(CASE WHEN end_of_line_result = 'FAIL' THEN 1 ELSE 0 END) AS failed_modules,
  MAX(batches_per_pack) AS max_batches_per_pack
FROM traceability
GROUP BY supplier_id, cell_model;`;
  return `${abstract(profile, plan, "电动汽车供应链的数据核心是“物料—电芯批次—模组—Pack—整车 VIN—交付与售后”的追溯链。它同时连接供应商质量、生产参数、整车状态和召回处置，不能用普通采购库存表代替。")}

## 一、EV 供应链的对象层级

${table(
    ["层级", "对象", "关键标识", "主要数据"],
    [
      ["物料", "正负极、隔膜、电解液、结构件", "material_id + lot", "供应商、批次、检验、有效期"],
      ["电芯", "Cell", "cell_id + cell_batch_id", "容量、内阻、自放电、工艺和检测"],
      ["模组", "Module", "module_id", "电芯绑定、焊接、装配和测试"],
      ["电池包", "Pack", "pack_id", "模组关系、BMS、气密、绝缘和EOL"],
      ["整车", "Vehicle", "VIN", "车型、配置、装配、交付和售后"],
      ["供应商", "Supplier", "supplier_id + site", "准入、批次质量、交付和变更"],
      ["遥测事件", "Telemetry", "event_id + VIN", "电压、温度、SOC、告警和维修"]
    ]
  )}

## 二、BOM 不是实时装配关系的替代品

工程 BOM 描述允许使用什么，实际装配关系描述某辆车用了哪一批物料。二者必须分开：

- 工程 BOM 带版本和生效时间；
- 采购订单和到货批次记录供应来源；
- MES 绑定记录实际电芯、模组和 Pack；
- 整车 VIN 关联生产、交付和售后；
- 替代料和返修必须保留变更审批。

只有 BOM 没有装配记录，召回时无法定位受影响车辆；只有装配记录没有工程版本，又无法判断设计变更范围。

## 三、供应商质量与来料批次

${table(
    ["指标", "计算基础", "必要分层", "常见误读"],
    [
      ["来料批次合格率", "合格批次 / 检验批次", "供应商、工厂、物料、批次", "忽略免检和抽样方案"],
      ["PPM", "不合格件数 / 百万件", "缺陷类型和时间窗", "只看总数不看严重度"],
      ["供应商交付及时率", "按承诺到达的订单行比例", "物料、运输方式和紧急插单", "提前到货掩盖库存风险"],
      ["批次一致性", "关键参数分布随批次变化", "设备、工艺和原材料", "用平均值隐藏双峰"],
      ["售后失效率", "失效车辆 / 同批次已交付车辆", "里程、气候和使用年限", "未考虑观察期差异"]
    ]
  )}

## 四、电芯批次如何追溯到整车

一条可用的追溯链应能回答：

1. 某电芯批次进入了哪些模组和 Pack？
2. 这些 Pack 装到哪些 VIN？
3. 车辆何时生产、交付、维修和更换电池？
4. 同批电芯的工艺参数、来料检验和供应商变更是什么？
5. 售后告警是否支持批次风险，而不是单辆车偶发故障？

追溯表必须有有效期和拆换记录。电池包在售后被更换后，原车与当前 Pack 的关系不能覆盖历史，否则无法区分原装故障和更换件故障。

## 五、脱敏 SQL：批次到整车的影响范围

${fence("sql", sql)}

真实查询还要处理模组返修、电芯替换、Pack 换装、VIN 变更、出口市场和试验车。结果只能形成召回候选范围，是否召回仍需质量、工程、法规和售后共同判断。

## 六、车载遥测与安全边界

遥测指标可包括单体电压差、温度、SOC、SOH、绝缘、故障码和充电行为。分析时应区分：

- 传感器采集异常；
- 通信延迟和丢包；
- 真实热失控前兆；
- 环境温度、驾驶和充电条件；
- 软件版本与 BMS 策略变化。

任何与安全相关的自动告警都要有阈值来源、临床/工程确认和升级机制。数据平台不能直接向车辆下发控制指令。

## 七、四个实际工作现场

### 现场一：同一电芯批次跨多个 Pack

供应商批次异常后，质量团队需要定位车辆。系统只有采购批次和整车 VIN，没有 MES 绑定，最终靠纸质记录人工追查。修复后建立电芯、模组、Pack 和 VIN 的实际装配关系，并把替代料与返修纳入链条。

### 现场二：来料合格但售后失效上升

某批电芯来料检验合格，售后故障却增加。分析发现抽样只覆盖出厂容量，没有覆盖高温循环和内阻分布。团队补充可靠性测试，并用车辆遥测验证批次风险。

### 现场三：售后换电覆盖原始关系

车辆更换电池包后，系统直接用新 Pack 覆盖原 Pack，导致历史故障追溯丢失。修复后保留安装、拆卸、维修和质保关系及其有效期。

### 现场四：供应商交付及时率看似改善

供应商通过提前发货提升及时率，但工厂仓库存和物料有效期风险上升。团队将交付、库存、批次周转和来料质量放在同一指标组中，避免局部优化转移成本。

## 八、验收清单

${table(
    ["验收项", "通过标准", "失败表现"],
    [
      ["BOM 版本", "设计变更与生效时间可追溯", "用最新 BOM 回写历史车型"],
      ["实际装配", "电芯到 VIN 全链路可回查", "只有理论BOM"],
      ["售后拆换", "安装与拆卸历史保留", "新件覆盖旧件"],
      ["供应商批次", "供应商、工厂、物料和批次贯通", "只保留供应商名称"],
      ["遥测质量", "缺失、延迟和设备异常可见", "断网当健康"],
      ["召回候选", "影响范围、证据和人工确认完整", "模型直接决定召回"]
    ]
  )}

${sourceList(d, profile)}`;
}

function resumeArticle(profile, plan) {
  const d = plan.definition;
  const topic = profile.topic;
  const named = /模板-([\u4e00-\u9fa5]{2,4})$/u.exec(topic)?.[1] || "";
  const roleSpecs = [
    {
      key: "prompt",
      match: /AI简历生成Prompt/,
      label: "AI 简历生成提示词",
      summary: "这是一份业务简历提示词设计指南。目标不是让模型写得更华丽，而是让它在事实边界内完成岗位拆解、证据筛选、弱项诊断和针对性改写。",
      signals: ["目标岗位与职级", "招聘方前三个硬性要求", "可验证项目与个人边界", "不可公开的数据与信息", "输出长度和格式"],
      evidence: ["原始事实卡", "岗位要求矩阵", "项目证据表", "禁用信息清单", "人工复核记录"],
      projects: [
        ["先建立事实卡", "逐条记录项目背景、个人动作、技术约束、结果和失败复盘，不允许模型自行补数字。"],
        ["再做岗位对齐", "把 JD 拆成业务、数据、工程、协作和行业五类要求，逐项标记强证据、弱证据和缺口。"],
        ["最后控制输出", "规定一页/两页、项目排序、动词强度、禁用词和必须保留的口径边界。"]
      ],
      rewrites: [
        ["精通 SQL、Python 和 AI", "技能词没有任务和证据", "按任务写：用 SQL 完成渠道归因核对，用 Python 构建异常检测，用 AI 辅助初筛并人工复核"],
        ["负责数据平台建设", "无法判断个人边界", "负责实时链路中的 Kafka 积压监控与回放校验，定义 Lag、分区和幂等验收指标"],
        ["提升业务效率", "没有采用者和基线", "将 6 张月末手工对账表改为参数化任务，财务复核步骤从 5 步降至 2 步，异常仍需人工确认"]
      ],
      questions: [
        ["你的 Prompt 如何防止编造项目结果", "需要说明事实卡、不可改写字段、缺失值处理和第二轮事实核验"],
        ["不同岗位为什么使用不同结构", "岗位证据权重不同，分析、工程、产品和治理不能共用同一项目顺序"],
        ["如何评估简历提示词", "看事实保真、岗位命中、信息密度、可读性和面试追问准备度，不只看文字是否漂亮"]
      ]
    },
    {
      key: "ai-project",
      match: /如何把AI项目写进简历/,
      label: "AI 项目经历",
      summary: "AI 项目写进简历的关键，是把“用了什么模型”改成“什么任务、什么数据、怎样评测、哪些地方仍需人工、最终谁采用”。",
      signals: ["任务类型与用户", "数据来源和授权", "基线方案", "离线/在线评估", "风险、成本、延迟和采用"],
      evidence: ["任务定义", "评测集版本", "失败样本", "人工复核记录", "上线与回退记录"],
      projects: [
        ["RAG 知识库", "突出文档治理、召回、重排、引用支持、拒答和越权过滤，不写“接入大模型后准确率提升”。"],
        ["Text-to-SQL", "突出业务语义层、字段权限、SQL 校验、执行成本、结果对账和转人工规则。"],
        ["Agent 工作流", "突出工具白名单、最大步数、参数校验、审批、幂等、审计和失败恢复。"]
      ],
      rewrites: [
        ["参与企业大模型项目", "只说明参与，没有职责", "负责制度知识库的检索评估：构建 180 条问题集，按部门与文档版本过滤，记录 Recall@3、引用支持和拒答错误"],
        ["使用 RAG 提升回答准确率", "结果不可核验", "将旧制度冲突、无答案和越权访问拆为独立评测切片，上线门禁要求引用可定位且越权命中为零"],
        ["开发智能分析助手", "没有边界", "助手仅使用只读指标和事件查询工具，查询前校验权限与扫描量，超过预算或证据不足时停止并转人工"]
      ],
      questions: [
        ["你亲自负责哪一段", "应能分开说明数据、检索、模型、评估、平台和业务采用，不把团队成果全部写成个人成果"],
        ["如何证明不是演示", "准备固定评测集、失败分类、灰度用户、采用率、人工修订和回退记录"],
        ["AI 项目的业务价值是什么", "优先写决策或流程改变，例如减少查找时间、减少错误引用或提前阻断风险，不只写调用量"]
      ]
    },
    {
      key: "rewrite",
      match: /简历重写方法/,
      label: "数据简历重写",
      summary: "简历重写不是换更高级的形容词，而是重新选择与目标岗位最相关的证据，并把团队成果、个人动作、结果边界和失败复盘写清。",
      signals: ["岗位核心任务", "候选人的最强证据", "不匹配但可迁移的能力", "事实缺口", "投递版本"],
      evidence: ["原简历", "岗位要求", "项目原始记录", "数字口径", "面试追问清单"],
      projects: [
        ["删减", "先删除无法解释的数字、过期工具和与岗位无关的课程，再控制每项 1 至 3 行。"],
        ["重排", "把最接近目标岗位的项目放前面；治理岗位先标准与闭环，开发岗位先链路与故障，分析岗位先决策与行动。"],
        ["补证", "为每条保留要点准备对象、动作、口径、结果和边界五项证据，无法回答的内容缩小或删除。"]
      ],
      rewrites: [
        ["工作认真，学习能力强", "不可验证", "在两个月内补齐流批链路知识，独立完成 Kafka 积压演练并从分区 Lag 定位到下游写入瓶颈"],
        ["搭建数据指标体系", "缺对象与采用", "为会员运营定义首购、复购、退款和渠道归因口径，发布口径卡并让 3 个团队切换同一指标版本"],
        ["熟练使用 AI 工具", "无法判断能力", "用 AI 辅助生成数据字典初稿，建立人工抽检与错误登记，将字段解释缺失项从 320 个降至 90 个"]
      ],
      questions: [
        ["为什么删掉某段经历", "要能说明岗位相关性、证据强度和页面信息密度，不能因为不会回答而删除"],
        ["结果数字如何得到", "准备基线、周期、样本、计算方式、个人贡献和不可比因素"],
        ["你与其他候选人差异在哪里", "用两到三个可复核的项目证据回答，而不是性格形容词"]
      ]
    },
    {
      key: "scientist",
      match: /数据科学家|Data Scientist/,
      label: "数据科学家",
      summary: "数据科学家简历要证明完整的问题定义、数据因果、建模评估和业务决策能力；算法名称只是证据的一部分。",
      signals: ["业务问题与决策", "标签和样本", "统计/实验/建模", "离线与线上评估", "部署、监控和业务采用"],
      evidence: ["问题定义", "数据切分", "基线与模型比较", "分层误差", "上线收益和风险"],
      projects: [
        ["用户流失预测", "写清标签窗口、观察期、特征可得时间、类别不平衡、基线模型、阈值选择和干预策略。"],
        ["实验与因果评估", "写清随机化单位、样本量、污染、主指标、护栏和停止规则，不把相关性写成因果。"],
        ["推荐或排序模型", "写清候选、特征、离线指标、线上 A/B、冷启动、多样性和长期体验。"]
      ],
      rewrites: [
        ["使用 XGBoost 提升预测准确率", "缺少任务和评估", "构建 90 天流失预警，按客户注册月切分训练/验证，使用规则基线对比 PR-AUC，并按高价值客户单独评估召回"],
        ["负责用户画像建模", "职责模糊", "负责 26 个行为特征的口径与时点校验，排除活动后信息泄漏，模型上线前通过训练/服务特征一致率 99.5% 的检查"],
        ["模型准确率 92%", "类别不平衡下指标可能误导", "在 8.7% 正样本下将 PR-AUC 从基线 0.21 提升到 0.34，覆盖率提升未以客服误报率恶化为代价"]
      ],
      questions: [
        ["为什么选这个指标", "从业务代价、正负样本和阈值决策解释，不只背公式"],
        ["如何避免数据泄漏", "说明时间切分、特征可得时间、Pipeline 和训练/线上一致性"],
        ["模型上线后怎么监控", "覆盖输入漂移、分数分布、分层误差、业务指标、人工干预和回滚"]
      ]
    },
    {
      key: "engineer",
      match: /数据工程师|Data Engineer/,
      label: "数据工程师",
      summary: "数据工程师简历要证明你能交付可靠、可恢复、可治理的数据链路。吞吐和组件只是背景，关键是数据契约、质量、故障与成本。",
      signals: ["批/流链路", "数据模型与调度", "吞吐和延迟", "质量与幂等", "故障恢复和成本"],
      evidence: ["源目标对账", "分区与位点", "故障演练", "SLA/SLO", "资源和成本"],
      projects: [
        ["实时消费链路", "突出分区、Lag、Rebalance、offset、幂等 Sink、回放和源目标对账，区分扩容与结构优化。"],
        ["离线数仓任务", "突出事实粒度、依赖、分区就绪、幂等重跑、长尾任务和小文件治理。"],
        ["数据接入平台", "突出 CDC 位点、Schema 演进、删除事件、全增量切换和失败补偿。"]
      ],
      rewrites: [
        ["负责 Kafka 消费任务", "没有规模与故障", "维护 12 个分区订单 Topic 的实时入湖，按分区 Lag 和 Sink 时延拆分瓶颈，设计按业务主键幂等与 24 小时回放"],
        ["优化 Spark 作业", "缺少证据", "通过 Spark UI 定位少量热点商户 Task 长尾与 Spill，采用两阶段聚合和空 Key 隔离，在同数据快照下保持金额守恒"],
        ["搭建数据仓库", "范围过大", "建立订单行事实表与客户、商品、门店一致性维度，补充唯一性、金额平衡和维度命中率门禁"]
      ],
      questions: [
        ["任务失败如何恢复", "要能说明幂等、重跑范围、下游通知、数据对账和回滚"],
        ["性能瓶颈在哪里", "用 Task 分位数、Shuffle、Spill、IO、队列等待和下游耗时解释"],
        ["如何保证数据质量", "从契约、测试、监控、隔离、修复和复盘形成闭环，不能只回答告警"]
      ]
    },
    {
      key: "product",
      match: /数据产品经理/,
      label: "数据产品经理",
      summary: "数据产品经理简历要证明你既能定义业务问题，也能约束数据、模型、权限和运营边界；原型和功能列表不是最终价值。",
      signals: ["用户与决策场景", "产品目标和非目标", "指标与评估", "数据/模型约束", "采用、运营和商业化"],
      evidence: ["用户研究", "需求与版本", "采用数据", "质量反馈", "业务行动"],
      projects: [
        ["经营分析平台", "从重复决策和口径冲突出发，写指标治理、权限、采用率和行动闭环。"],
        ["RAG/Text-to-SQL 产品", "写任务边界、评测集、拒答、人工接管、权限和高风险场景限制。"],
        ["标签/画像平台", "写标签质量、有效期、授权、人群应用和实验，而不是标签数量。"]
      ],
      rewrites: [
        ["负责数据产品从 0 到 1", "口号化", "面向区域运营上线门店异常分析，首期只覆盖客流、缺货和排班三类决策，灰度 18 家门店后按周关闭无行动告警"],
        ["推动 AI 助手落地", "没有边界和采用", "定义制度问答仅回答有有效版本和权限的证据，设置冲突、过期和无答案拒答，法务场景保留人工确认"],
        ["建设指标体系", "缺少治理", "建立指标 Owner、口径版本和变更通知，将月结争议工单从每期 24 个降至 7 个"]
      ],
      questions: [
        ["产品解决了什么决策", "说明用户、触发场景、行动和不用产品时的代价"],
        ["如何排优先级", "从价值、风险、依赖、采用和学习成本解释，不只说业务方要求"],
        ["AI 功能如何验收", "使用任务完成、引用、拒答、越权、人工修订和采用率等组合指标"]
      ]
    },
    {
      key: "bi",
      match: /BI分析师|\bBI\b/,
      label: "BI 分析师",
      summary: "BI 分析师简历要有语义模型、指标治理、可视化和行动闭环证据；会做图不等于能让组织用同一口径做决定。",
      signals: ["业务问题", "语义模型与指标", "数据质量", "可视化与交互", "采用与行动"],
      evidence: ["指标卡", "语义模型", "看板使用", "异常闭环", "用户反馈"],
      projects: [
        ["经营驾驶舱", "写清受众、决策节奏、指标树、下钻路径、数据新鲜度和异常处理。"],
        ["语义层治理", "写复用维度、指标版本、权限和从报表回到明细的能力。"],
        ["异常分析", "写告警触发、分层拆解、业务确认和行动结果，不只写做了多少张图。"]
      ],
      rewrites: [
        ["制作 30 张经营看板", "数量不等于价值", "重构区域经营看板，将 30 张重复报表收敛为 8 个主题和统一语义层，月活使用覆盖 6 个区域"],
        ["负责数据可视化", "职责泛化", "围绕门店营业额下降设计客流、客单、品类和时段下钻，帮助区域团队定位 3 家缺货门店"],
        ["优化报表速度", "缺少基线", "将高频查询从直连明细改为按日聚合快照，P95 从 18 秒降至 4 秒，同时保留明细追溯"]
      ],
      questions: [
        ["如何判断看板有用", "看决策、使用、行动和结果复盘，不只看访问次数"],
        ["指标冲突怎么处理", "说明 Owner、口径卡、版本、发布和淘汰机制"],
        ["如何处理性能与实时性", "从查询模式、粒度、预聚合、缓存和新鲜度权衡回答"]
      ]
    },
    {
      key: "analytics-engineer",
      match: /Analytics.?Engineer/i,
      label: "Analytics Engineer",
      summary: "Analytics Engineer 连接分析与数据工程，简历要同时展示业务语义、SQL 模型、测试、契约、文档和下游采用。",
      signals: ["业务过程与粒度", "维度建模", "SQL/转换框架", "测试与契约", "文档、复用和发布"],
      evidence: ["模型 DAG", "测试覆盖率", "数据契约", "血缘", "下游采用与故障"],
      projects: [
        ["分析模型层", "写清事实粒度、一致性维度、增量策略、测试和指标复用。"],
        ["数据契约", "写 schema、新鲜度、主键、质量门禁和消费者影响分析。"],
        ["指标交付", "从原始事件到统一指标，保留版本、测试和业务验收。"]
      ],
      rewrites: [
        ["编写大量 SQL", "没有模型与质量", "维护 28 个分析模型，为核心事实表增加粒度唯一、金额平衡和维度命中测试，变更前自动生成下游影响清单"],
        ["搭建 dbt 项目", "工具代替成果", "将分散 SQL 重组为 staging、intermediate、mart 三层，统一客户与日期维度，关键模型测试覆盖率达到 92%"],
        ["支持业务取数", "被动职责", "为留存和复购定义共享指标层，减少重复口径，业务自助分析采用率提升且核心争议工单下降"]
      ],
      questions: [
        ["如何选择模型粒度", "从业务过程、事件、快照和指标可加性解释"],
        ["测试应该覆盖什么", "主键、关系、取值范围、业务守恒、新鲜度和异常量级"],
        ["模型变更如何发布", "契约、影响分析、兼容窗口、灰度、回滚和消费者确认"]
      ]
    },
    {
      key: "operations",
      match: /数据运营/,
      label: "数据运营",
      summary: "数据运营简历要证明你能把数据转成人群、策略、动作和复盘，而不是停留在日报、取数和活动记录。",
      signals: ["业务目标", "用户/商品/渠道分层", "策略与实验", "执行协同", "护栏与复盘"],
      evidence: ["人群规则", "活动与触达", "实验基线", "成本和退款", "行动记录"],
      projects: [
        ["会员复购", "写清首购、复购、退款、归因窗口和触达频控，区分自然增长与策略收益。"],
        ["渠道增长", "写清渠道质量、获客成本、转化、留存和收入贡献。"],
        ["运营自动化", "写清规则触发、权限、内容质量、人工复核和异常停止。"]
      ],
      rewrites: [
        ["负责会员活动运营", "没有策略和结果", "针对 30 天未复购人群设计分层触达，先做 10% 灰度，比较复购、退款和退订，扩展前确认毛利未被优惠侵蚀"],
        ["输出每日经营日报", "停留在报表", "将日报异常转为行动清单，按渠道、商品和履约节点分派责任人，关闭率与复发率进入周复盘"],
        ["使用 AI 提升内容效率", "缺少质量控制", "用 AI 生成候选文案，品牌词、禁用承诺和价格由规则校验，人工抽检后进入小流量实验"]
      ],
      questions: [
        ["策略效果如何归因", "说明对照组、自然趋势、同期活动、触达频控和护栏"],
        ["如何做用户分层", "从业务目标、行为窗口、价值和可执行性解释，不堆标签"],
        ["AI 出错谁负责", "说明规则门禁、人工复核、发布权限和回退"]
      ]
    },
    {
      key: "governance",
      match: /数据治理工程师|数据治理/,
      label: "数据治理工程师",
      summary: "数据治理简历要证明标准、质量、血缘、权限和审计真正进入流程与系统，而不是只组织会议或整理制度。",
      signals: ["治理对象与责任", "标准/主数据/质量", "平台与自动化", "跨部门推动", "审计与闭环"],
      evidence: ["资产与Owner", "规则版本", "血缘覆盖", "问题闭环", "权限审计"],
      projects: [
        ["监管数据质量", "写规则分级、阻断、修复、责任和审计证据。"],
        ["主数据治理", "写编码、匹配、合并、拆分、审批和历史关系保留。"],
        ["权限与分类分级", "写用途、最小权限、列级控制、到期回收和审计。"]
      ],
      rewrites: [
        ["推动数据治理制度落地", "只有制度没有执行", "建立 46 项核心资产 Owner 与质量门禁，把主键重复、金额不平和历史分区覆盖设为发布阻断项，按故障回放验证拦截"],
        ["负责元数据管理", "平台功能罗列", "从任务 SQL、调度和 API 定义构建字段级血缘，记录解析置信度与人工登记，变更前自动生成消费者影响清单"],
        ["提升数据质量", "缺少范围与结果", "将近千条无分级告警收敛为 38 条关键规则，补充失败样本、处置时限和误报复核，关键问题拦截率得到验证"]
      ],
      questions: [
        ["治理如何证明有效", "用资产覆盖、关键规则拦截、问题闭环、变更影响和审计证据衡量"],
        ["业务不配合怎么办", "从风险、责任、决策价值和最小试点推进，不把治理变成额外报表"],
        ["权限如何审计", "覆盖身份、用途、资源、列、时间、审批、访问结果和到期回收"]
      ]
    },
    {
      key: "analyst",
      match: /数据分析师|Data.?Analyst|初级数据分析师/,
      label: "数据分析师",
      summary: "数据分析师简历要证明你能定义问题、保证口径、完成分析并推动行动；工具清单不能代替业务判断。",
      signals: ["业务问题", "对象与指标", "SQL/分析/可视化", "验证与归因", "行动和复盘"],
      evidence: ["决策问题", "口径与基线", "SQL对账", "分层证据", "业务行动"],
      projects: [
        ["转化下降", "先拆对象、分母、渠道、商品和同期变化，再区分数据问题、结构变化与真实业务变化。"],
        ["留存/复购", "写清首发时间、观察窗口、回访状态、分群和自然趋势。"],
        ["经营看板", "写指标树、口径、使用场景和异常到行动的闭环。"]
      ],
      rewrites: [
        ["负责日常取数和报表", "被动职责", "围绕渠道转化下降建立对象与分母核对，发现支付回调迟到导致当日转化低估，修复后为活动复盘提供可比基线"],
        ["使用 SQL 分析用户行为", "工具导向", "用 SQL 重建注册、首购和复购时间线，按渠道与新老客分层，定位某渠道高退款对净增长的影响"],
        ["优化活动效果", "结论过宽", "将活动效果拆成增量订单、优惠成本、退款和自然趋势，小流量实验显示支付转化提升但毛利未改善"]
      ],
      questions: [
        ["指标下降怎么查", "先质量与时点，再总量/结构/行为，最后做样本和业务验证"],
        ["SQL 一对多如何避免放大", "先确认粒度、Join 基数、聚合顺序和金额守恒"],
        ["分析如何推动行动", "说明决策人、备选动作、证据、执行和复盘"]
      ]
    }
  ];
  const spec = roleSpecs.find((item) => item.match.test(topic)) || {
    key: "data",
    label: "数据岗位",
    summary: "数据岗位简历要从招聘要求出发，用对象、动作、方法、结果和边界证明岗位匹配度。",
    signals: ["目标岗位", "核心任务", "项目证据", "技术能力", "业务协作"],
    evidence: ["岗位要求", "项目原始记录", "口径与结果", "个人边界", "面试复盘"],
    projects: [
      ["选择最相关项目", "优先展示与目标岗位相同的数据对象、问题类型和交付责任。"],
      ["写清个人动作", "区分自己设计、开发、推动和复核的内容，团队成果不能冒充个人成果。"],
      ["补充边界", "说明样本、周期、风险和未解决问题，保持事实可核验。"]
    ],
    rewrites: [
      ["参与重点项目", "没有动作与结果", "说明自己负责的对象、链路或分析环节，以及如何验证"],
      ["精通多种工具", "无法验证", "把工具绑定到任务、约束和交付证据"],
      ["提升业务效率", "没有基线与采用", "写清旧流程、变化、使用者和仍需人工处理的环节"]
    ],
    questions: [
      ["为什么选择这个岗位", "用项目和能力证据回答，不写空泛热情"],
      ["最强项目是什么", "说明问题、动作、结果、失败和重做方案"],
      ["如何证明 AI 能力", "展示任务、数据、评估、安全和采用，不背模型名称"]
    ]
  };
  const sectionOrder = profile.seed % 2 === 0
    ? ["evidence", "project", "rewrite", "ai", "interview", "check"]
    : ["project", "evidence", "interview", "rewrite", "ai", "check"];
  const sections = {
    evidence: `## 招聘方真正要找的${spec.label}证据

${table(
      ["招聘信号", "简历中应出现的事实", `${spec.label}的常见误写`],
      spec.signals.map((signal, index) => [
        signal,
        spec.evidence[index % spec.evidence.length],
        ["只写“负责相关项目”", "只列工具名称", "没有对象和范围", "结果数字无法解释", "把团队产出写成个人成果"][(profile.seed + index) % 5]
      ])
    )}

${spec.summary} 简历筛选通常先判断岗位匹配，再验证项目深度。项目名称看起来相似时，能决定结果的是你负责的边界、遇到的失败和留下的证据。`,
    project: `## ${spec.label}项目应怎样展开

${spec.projects.map(([name, detail], index) => `### ${index + 1}. ${name}

${detail}

每段项目建议保留四类信息：问题与用户、你亲自完成的动作、可解释的结果、没有解决的边界。没有真实数字时，可以写清质量、时效、覆盖或流程变化，但不要编造精确百分比。`).join("\n\n")}`,
    rewrite: `## 三组针对${spec.label}的改写

${table(
      ["弱写法", "为什么弱", "改写方向"],
      spec.rewrites
    )}

改写时不要只替换动词。先确认目标岗位是否真的需要这项能力，再判断原句能否提供对象、动作、约束和证据。无法证明的内容应当缩小范围或删除。`,
    ai: `## AI 能力怎样写才可信

${list([
      `把 AI 写成一个具体任务：检索、分类、生成、Text-to-SQL、Agent 动作或模型预测，而不是“熟悉大模型”。`,
      `写清数据来源、授权、版本、敏感字段和评测集；没有评测集的演示不能支撑“提升准确率”。`,
      `写清安全边界：权限过滤、引用、拒答、人工审批、最大步数、成本和失败回退。`,
      `写清采用证据：谁在用、替代了哪个步骤、人工修订多少，以及哪些高风险决定仍由人负责。`,
      `${spec.label}的 AI 项目应服务于岗位核心任务，不要为了追热点把无关聊天机器人放在简历首位。`
    ])}`,
    interview: `## 面试追问与作答证据

${table(
      ["简历信号", "可能追问", "需要准备的证据"],
      spec.questions.map(([question, evidence], index) => [
        spec.signals[index % spec.signals.length],
        question,
        evidence
      ])
    )}

回答时先给结论，再给两到三个事实，最后说明边界。不要用“我们团队”覆盖自己的职责，也不要把一次成功演示描述成长期生产运营。`,
    check: `## 投递前检查

${list([
      "把岗位最看重的项目放在第一页上半部分，摘要不超过三行。",
      "每条项目描述尽量控制在一至三行，保留对象、动作、方法、结果和边界。",
      "所有数字准备基线、周期、样本、计算方式和个人贡献说明。",
      "删除身份证号、家庭住址、内部域名、客户名单、密钥和未公开经营数据。",
      "统一时间和工具大小写，导出 PDF 后检查字体、分页、链接与移动端阅读。",
      `本页目标岗位是“${spec.label}”，不要用同一份内容直接投数据分析、数据工程和 AI 产品三个方向。`
    ])}`
  };
  const candidateBlock = named ? `## ${named}的一页式内容骨架

${table(
      ["模块", "建议内容", "不要写什么"],
      [
        ["求职目标", `${spec.label} / 数据方向，突出与目标岗位最接近的 2 个能力`, "“希望找一份有发展的工作”"],
        ["个人摘要", `${named}，用 2 段项目证据说明擅长对象、方法和交付`, "性格形容词和无法验证的自评"],
        ["核心项目 A", spec.projects[0][0], "只有技术栈，没有个人动作"],
        ["核心项目 B", spec.projects[1][0], "团队成绩全部写个人"],
        ["技术工具", "与项目证据一致的工具和熟练边界", "列出二十个只听过名字的工具"],
        ["教育与证书", "与岗位相关的教育、证书或持续学习证据", "与岗位无关的大段课程"]
      ]
    )}

此页是公开演示用的虚构候选人结构，姓名、项目和数字只用于展示排版，不应作为真实候选人经历引用。` : "";
  const selectedSections = sectionOrder.map((key) => sections[key]);
  if (candidateBlock) selectedSections.splice(1, 0, candidateBlock);
  return `${abstract(profile, plan, spec.summary)}

${selectedSections.join("\n\n")}

${sourceList(d, profile)}`;
}

function genericDossier(profile, plan) {
  const copy = FAMILY_COPY[plan.family] || FAMILY_COPY.default;
  const d = plan.definition;
  const variants = [
    `从工作现场看，${profile.topic}通常不是单独出现的问题。它会同时牵动${d.objects.slice(0, 3).join("、")}和${d.roles.slice(0, 3).join("、")}之间的判断。`,
    `把${profile.topic}写进方案时，先不要急着选工具。先确认${d.stages.slice(0, 3).join("、")}各自产出什么证据，以及哪一步失败会让后续结果失去意义。`,
    `${profile.topic}的难点往往在交接处：业务认为已经完成，系统状态还没有生效，数据又已经进入下游。只有把对象、时点和责任人固定下来，结果才可复核。`,
    `一份有用的${profile.topic}说明，应让读者知道问题从哪里开始、使用什么样本、结论适用于谁，以及出现反例时由谁停下来处理。`,
    `在${d.label}中，${profile.topic}不只是知识名词。它需要能解释一次业务判断、一次异常处置或一次交接为什么成功或失败。`,
    `如果只能保留一种证据，优先保留能回到原始对象的明细和时间线。${profile.topic}的汇总结果必须能向下解释，否则图表越完整，误判传播得越快。`
  ];
  const actions = [
    `先抽 20 条正常记录和 10 条边界记录，逐条核对${copy.evidence}。`,
    `把${d.stages.slice(0, 4).join("、")}画成状态链，标出输入、输出和停止条件。`,
    `对比${d.systems.slice(0, 3).join("、")}中的同一对象，确认主键、时间和状态能否对应。`,
    `让${d.roles.slice(0, 3).join("、")}分别解释一个失败样本，记录口径差异而不是只记结论。`,
    `先修复一个可验证的${copy.failure}，再做范围扩展。`,
    `把${d.metrics.slice(0, 3).join("、")}和至少一个护栏指标写入复盘。`
  ];
  const cases = (d.cases && d.cases.length ? d.cases : [
    ["某跨部门数据团队", `围绕“${profile.topic}”整理口径时，发现业务记录与系统状态无法对应`]
  ]);
  const seed = hash(`${profile.relativePath}:${profile.title}:dossier`);
  const selected = Array.from({ length: Math.min(3, cases.length) }, (_, index) => cases[(seed + index) % cases.length]);
  return `## ${copy.section}：把“${profile.topic}”落到现场

${pick(variants, profile, "dossier-lead")} 这篇内容属于${profile.section || d.label}，讨论范围是${d.label}，不从其他专题直接借用结论。

${table(
    ["先固定", "本篇要回答", "证据"],
    [
      ["对象", d.objects.slice(0, 4).join("、"), d.controls[0] || "对象清单与样本"],
      ["时间", "业务发生、系统生效、数据处理和报告时点分别是什么", "时间字段说明与跨期样本"],
      ["状态", "开始、完成、撤回、失败和人工修正是如何记录的", "状态字典与状态迁移"],
      ["口径", d.metrics.slice(0, 4).join("、"), "公式、分母、排除项与版本"],
      ["行动", "谁使用结果继续、阻断、修复或升级", "行动日志与复核日期"]
    ]
  )}

### 本篇的判断顺序

${list([
    copy.decision,
    `用${d.stages[0]}确认问题边界，不用一张总览替代业务过程。`,
    `用${d.stages[Math.min(2, d.stages.length - 1)]}核对对象与状态，优先排除身份、时间和版本错误。`,
    `用${d.stages[Math.min(4, d.stages.length - 1)]}验证结果，保留正常、边界和失败样本。`,
    `最后由${d.roles[0]}确认行动，由${d.roles[Math.min(2, d.roles.length - 1)]}复核副作用。`
  ])}

### 工作现场与处理

${selected.map((scenario, index) => `#### 现场 ${index + 1}：${scenario[0]}

${scenario[1]}。这个情景用于说明${profile.topic}的判断方法，已经脱敏并合并常见现场，不对应单一企业事实。

处理时先执行：${pick(actions, profile, `action-${index}`)} 如果发现${copy.failure}，暂停据此形成结论，先把${d.controls[(seed + index) % d.controls.length]}补齐。

复核时同时观察${d.metrics.slice(0, 3).join("、")}和${d.metrics[Math.min(3, d.metrics.length - 1)]}。只有对象、时间和口径能解释，且行动后果可回查，才把这次处理沉淀为可复用规则。`).join("\n\n")}

### 本主题不建议直接照搬什么

${list(d.risks.slice(0, 4).map((risk, index) => `${risk}。遇到这种情况先检查${d.controls[(index + 1) % d.controls.length]}，不要用更复杂的图表或自动化掩盖语义问题。`))}`;
}

function genericArticle(profile, plan) {
  return genericDossier(profile, plan);
}

function buildTitleFamilyArticle(profile, plan) {
  const featuredArticles = {
    "企业级建模方法论": enterpriseModelingArticle,
    "金融风险管理体系": financeRiskArticle,
    "信托业务全景解析": trustBusinessArticle,
    "ICU": icuArticle,
    "六西格玛": sixSigmaArticle,
    "电动汽车供应链管理体系": evSupplyChainArticle
  };
  if (profile.topic === "热力图") {
    return profile.relativePath.startsWith("【各行业的基础知识】/02-零售电商")
      ? webHeatmapArticle(profile, plan)
      : analysisHeatmapArticle(profile, plan);
  }
  if (profile.kind === "resume") {
    return resumeArticle(profile, plan);
  }
  if (profile.kind === "career") {
    return careerArticle(profile, plan);
  }
  if (
    profile.kind === "learning" &&
    (
      profile.relativePath.startsWith("【学习路线】/") ||
      profile.relativePath.startsWith("【学习方法分享】/") ||
      profile.relativePath.startsWith("【求职就业专题】/")
    )
  ) {
    return learningArticle(profile, plan);
  }
  const renderer = featuredArticles[profile.topic];
  return renderer ? renderer(profile, plan) : null;
}

module.exports = {
  buildTitleFamilyArticle,
  enterpriseModelingArticle,
  financeRiskArticle,
  webHeatmapArticle,
  analysisHeatmapArticle,
  trustBusinessArticle,
  icuArticle,
  sixSigmaArticle,
  evSupplyChainArticle,
  resumeArticle,
  slug
};
