const { resolveTopicBlueprint } = require("./topic-blueprints");
const { buildTitleFamilyArticle } = require("./title-family-renderers");

const FAMILY_DEFINITIONS = {
  modeling: {
    label: "企业数据建模",
    roles: ["业务数据负责人", "数据架构师", "模型开发", "指标负责人", "数据治理委员"],
    objects: ["业务对象", "业务事件", "事实粒度", "一致性维度", "指标口径"],
    systems: ["业务系统", "数据仓库", "元数据平台", "指标平台", "数据质量平台"],
    stages: ["识别业务过程", "确定事实粒度", "定义维度与键", "处理历史变化", "发布模型契约"],
    metrics: ["粒度冲突数", "维度复用率", "历史可追溯率", "下游影响面", "口径争议单量"],
    risks: ["事实粒度混用", "维度历史被覆盖", "逻辑模型未评审", "模型变更未通知下游", "同名指标多套口径"],
    controls: ["事实表一行含义可复述", "业务时间和入仓时间分离", "SCD 有效期可关联", "模型版本可回滚", "下游影响分析完整"],
    cases: [
      ["某跨区域零售集团的会员分析组", "会员、订单、门店和活动数据被拼成一张宽表，历史会员等级被最新状态覆盖"],
      ["某保险公司数据架构团队", "保单、批改、赔付和佣金各自建模，理赔事件无法稳定关联到保单版本"],
      ["某制造集团供应链数据组", "采购订单、入库批次和发票行粒度不同，数量在集团报表中被重复累计"],
      ["某证券公司客户平台", "委托、成交、资金流水和持仓快照被放进同一事实表，导致金额与数量无法对账"]
    ],
    sources: [
      ["Kimball Dimensional Modeling Techniques", "https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/"],
      ["DAMA-DMBOK2", "https://www.dama.org/cpages/body-of-knowledge"],
      ["TOGAF Standard", "https://www.opengroup.org/togaf"]
    ]
  },
  finance: {
    label: "金融业务与风险管理",
    roles: ["业务负责人", "风险经理", "财务与精算", "合规人员", "数据管理员"],
    objects: ["客户", "合同", "账户", "交易", "资产", "风险分类"],
    systems: ["核心账务系统", "信贷系统", "风险数据集市", "总账系统", "监管报表平台"],
    stages: ["客户准入", "业务审批", "交易或放款", "存续期管理", "分类与处置", "报表复核"],
    metrics: ["业务规模", "收益率", "风险成本", "不良或逾期", "资本占用", "客户贡献"],
    risks: ["时点与期间混用", "并表范围不一致", "本金与利息重复计算", "风险分类版本错配", "调整项没有审批轨迹"],
    controls: ["分子分母来自同一快照", "业务日期与会计日期分离", "合同与账户主键可追溯", "分类版本带生效时间", "监管与会计口径分别登记"],
    cases: [
      ["某城市商业银行零售金融部", "季度不良率上升，但新增下迁、处置回收和核销对变化的贡献无法拆清"],
      ["某股份制银行公司业务部", "同一集团客户在多个分行有授信，单户口径与集团口径同时存在"],
      ["某保险集团精算数据中心", "保单、准备金和赔付在财务与监管报表中的期间和范围不一致"],
      ["某消费金融公司决策科学团队", "申请评分、额度使用和逾期表现无法按客户与借据统一关联"],
      ["某证券公司风险管理部", "融资融券客户的担保品、负债和强平事件跨系统时点不一致"]
    ],
    sources: [
      ["BIS Basel Framework", "https://www.bis.org/basel_framework/"],
      ["IFRS Foundation", "https://www.ifrs.org/"],
      ["中国人民银行统计数据", "http://www.pbc.gov.cn/diaochatongjisi/116219/index.html"]
    ]
  },
  manufacturing: {
    label: "制造运营与工业数据",
    roles: ["生产计划", "工艺工程师", "设备维护", "质量工程师", "工业数据团队"],
    objects: ["工厂", "产线", "设备", "工单", "批次", "质量记录"],
    systems: ["ERP", "MES", "SCADA", "QMS", "WMS", "设备物联网平台"],
    stages: ["计划排产", "物料准备", "工单执行", "质量检验", "入库发运", "异常复盘"],
    metrics: ["计划达成率", "设备利用率", "良品率", "生产周期", "库存周转", "单位制造成本"],
    risks: ["计划时间与运行时间混淆", "停机区间重叠", "工单批次断链", "标准节拍版本失效", "返工被重复计数"],
    controls: ["设备时间台账连续", "工单与批次可追溯", "标准参数按生效日期版本化", "停机原因编码唯一", "产量与质检记录平衡"],
    cases: [
      ["某精密零部件工厂设备部", "设备报警频繁，但故障停机、微停和速度损失没有放在同一时间账上"],
      ["某新能源材料工厂质量组", "批次质量波动明显，工单、设备参数和检验结果无法快速串联"],
      ["某食品加工集团生产中心", "换型与清洗时间混在计划停机中，产能判断长期偏高"],
      ["某电子组装厂工业工程团队", "产出数量增加但良率下降，返工工时被计入有效产出"],
      ["某汽车零部件供应商质量部", "供应商来料、上线批次和售后失效记录无法完成批次追踪"]
    ],
    sources: [
      ["ISA-95 overview", "https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard"],
      ["ISO 22400-2", "https://www.iso.org/standard/54497.html"],
      ["NIST Smart Manufacturing", "https://www.nist.gov/programs-projects/smart-manufacturing"]
    ]
  },
  retail: {
    label: "零售、电商与营销运营",
    roles: ["商品运营", "用户运营", "投放优化师", "活动运营", "供应链计划", "数据分析师"],
    objects: ["用户", "商品", "店铺", "订单", "流量", "活动", "履约单"],
    systems: ["广告平台", "推荐系统", "订单中心", "会员系统", "履约系统", "客服系统"],
    stages: ["曝光", "点击", "浏览", "加购", "支付", "履约", "售后", "复购"],
    metrics: ["CTR", "CVR", "客单价", "毛利率", "获客成本", "复购率", "退款率", "履约时效"],
    risks: ["曝光与点击口径不一致", "归因窗口重叠", "活动优惠重复计算", "自然增长被当成投放效果", "退款未回到原订单"],
    controls: ["用户与设备身份可映射", "订单金额按明细对账", "去重规则有版本", "归因窗口可追溯", "活动预算与核销平衡"],
    cases: [
      ["某品牌服饰直营电商", "投放 ROI 看似改善，但退款和跨渠道归因导致真实贡献被高估"],
      ["某内容电商平台商家运营组", "商品曝光增长而支付转化下降，流量质量与详情页问题同时存在"],
      ["某即时零售平台履约团队", "订单增长时配送超时和缺货率同时上升，瓶颈无法按区域定位"],
      ["某连锁便利店会员团队", "会员数持续增长，高价值会员占比与复购贡献无法稳定解释"],
      ["某跨境店铺推广团队", "关键词、匹配方式和否词调整后，广告结构变化无法按搜索词复盘"]
    ],
    sources: [
      ["Google Analytics measurement guidance", "https://support.google.com/analytics/answer/9355655"],
      ["OpenRTB specification", "https://iabtechlab.com/standards/openrtb/"],
      ["Trustworthy Online Controlled Experiments", "https://experimentguide.com/"]
    ]
  },
  healthcare: {
    label: "医疗健康业务与数据",
    roles: ["临床科室", "医务管理", "医保人员", "信息中心", "数据治理", "安全合规"],
    objects: ["患者", "就诊", "医嘱", "检查检验", "处方", "费用", "随访"],
    systems: ["HIS", "EMR", "LIS", "PACS", "医保结算", "随访平台"],
    stages: ["预约挂号", "接诊", "检查检验", "诊断治疗", "结算", "随访与质控"],
    metrics: ["门急诊人次", "平均住院日", "检查及时率", "复诊率", "费用偏差", "质量事件率"],
    risks: ["患者主索引重复", "临床时间与计费时间混用", "诊断编码版本失效", "检验单位不统一", "敏感数据越权访问"],
    controls: ["患者主索引跨院区唯一", "就诊与医嘱时间有序", "检验结果带单位和参考区间", "费用明细可对账", "访问目的与权限可审计"],
    cases: [
      ["某区域三甲医院门诊部", "高峰投诉增加，但号源、接诊、检查和报告回传的断点无法区分"],
      ["某医疗集团运营管理中心", "多院区同一患者被重复计数，重点专科服务量口径不一致"],
      ["某互联网医院运营团队", "在线问诊订单增长，完成率却因医生供给和支付超时下降"],
      ["某医学影像中心质控组", "检查量增长后报告及时率波动，设备等待与复审返工混在一起"],
      ["某区域医保管理部门", "结算、审核和拒付明细无法按同一就诊与费用项目回查"]
    ],
    sources: [
      ["国家卫生健康委员会", "http://www.nhc.gov.cn/"],
      ["HL7 FHIR specification", "https://hl7.org/fhir/"],
      ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"]
    ]
  },
  governance: {
    label: "数据治理与数据安全",
    roles: ["数据所有者", "数据管理员", "业务专家", "平台团队", "安全合规", "审计"],
    objects: ["数据资产", "业务术语", "指标", "数据标准", "质量规则", "权限策略"],
    systems: ["元数据平台", "数据质量平台", "指标平台", "权限系统", "工单系统", "审计平台"],
    stages: ["识别资产", "明确责任", "定义标准", "建立控制", "监测问题", "变更与复盘"],
    metrics: ["资产登记率", "规则通过率", "问题闭环时长", "血缘覆盖率", "变更影响面", "权限合规率"],
    risks: ["责任边界不清", "规则只有告警没有处置", "血缘断点导致影响分析失真", "权限长期未复核", "标准与系统实现脱节"],
    controls: ["资产有唯一编号和责任人", "规则阈值有业务依据", "问题保留时间线与证据", "变更影响分析完整", "权限按用途和期限审批"],
    cases: [
      ["某银行数据治理办公室", "监管报表问题反复出现，却无法定位责任系统和上游变更"],
      ["某零售集团数据平台", "商品主数据在门店、电商和供应链系统中编码不一致"],
      ["某制造企业数据管理部", "设备停机原因编码各工厂自行扩展，集团报表无法汇总"],
      ["某保险公司数据安全团队", "分析人员长期持有宽表权限，敏感字段用途没有定期复核"],
      ["某互联网平台数据委员会", "表血缘只覆盖计算任务，接口和报表消费关系缺失"]
    ],
    sources: [
      ["DAMA-DMBOK2", "https://www.dama.org/cpages/body-of-knowledge"],
      ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"],
      ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"]
    ]
  },
  analytics: {
    label: "数据分析与经营决策",
    roles: ["业务负责人", "数据分析师", "产品经理", "运营", "实验平台", "决策委员会"],
    objects: ["业务对象", "用户或客户", "事件", "指标", "分组", "实验或策略"],
    systems: ["业务数据库", "埋点平台", "数据仓库", "实验平台", "BI 工具", "行动系统"],
    stages: ["定义决策问题", "确认对象与口径", "建立基线", "拆解变化", "验证假设", "行动与复盘"],
    metrics: ["规模", "转化率", "留存率", "贡献度", "波动区间", "护栏指标"],
    risks: ["总体平均掩盖分层差异", "分母随筛选条件变化", "多重比较产生假阳性", "相关关系被解释为因果", "结论没有行动负责人"],
    controls: ["对象、粒度、时间和排除项固定", "基线具有可比性", "切分次数预先登记", "实验污染已检查", "结论绑定行动与复核日期"],
    cases: [
      ["某电商增长分析团队", "总体转化率只小幅下降，但不同渠道和用户层级的贡献方向相反"],
      ["某内容平台策略组", "推荐点击率提升，长期留存和内容多样性却可能恶化"],
      ["某连锁餐饮经营分析部", "门店营业额下降，需要区分客流、客单、时段和新店结构"],
      ["某 SaaS 产品数据团队", "功能使用率上升，但续费和客服工单显示价值并未同步改善"],
      ["某出行平台城市运营组", "补贴上线后订单增长，自然需求与预算浪费难以分离"]
    ],
    sources: [
      ["Trustworthy Online Controlled Experiments", "https://experimentguide.com/"],
      ["OECD composite indicators handbook", "https://www.oecd.org/sdd/42495745.pdf"],
      ["Google Analytics measurement guidance", "https://support.google.com/analytics/answer/9355655"]
    ]
  },
  engineering: {
    label: "数据工程与数据架构",
    roles: ["数据开发", "平台工程", "数据架构师", "SRE", "安全工程师", "业务负责人"],
    objects: ["数据源", "任务", "表或主题", "接口", "服务", "运行事件"],
    systems: ["调度平台", "消息队列", "计算引擎", "数据仓库", "元数据平台", "监控平台"],
    stages: ["需求与约束", "源端接入", "模型与任务设计", "测试发布", "运行监控", "故障复盘"],
    metrics: ["任务成功率", "端到端延迟", "数据完整率", "重复写入数", "资源成本", "恢复时长"],
    risks: ["分区覆盖不完整", "任务不幂等", "依赖形成环", "热点导致长尾任务", "发布缺少回滚"],
    controls: ["输入版本和分区可追溯", "重复执行结果一致", "依赖图无环", "监控覆盖延迟与质量", "回滚与重放经过演练"],
    cases: [
      ["某电商订单实时链路团队", "大促期间消息积压，扩容后 Rebalance 和下游写入瓶颈反而被放大"],
      ["某物流集团离线数仓团队", "核心事实任务从小时级恶化到半天，资源增加后长尾任务仍然存在"],
      ["某金融机构数据服务团队", "接口版本升级后旧客户端解析失败，发布流程没有兼容性检查"],
      ["某内容平台湖仓团队", "小文件持续增加，查询变慢且元数据服务压力上升"],
      ["某零售企业调度平台团队", "上游任务成功但数据未就绪，下游按时间触发导致读到旧分区"]
    ],
    sources: [
      ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"],
      ["OpenAPI Specification", "https://spec.openapis.org/oas/latest.html"],
      ["Apache Spark Documentation", "https://spark.apache.org/docs/latest/"]
    ]
  },
  ai: {
    label: "人工智能与数据工程",
    roles: ["AI 工程师", "数据工程师", "算法工程师", "产品经理", "安全合规", "业务专家"],
    objects: ["任务", "训练或评测数据", "模型", "提示词", "检索证据", "反馈记录"],
    systems: ["数据平台", "特征平台", "模型服务", "向量数据库", "评测平台", "监控平台"],
    stages: ["任务定义", "数据准备", "基线与实验", "离线评估", "灰度上线", "反馈与回归"],
    metrics: ["任务成功率", "召回率", "忠实度", "拒答准确率", "P95 延迟", "单位请求成本"],
    risks: ["训练与线上特征时点不一致", "评测集泄漏", "无证据生成", "权限过滤缺失", "只看平均分忽略高风险切片"],
    controls: ["数据授权和版本可追溯", "训练验证测试隔离", "高风险切片单独评估", "输出可引用或拒答", "模型和提示词可回滚"],
    cases: [
      ["某企业知识库团队", "RAG 回答看似流畅，但旧制度和新制度同时被召回，引用无法支持结论"],
      ["某电商推荐算法组", "离线 AUC 提升，线上新用户转化没有改善，特征时点与样本权重存在偏差"],
      ["某客服 Agent 项目组", "工具调用成功率不低，但越权查询和高风险自动执行缺少拦截"],
      ["某金融风控模型团队", "模型版本更新后 KS 变化明显，训练样本与决策时点数据发生穿越"],
      ["某制造视觉质检团队", "整体准确率稳定，但少见缺陷类别漏检，样本和阈值未按产线拆分"]
    ],
    sources: [
      ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"],
      ["Google Rules of Machine Learning", "https://developers.google.com/machine-learning/guides/rules-of-ml"],
      ["OpenAI retrieval guide", "https://platform.openai.com/docs/guides/retrieval"]
    ]
  },
  project: {
    label: "数据项目交付",
    roles: ["项目负责人", "业务负责人", "数据开发", "数据治理", "安全合规", "运维"],
    objects: ["业务目标", "范围", "里程碑", "交付物", "风险", "验收证据"],
    systems: ["项目管理", "需求管理", "代码仓库", "调度平台", "监控平台", "工单系统"],
    stages: ["问题定义", "范围与基线", "方案设计", "迭代实施", "灰度验收", "运营复盘"],
    metrics: ["目标达成度", "按期交付率", "缺陷关闭率", "采用率", "回滚次数", "单位交付成本"],
    risks: ["范围持续扩张", "验收标准模糊", "关键依赖延期", "上线后无人使用", "数据迁移不可回滚"],
    controls: ["目标与非目标书面确认", "每个里程碑有退出条件", "变更说明替代关系", "上线前完成回滚演练", "运营指标有责任人"],
    cases: [
      ["某集团数据中台项目", "项目不断新增报表需求，核心口径和质量门禁却迟迟未完成"],
      ["某银行数据迁移项目", "新旧系统并行期间差异无法分类，业务不敢切换"],
      ["某零售企业实时链路项目", "演示环境表现正常，峰值流量和故障恢复没有纳入验收"],
      ["某制造企业主数据项目", "系统上线后工厂仍沿用旧编码，采用率和使用流程缺少跟踪"]
    ],
    sources: [
      ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"],
      ["PMI Disciplined Agile", "https://www.pmi.org/disciplined-agile"],
      ["Atlassian Project Management Guide", "https://www.atlassian.com/agile/project-management"]
    ]
  },
  career: {
    label: "数据职业发展与协作",
    roles: ["个人贡献者", "直属主管", "业务伙伴", "跨团队负责人", "人力资源", "面试官"],
    objects: ["目标岗位", "能力证据", "利益相关方", "决策", "反馈", "成长计划"],
    systems: ["项目记录", "作品集", "绩效材料", "会议与文档", "招聘流程", "学习平台"],
    stages: ["识别差距", "选择目标", "积累证据", "沟通影响", "复盘反馈", "调整计划"],
    metrics: ["能力证据数量", "关键任务完成度", "反馈改善率", "决策采纳率", "协作周期", "目标岗位匹配度"],
    risks: ["把忙碌当成长", "只讲团队成果不讲个人边界", "沟通没有决策对象", "遇到冲突只向上转移", "简历堆砌工具名"],
    controls: ["目标可验证", "案例说明个人动作", "利益相关方和决策权清楚", "反馈有具体行为", "每个阶段有作品或结果证据"],
    cases: [
      ["某互联网公司数据开发晋升准备", "项目很多但无法说明个人判断、影响范围和可复用资产"],
      ["某零售企业分析团队跨部门协作", "业务、产品和数据对同一目标理解不同，周会持续争论"],
      ["某银行数据岗位转岗面试", "候选人能背工具，却不能解释一次口径冲突如何解决"],
      ["某 SaaS 公司新人成长计划", "学习课程完成很多，工作中仍无法独立承担交付"]
    ],
    sources: [
      ["Google re:Work feedback guidance", "https://rework.withgoogle.com/guides/"],
      ["NIST Workforce Framework", "https://www.nist.gov/nice"],
      ["ATD capability model", "https://www.td.org/capability-model"]
    ]
  },
  learning: {
    label: "学习方法与能力成长",
    roles: ["学习者", "导师", "同伴", "业务专家", "项目负责人"],
    objects: ["学习目标", "知识地图", "练习", "反馈", "作品", "复盘"],
    systems: ["学习平台", "代码仓库", "笔记系统", "项目环境", "社区", "作品集"],
    stages: ["定义目标", "建立地图", "刻意练习", "项目应用", "获取反馈", "复盘迭代"],
    metrics: ["可演示作品数", "练习完成度", "问题复现率", "反馈采纳率", "知识迁移次数", "目标能力覆盖"],
    risks: ["只收藏资料不练习", "路径过长没有里程碑", "只学工具不理解机制", "没有反馈闭环", "作品无法复现"],
    controls: ["每个阶段有可验收产物", "练习包含失败样本", "由他人按文档复跑", "定期回顾错题", "学习内容绑定真实任务"],
    cases: [
      ["某转行者学习数据开发", "课程看了很多，却无法独立完成一条可监控、可回滚的数据任务"],
      ["某应届生准备数据分析作品集", "图表很多但没有问题、口径、行动和复盘"],
      ["某团队新人培养", "导师口头讲解多，缺少统一练习和反馈记录"],
      ["某工程师学习 Spark", "能背参数，却无法通过执行计划和数据分布解释性能变化"]
    ],
    sources: [
      ["The Learning Scientists", "https://www.learningscientists.org/"],
      ["Carnegie Mellon Eberly Teaching Resources", "https://www.cmu.edu/teaching/resources/"],
      ["NIST NICE Workforce Framework", "https://www.nist.gov/nice"]
    ]
  },
  resume: {
    label: "数据岗位简历与作品集",
    roles: ["候选人", "招聘者", "业务面试官", "技术面试官", "推荐人"],
    objects: ["目标岗位", "项目", "个人动作", "结果", "技术证据", "能力关键词"],
    systems: ["招聘系统", "简历文件", "作品集仓库", "演示环境", "项目文档", "面试记录"],
    stages: ["研究岗位", "筛选证据", "重写项目", "量化结果", "校验真实性", "针对投递"],
    metrics: ["岗位匹配度", "项目证据数", "一页信息密度", "面试追问通过率", "投递转化率", "事实可核验率"],
    risks: ["工具名堆砌", "团队成果冒充个人成果", "结果没有基线", "项目描述像岗位职责", "泄露内部信息"],
    controls: ["每条要点有动作与结果", "数字可解释", "个人边界真实", "技术栈对应岗位", "敏感信息已脱敏"],
    cases: [
      ["某数据分析师投递零售岗位", "简历写了十几种工具，却没有门店经营和实验分析案例"],
      ["某数据工程师转投平台方向", "项目只写参与建设，无法说明吞吐、故障和回滚"],
      ["某应届生作品集", "仪表盘截图很多，缺少数据来源、口径和业务行动"],
      ["某候选人准备 AI 岗位", "项目写“使用大模型”，没有任务、评测、风险和工程边界"]
    ],
    sources: [
      ["Google re:Work hiring guidance", "https://rework.withgoogle.com/guides/"],
      ["OWASP Top 10", "https://owasp.org/www-project-top-ten/"],
      ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"]
    ]
  }
};

const SUBDOMAIN_RULES = [
  {
    key: "oee",
    family: "manufacturing",
    match: /设备综合效率|OEE/i,
    label: "设备时间损失",
    focus: "把日历时间、计划停机、故障停机、换型、微停、速度损失和良品损失放在同一条设备时间账上。",
    concepts: ["时间开动率", "性能开动率", "良品率", "标准节拍版本", "停机原因", "工单与批次"],
    evidence: ["设备状态区间", "工单执行记录", "标准节拍生效版本", "质检与返工明细"],
    traps: ["计划保养未排除", "停机区间重叠", "标准节拍用错版本", "返工品重复计入产出"],
    codeKind: "sql-oee"
  },
  {
    key: "quality",
    family: "manufacturing",
    match: /质量|良率|返工|报废|缺陷|SPC|检验/i,
    label: "制造质量追溯",
    focus: "用设备、工单、批次、工艺参数和检验结果重建质量证据链，区分来料、过程、设备和检验规则造成的变化。",
    concepts: ["批次谱系", "抽样方案", "一次合格率", "返工与报废", "偏差调查", "放行规则"],
    evidence: ["来料检验", "过程参数", "首检终检", "返工与报废记录"],
    traps: ["抽样不代表整批", "返工后一次合格率被重算", "检验标准版本混用", "只分析最终检验"],
    codeKind: "sql-quality"
  },
  {
    key: "manufacturing-system",
    family: "manufacturing",
    match: /MES|SCADA|QMS|WMS|ERP|APS|设备物联网|制造系统|产线/i,
    label: "制造系统集成",
    focus: "围绕计划、工单、设备、批次、库存和质量事件定义系统边界，避免把计划状态误当成实际执行状态。",
    concepts: ["ISA-95 层级", "工单状态", "设备事件", "批次库存", "主数据映射", "接口补偿"],
    evidence: ["接口日志", "状态变更历史", "物料批次台账", "产量与库存对账"],
    traps: ["计划版本覆盖执行版本", "重复接口导致重复入库", "设备编码跨厂不一致", "工单关闭后仍产生报工"],
    codeKind: "yaml-manufacturing"
  },
  {
    key: "manufacturing-general",
    family: "manufacturing",
    match: /制造|生产|工厂|车间|产线|设备|工单|批次|库存|供应链|BOM|工艺|排产/i,
    label: "生产运营分析",
    focus: "从计划、执行、质量、库存和成本五个视角解释生产结果，确保每个指标都能回到工单、设备或批次证据。",
    concepts: ["计划达成", "节拍与瓶颈", "在制品", "物料齐套", "质量损失", "交付承诺"],
    evidence: ["排产版本", "工单报工", "设备状态", "库存与发运记录"],
    traps: ["产量与良品混淆", "计划变更未留版本", "在制品跨期归属错误", "库存单位不统一"],
    codeKind: "sql-manufacturing"
  },
  {
    key: "npl",
    family: "finance",
    match: /不良贷款率|不良率|逾期率|迁徙率|拨备覆盖率/i,
    label: "信贷资产质量指标",
    focus: "把五级分类、逾期账龄、重组、核销和迁徙率放在同一个时点与并表范围内，先搭变动桥再解释业务原因。",
    concepts: ["五级分类", "逾期天数", "重组观察期", "核销出表", "迁徙率", "拨备覆盖"],
    evidence: ["贷款余额快照", "分类版本", "逐笔逾期流水", "核销与处置审批"],
    traps: ["核销压低比率却不可比", "重组贷款提前恢复", "时点余额与平均余额混用", "并表范围变化未标注"],
    codeKind: "sql-finance"
  },
  {
    key: "finance-risk",
    family: "finance",
    match: /风险|资本|拨备|信用评级|流动性|偿付|杠杆|巴塞尔/i,
    label: "金融风险管理",
    focus: "先明确风险对象、违约或损失定义、观察期和资本口径，再检查模型或指标是否真正支持授信、处置和资本决策。",
    concepts: ["风险暴露", "违约定义", "风险缓释", "资本占用", "压力情景", "限额与预警"],
    evidence: ["合同与余额", "评级版本", "担保品估值", "风险分类和审批记录"],
    traps: ["风险暴露与余额混用", "评级时点穿越", "缓释重复计算", "情景变化与业务变化混在一起"],
    codeKind: "python-finance-risk"
  },
  {
    key: "finance-market",
    family: "finance",
    match: /市盈率|市净率|ROE|ROA|EBITDA|股息|beta|夏普|现金流|估值|债券|股票|基金|期权|期货|互换|套利|量化|净值/i,
    label: "金融指标与估值",
    focus: "同时写清分子、分母、价格日期、期间、年化因子和样本范围，避免把价格变化、会计变化与业务变化混为一谈。",
    concepts: ["估值日", "分子与分母", "年化规则", "复权与汇率", "可比样本", "风险调整"],
    evidence: ["行情快照", "财务科目", "分红与费用", "汇率和交易日历"],
    traps: ["负分母仍机械计算", "期末值与期间值混用", "复权口径不一致", "只做单点估值不看敏感性"],
    codeKind: "python-valuation"
  },
  {
    key: "finance-general",
    family: "finance",
    match: /银行|保险|证券|基金|信贷|贷款|存款|支付|金融|资产|负债|利率|汇率|承销|并购|保理|租赁/i,
    label: "金融业务与账务",
    focus: "沿客户、合同、账户、交易和账务事件建立可追溯链路，区分业务发生、账务入账和监管报送时间。",
    concepts: ["客户与合同", "账户余额", "交易流水", "账务日期", "并表范围", "监管口径"],
    evidence: ["业务单据", "会计分录", "账户快照", "监管报表勾稽"],
    traps: ["借贷不平", "冲正未成对", "合同版本被覆盖", "业务与财务日期混用"],
    codeKind: "sql-finance"
  },
  {
    key: "direct",
    family: "retail",
    match: /直通车|关键词|竞价|广告|投放|出价|搜索词|否词|质量分|ROI|CTR|CVR/i,
    label: "搜索广告与直通车",
    focus: "从关键词、匹配方式、出价、质量分、搜索词、否词、预算和创意八层拆解投放，不用一个 ROI 解释全部问题。",
    concepts: ["关键词意图", "匹配方式", "质量分", "出价与预算", "CTR/CVR", "搜索词与否词"],
    evidence: ["计划单元结构", "搜索词报表", "点击与支付归因", "退款和毛利"],
    traps: ["只看 ROI 不看曝光份额", "归因窗口重叠", "广泛匹配失控", "退款未扣回"],
    codeKind: "sql-advertising"
  },
  {
    key: "user-profile",
    family: "retail",
    match: /用户画像|标签体系|OneID|RFM|会员|用户分群|用户细分/i,
    label: "用户画像与标签",
    focus: "先解决身份映射、标签定义、离线在线一致、资格与授权，再讨论画像应用；标签数量不是治理成熟度。",
    concepts: ["身份映射", "标签口径", "有效期", "离线在线一致", "授权与频控", "效果实验"],
    evidence: ["身份关系图", "标签版本", "特征快照", "授权与触达日志"],
    traps: ["多账号重复计算", "标签过期仍生效", "离线在线口径不同", "越权用于敏感营销"],
    codeKind: "sql-profile"
  },
  {
    key: "retail-general",
    family: "retail",
    match: /零售|电商|平台|店铺|商品|订单|会员|复购|转化|活动|流量|履约|直播|供应链/i,
    label: "零售经营与增长",
    focus: "把流量、商品、用户、订单、履约和售后放到同一条经营链路，区分规模增长、结构变化和真实效率改善。",
    concepts: ["流量质量", "商品结构", "转化路径", "订单与退款", "履约成本", "复购贡献"],
    evidence: ["曝光点击日志", "订单支付明细", "退款售后单", "履约节点时间"],
    traps: ["曝光去重口径不一致", "GMV 未扣退款", "活动优惠重复", "自然增长被归因给策略"],
    codeKind: "sql-retail"
  },
  {
    key: "healthcare-general",
    family: "healthcare",
    match: /医疗|医院|患者|临床|检验|药品|医药|医保|问诊|影像|疾病|诊断|住院|门诊/i,
    label: "医疗业务与临床数据",
    focus: "围绕患者主索引、就诊、医嘱、检查检验、费用和随访建立时间链，始终把隐私与临床安全放在分析便利之前。",
    concepts: ["患者主索引", "就诊事件", "医嘱执行", "检验单位", "费用结算", "授权与留痕"],
    evidence: ["就诊号与患者号", "医嘱时间线", "检验参考区间", "费用与医保明细"],
    traps: ["患者重复计数", "临床与计费时间混用", "编码版本不一致", "敏感数据越权导出"],
    codeKind: "sql-healthcare"
  },
  {
    key: "spark",
    family: "engineering",
    match: /Spark|RDD|Shuffle|DAGScheduler|TaskScheduler|Executor|Partitioner|checkpoint|cache|persist/i,
    label: "Spark 执行与优化",
    focus: "从逻辑计划、依赖关系、Stage、Task、数据分布和资源使用定位问题，不用增加内存代替机制解释。",
    concepts: ["RDD 血缘", "宽窄依赖", "Stage 与 Task", "Shuffle", "数据倾斜", "容错与持久化"],
    evidence: ["执行计划", "Spark UI", "Task 分位数", "Spill 与 GC", "输入输出行数"],
    traps: ["只看总耗时", "参数越大越好", "广播对象过大", "结果变化未对账"],
    codeKind: "pyspark"
  },
  {
    key: "kafka",
    family: "engineering",
    match: /Kafka|消费积压|消费者组|Rebalance|分区副本|ISR|offset/i,
    label: "Kafka 消息链路",
    focus: "把生产速率、分区分布、消费速率、Rebalance、Broker 状态和下游反压放在同一时间轴，看到 Lag 先分层再扩容。",
    concepts: ["Topic 与 Partition", "生产速率", "消费速率", "Lag 与 offset", "Rebalance", "回放与死信"],
    evidence: ["分区 Lag", "消费者成员", "commit rate", "Broker 请求时延", "下游 Sink 耗时"],
    traps: ["只看总 Lag", "反复扩容触发 Rebalance", "消费成功但提交失败", "重放造成重复写入"],
    codeKind: "kafka-ops"
  },
  {
    key: "streaming",
    family: "engineering",
    match: /Flink|流处理|实时计算|水位线|watermark|CDC|变更数据捕获|实时链路/i,
    label: "实时流处理",
    focus: "明确事件时间、处理时间、水位线、状态、检查点和输出语义，再讨论吞吐与延迟。",
    concepts: ["事件时间", "水位线", "状态", "Checkpoint", "Exactly-once", "迟到与重放"],
    evidence: ["来源位点", "Checkpoint 记录", "端到端延迟", "重复与乱序样本", "Sink 事务日志"],
    traps: ["窗口结果随到达时间漂移", "状态无限增长", "重放导致重复输出", "只测吞吐不测端到端"],
    codeKind: "flink-sql"
  },
  {
    key: "scheduling",
    family: "engineering",
    match: /调度|DAG|依赖|补数|重跑|任务编排|Airflow|DolphinScheduler|Azkaban/i,
    label: "调度与依赖治理",
    focus: "把数据就绪、任务依赖、资源竞争、补数窗口和失败恢复一起设计，时间到不等于数据可用。",
    concepts: ["数据就绪", "任务依赖", "幂等", "补数", "并发控制", "失败重试"],
    evidence: ["依赖图", "分区就绪表", "重跑记录", "SLA 与告警", "资源队列"],
    traps: ["按时间触发不看数据", "依赖成环", "重试造成重复写入", "补数挤占在线资源"],
    codeKind: "yaml-schedule"
  },
  {
    key: "pipeline",
    family: "engineering",
    match: /ETL|ELT|数据管道|数据接入|增量|CDC|数据集成|数据同步|数据迁移/i,
    label: "数据接入与管道",
    focus: "从源端位点、Schema、增量策略、幂等、顺序、迟到和回滚控制数据管道，不只验证一次全量同步。",
    concepts: ["源端位点", "全量与增量", "Schema 演进", "幂等合并", "迟到与删除", "回滚"],
    evidence: ["同步位点", "Schema 版本", "主键去重结果", "迟到与删除样本", "源目标对账"],
    traps: ["删除事件丢失", "更新时间不单调", "Schema 变化静默丢字段", "全量重跑覆盖新数据"],
    codeKind: "python-cdc"
  },
  {
    key: "sql",
    family: "engineering",
    match: /SQL|窗口函数|TopN|连续活跃|行列转换|Join|聚合|查询优化/i,
    label: "SQL 查询与计算",
    focus: "先固定对象粒度、时间窗和去重规则，再选择窗口、聚合或连接方式；SQL 写通不等于口径正确。",
    concepts: ["对象粒度", "连接基数", "窗口定义", "空值与重复", "执行计划", "结果对账"],
    evidence: ["输入行数", "主键唯一性", "Join 前后计数", "窗口排序样本", "执行计划"],
    traps: ["一对多 Join 放大", "NULL 参与比较", "窗口排序不唯一", "只看结果示例不看基数"],
    codeKind: "sql"
  },
  {
    key: "service",
    family: "engineering",
    match: /数据服务|API|RESTful|GraphQL|接口|网关|服务部署|SLA|SLO|限流/i,
    label: "数据服务与部署",
    focus: "把契约、配置、迁移、密钥、就绪检查、金丝雀、回滚、容量和 SLO 作为一次发布整体验证。",
    concepts: ["接口契约", "配置与密钥", "数据库迁移", "就绪探针", "金丝雀", "回滚与 SLO"],
    evidence: ["OpenAPI 契约", "迁移版本", "密钥轮换记录", "灰度指标", "回滚演练"],
    traps: ["只验证容器启动", "配置硬编码", "迁移不可逆", "无限流和超时", "旧客户端未兼容"],
    codeKind: "yaml-service"
  },
  {
    key: "warehouse",
    family: "engineering",
    match: /数据仓库|数仓|数据湖|湖仓|ODS|DWD|DWS|ADS|分层|Iceberg|Delta|Hudi|存储/i,
    label: "数仓与湖仓架构",
    focus: "按业务过程、粒度、更新方式、查询模式和生命周期设计分层与存储格式，避免用组件名代替架构取舍。",
    concepts: ["分层边界", "事实与维度", "文件布局", "元数据", "增量更新", "生命周期"],
    evidence: ["血缘与复用率", "查询 P95", "文件大小分布", "分区与快照", "成本"],
    traps: ["跨层直读", "小文件过多", "分区键选择错误", "只迁存储不治理模型"],
    codeKind: "sql-lakehouse"
  },
  {
    key: "governance-ai",
    family: "ai",
    match: /AI治理|模型风险|可解释|模型卡片|数据卡片|AI合规|AI安全|训练数据|偏见|隐私计算/i,
    label: "AI 数据治理与风险",
    focus: "把任务、数据、模型、提示词、评测、权限和审计串成证据链，用风险等级决定人审、拒答和回滚。",
    concepts: ["数据授权", "训练与评测隔离", "模型卡", "风险切片", "人工接管", "审计证据"],
    evidence: ["数据版本", "模型与提示词版本", "高风险切片评测", "访问与输出审计"],
    traps: ["平均分掩盖高风险失败", "训练数据与线上时点穿越", "无人工接管", "只记录结果不记录版本"],
    codeKind: "python-ai-governance"
  },
  {
    key: "rag",
    family: "ai",
    match: /RAG|检索增强|向量数据库|Embedding|语义搜索|重排|混合检索/i,
    label: "RAG 检索增强生成",
    focus: "分别评测解析、切片、Embedding、召回、重排、引用和拒答，任何一层都不能用最终回答“看起来不错”替代。",
    concepts: ["解析", "切片", "Embedding", "召回", "重排", "引用", "拒答", "评测"],
    evidence: ["解析样本", "Chunk 边界", "Recall@K", "引用支持率", "无答案集", "权限过滤"],
    traps: ["固定长度切断表格", "旧版本仍被召回", "只测命中不测支持", "没有证据仍回答"],
    codeKind: "python-rag"
  },
  {
    key: "agent",
    family: "ai",
    match: /Agent|智能体|工具调用|多Agent|控制平面|沙箱/i,
    label: "Agent 控制与执行",
    focus: "先定义工具权限、计划边界、状态、人工审批、沙箱和审计，再讨论自主性；自动执行能力越强，失败成本越高。",
    concepts: ["任务规划", "工具契约", "权限", "状态机", "人工接管", "沙箱", "审计"],
    evidence: ["工具调用日志", "授权策略", "状态转换", "失败恢复", "人工审批记录"],
    traps: ["模型自行扩大权限", "工具参数未校验", "失败重试无上限", "审计只有最终答案"],
    codeKind: "python-agent"
  },
  {
    key: "mlops",
    family: "ai",
    match: /机器学习|MLOps|特征工程|模型评估|模型监控|推荐系统|深度学习|LLM|大模型|Prompt|微调/i,
    label: "机器学习与 MLOps",
    focus: "从任务、标签、特征时点、训练验证测试隔离、线上评估和模型回滚管理模型，不把离线分数当成业务效果。",
    concepts: ["任务与标签", "特征时点", "数据隔离", "基线", "线上评估", "漂移与回滚"],
    evidence: ["训练数据版本", "特征时间", "模型卡", "分片评估", "线上护栏"],
    traps: ["样本泄漏", "特征穿越", "只看平均 AUC", "模型升级不可回滚"],
    codeKind: "python-ml"
  },
  {
    key: "ai-general",
    family: "ai",
    match: /人工智能|大模型|生成式|多模态|自然语言|计算机视觉|AI\b/i,
    label: "AI 应用工程",
    focus: "先定义任务、输入输出、错误成本和人工接管，再选择模型、Prompt、检索或微调方案。",
    concepts: ["任务边界", "数据与样本", "基线", "评测", "安全", "成本与延迟"],
    evidence: ["需求样本", "基线结果", "高风险切片", "失败回放", "运行成本"],
    traps: ["先选模型后定义问题", "演示样本代替评测", "忽略拒答", "没有版本记录"],
    codeKind: "python-ai"
  },
  {
    key: "experiment",
    family: "analytics",
    match: /A.?B|实验|假设检验|因果|显著性|置信区间/i,
    label: "实验与因果推断",
    focus: "在实验前固定假设、主指标、分流单位、样本量和停止规则，实验后检查污染、多重比较与业务护栏。",
    concepts: ["实验单位", "随机分流", "主指标与护栏", "样本量", "多重比较", "效应大小"],
    evidence: ["分流日志", "样本比例", "实验前基线", "主指标与护栏", "污染检查"],
    traps: ["运行中反复偷看", "分流单位不一致", "只报显著性", "忽略长期效果"],
    codeKind: "sql-experiment"
  },
  {
    key: "funnel",
    family: "analytics",
    match: /漏斗|留存|复购|转化|用户路径|用户行为|归因|活跃|流失/i,
    label: "用户行为与漏斗",
    focus: "固定用户、会话、事件和归因窗口，保证漏斗各步使用同一批对象，并让结论落到可干预环节。",
    concepts: ["对象去重", "事件顺序", "观察窗口", "归因窗口", "分层贡献", "护栏指标"],
    evidence: ["事件日志", "会话重建", "渠道与人群", "实验或对照", "退款等护栏"],
    traps: ["各步分母不同却直接相除", "跨天路径丢失", "归因重复", "只做总体平均"],
    codeKind: "sql-funnel"
  },
  {
    key: "metric",
    family: "analytics",
    match: /指标|率|额|成本|收入|利润|规模|价值|效率|满意度|NPS|ARPU|GMV/i,
    label: "业务指标与口径",
    focus: "把指标写成对象、时间、分子、分母、排除项和版本六部分，并同时看规模、结构、质量和护栏。",
    concepts: ["对象与粒度", "分子分母", "时间窗", "排除项", "维度拆解", "变动桥"],
    evidence: ["指标定义", "明细样本", "基线与分布", "口径版本", "责任人确认"],
    traps: ["分母随筛选变化", "只看比率不看规模", "同比与环比混用", "规则变化未标注"],
    codeKind: "sql-metric"
  },
  {
    key: "analysis-method",
    family: "analytics",
    match: /分析|思维|框架|复盘|洞察|报告|可视化|看板|业务问题|业务流程/i,
    label: "分析方法与表达",
    focus: "先写决策问题和行动对象，再选择拆解、比较、实验或质性证据；图表只是最后表达，不是分析本身。",
    concepts: ["决策问题", "比较基线", "拆解结构", "证据等级", "行动阈值", "复盘"],
    evidence: ["业务记录", "指标基线", "分层样本", "访谈或现场", "行动日志"],
    traps: ["先做图再找问题", "相关当因果", "结论没有负责人", "只讲现象不讲取舍"],
    codeKind: null
  },
  {
    key: "data-governance",
    family: "governance",
    match: /数据治理|数据质量|血缘|元数据|主数据|数据标准|分类分级|数据安全|权限|隐私|合规|审计|成熟度|数据合约/i,
    label: "数据治理控制",
    focus: "把责任、标准、规则、问题处置、权限和变更影响做成可运行闭环，而不是只维护制度文档。",
    concepts: ["资产与责任", "标准", "质量规则", "血缘", "权限", "问题闭环"],
    evidence: ["资产登记", "规则结果", "问题时间线", "影响分析", "审批与审计"],
    traps: ["规则只有告警", "血缘覆盖不全", "责任人与系统负责人分离", "权限长期不复核"],
    codeKind: "yaml-governance"
  },
  {
    key: "project",
    family: "project",
    match: /项目|建设|迁移|落地|实施|验收|交付/i,
    label: "数据项目交付",
    focus: "围绕业务目标、范围、基线、里程碑、质量门禁、灰度和运营采用管理项目，上线不是验收终点。",
    concepts: ["目标与非目标", "基线与范围", "里程碑", "质量门禁", "灰度与回滚", "采用与复盘"],
    evidence: ["需求与变更", "测试与对账", "回滚演练", "使用日志", "运营复盘"],
    traps: ["范围持续扩张", "验收标准模糊", "只测成功路径", "上线后无运营"],
    codeKind: "yaml-project"
  }
];

const STRUCTURES = [
  {
    key: "diagnosis",
    lead: "反例与诊断",
    order: ["opening", "mechanism", "cases", "verification", "implementation", "operations"]
  },
  {
    key: "decision",
    lead: "决策与证据",
    order: ["opening", "decisions", "mechanism", "cases", "verification", "implementation", "operations"]
  },
  {
    key: "delivery",
    lead: "从方法到交付",
    order: ["opening", "mechanism", "implementation", "cases", "verification", "operations"]
  },
  {
    key: "review",
    lead: "复盘与验收",
    order: ["opening", "cases", "mechanism", "verification", "implementation", "operations"]
  }
];

function hash(value) {
  let result = 2166136261;
  for (const char of String(value)) {
    result ^= char.codePointAt(0);
    result = Math.imul(result, 16777619);
  }
  return result >>> 0;
}

function pick(items, profile, salt = "") {
  return items[hash(`${profile.relativePath}:${profile.title}:${salt}`) % items.length];
}

function table(headers, rows) {
  const clean = (value) => String(value).replaceAll("|", "\\|").replaceAll("\n", " ");
  return [
    `| ${headers.join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${row.map(clean).join(" | ")} |`)
  ].join("\n");
}

function fence(language, value) {
  return `\`\`\`${language}\n${value.trim()}\n\`\`\``;
}

function list(items) {
  return items.map((item) => `- ${item}`).join("\n");
}

function oneLine(value) {
  return String(value).replace(/\s+/g, " ").replaceAll("*/", "* /").trim();
}

function mechanismHeaders(family) {
  const variants = {
    modeling: ["建模节点", "必须先固定的语义", "可审计模型产物", "语义失真的停止条件"],
    engineering: ["链路阶段", "工程动作与输入输出", "运行或变更证据", "异常出口与恢复动作"],
    finance: ["业务或账务环节", "口径确认动作", "可复核金融证据", "差异升级条件"],
    manufacturing: ["生产或质量环节", "现场确认动作", "时间与批次证据", "停线或隔离条件"],
    retail: ["用户或交易阶段", "运营判断动作", "可回查经营证据", "策略停止条件"],
    healthcare: ["诊疗或管理环节", "临床与数据核对动作", "可追溯医疗证据", "安全或质控出口"],
    governance: ["治理控制点", "责任与规则动作", "审计证据", "门禁失败处理"],
    analytics: ["决策分析阶段", "假设与口径动作", "分析证据", "结论停止条件"],
    ai: ["模型或数据阶段", "评测与控制动作", "可复核模型证据", "上线阻断条件"],
    project: ["交付里程碑", "范围与实施动作", "验收证据", "变更或回滚出口"],
    career: ["求职行动阶段", "候选人动作", "能力证据", "需要补证的信号"],
    learning: ["学习阶段", "刻意练习动作", "学习产物", "停止或补基础条件"],
    industry: ["业务运行环节", "现场判断动作", "经营与数据证据", "异常处置出口"]
  };
  return variants[family] || variants.industry;
}

const WORKBENCH_LENSES = {
  modeling: {
    decisionQuestion: "业务语义、粒度定义和历史维度还没有形成可评审的模型契约",
    options: [
      ["先补概念模型与业务过程", "业务事件、事实粒度和分析问题仍有争议", "物理表开发会延后", "业务负责人能逐条解释事实表一行代表什么"],
      ["先做逻辑模型评审", "业务对象已清楚，但维度和历史规则尚未统一", "需要额外评审与原型验证", "关键维度、键和 SCD 规则经上下游共同签字"],
      ["渐进物理建模", "核心粒度稳定，剩余问题可在受控范围验证", "可能产生阶段性返工", "模型契约、质量门禁和回滚版本同时发布"]
    ],
    verificationHeaders: ["模型检查层", "复核对象", "通过与复算方式", "必须阻断的情况"],
    verificationLabels: ["业务过程与事实粒度", "维度键与历史有效期", "事实可加性与指标口径", "模型契约与下游消费"],
    implementationLabels: ["抽取一条真实业务过程", "编写概念与逻辑模型卡", "用最小事实表验证粒度", "做维度历史和下游影响回放"],
    operationHeaders: ["模型治理项", "固定动作", "审计证据", "升级或停用条件"],
    operationLabels: ["模型契约", "粒度与键", "维度历史", "变更与消费"]
  },
  engineering: {
    decisionQuestion: "问题究竟来自数据契约、计算资源、依赖编排还是发布机制",
    options: [
      ["先修输入契约与幂等", "输入分区、schema 或重复执行结果不稳定", "新功能上线会变慢", "同一输入连续重跑结果一致"],
      ["先做分层定位与容量验证", "数据语义稳定，但长尾、延迟或资源成本异常", "需要可观测性和压测投入", "瓶颈定位到阶段、分区或资源队列"],
      ["先做灰度发布与恢复演练", "核心链路已稳定，风险集中在变更影响", "需要维护新旧版本并行成本", "回滚、重放和对账均已演练"]
    ],
    verificationHeaders: ["链路控制点", "观察指标", "通过与复算方式", "异常出口"],
    verificationLabels: ["输入契约与依赖", "计算分区与资源", "输出质量与守恒", "发布、回滚与重放"],
    implementationLabels: ["冻结输入版本和失败样本", "建立可重复执行的最小任务", "补齐延迟、质量和成本监控", "完成回滚、重放与下游对账"],
    operationHeaders: ["运行控制", "监控与处置动作", "保留证据", "升级或停止条件"],
    operationLabels: ["新鲜度与积压", "资源与长尾", "质量与重复写入", "变更与恢复"]
  },
  finance: {
    decisionQuestion: "差异来自客户与合同范围、业务时点、风险分类，还是核销处置和并表调整",
    options: [
      ["先统一对象与快照", "客户、合同、账户或并表范围不一致", "短期无法直接优化指标", "分子分母能在同一时点复算"],
      ["先修分类与处置追溯", "范围一致，但五级分类、重组、核销或回收链断", "需要业务和风险共同确认规则", "每笔余额变化可拆到分类、处置和还款事件"],
      ["再做策略或报表优化", "对象、时点和分类规则已稳定", "错误口径可能被更快传播", "监管、会计和管理口径分别通过复核"]
    ],
    verificationHeaders: ["金融核对层", "关键样本", "通过与复算方式", "风险升级条件"],
    verificationLabels: ["客户合同与并表范围", "业务日期与账务日期", "余额分类与风险处置", "报表披露与调整审批"],
    implementationLabels: ["冻结同一报告日快照", "建立合同账户借据关系", "拆分新增下迁处置与核销", "完成监管会计管理三口径对账"],
    operationHeaders: ["风险运行项", "日常控制动作", "审计证据", "升级或暂停条件"],
    operationLabels: ["快照与并表范围", "分类迁徙与处置", "对账与调整项", "口径版本与披露"]
  },
  manufacturing: {
    decisionQuestion: "现场差异来自设备时间、工单批次、质量状态，还是计划参数和采集口径",
    options: [
      ["先校准设备与工单时间轴", "停机、运行、报工和质量记录无法按同一班次对齐", "需要现场核对和补录", "设备、工单、批次可按时间连续回放"],
      ["先修批次与质量追溯", "时间轴稳定，但来料、过程与检验记录断链", "需要跨 MES、QMS、WMS 协同", "任意不良批次可回到工单、设备和来料批次"],
      ["再扩产线分析与优化", "核心追溯稳定，瓶颈已定位到明确环节", "局部优化可能转移瓶颈", "产量、质量、停机和单位成本护栏同时通过"]
    ],
    verificationHeaders: ["现场核对层", "关键对象", "通过与复算方式", "停线或隔离条件"],
    verificationLabels: ["班次设备与状态时间", "工单产量与报工", "批次质量与返工", "来料发运与追溯"],
    implementationLabels: ["选择一个班次和一条产线", "对齐设备工单与批次时间轴", "验证产量停机和质检守恒", "完成异常隔离与回放演练"],
    operationHeaders: ["现场运行项", "班组动作", "留存证据", "停线或升级条件"],
    operationLabels: ["设备时钟与状态", "工单与批次", "产量与质量守恒", "参数版本与异常闭环"]
  },
  retail: {
    decisionQuestion: "变化来自用户结构、流量质量、归因口径、交易履约，还是策略长期副作用",
    options: [
      ["先统一身份与交易口径", "用户、订单、退款和渠道归属无法稳定关联", "活动上线会延后", "同批用户和订单可在明细层复算"],
      ["先做小流量策略实验", "对象与口径稳定，但增量效果仍不确定", "需要对照组和观察窗口", "主指标、退款、投诉和长期价值同时可比较"],
      ["扩大策略或投放", "增量证据稳定且护栏没有恶化", "错误可能被规模化放大", "分渠道、分人群和分商品结构均通过复核"]
    ],
    verificationHeaders: ["经营核对层", "关键分组", "通过与复算方式", "暂停策略条件"],
    verificationLabels: ["用户身份与资格", "流量来源与归因", "订单退款与履约", "增量、成本与长期价值"],
    implementationLabels: ["冻结活动资格与归因窗口", "建立用户订单履约明细基线", "设计对照和分群评估", "设置预算、退款与投诉护栏"],
    operationHeaders: ["策略运行项", "运营动作", "复盘证据", "关停或升级条件"],
    operationLabels: ["人群资格与频控", "预算流量与归因", "退款履约与投诉", "增量与长期价值"]
  },
  healthcare: {
    decisionQuestion: "问题来自患者主索引、临床时点、诊疗流程、费用结算，还是权限与质控",
    options: [
      ["先统一患者就诊主索引", "患者、就诊、医嘱或费用对象重复或错配", "分析范围会暂时缩小", "同一患者跨院区与就诊可稳定回溯"],
      ["先核对临床与结算时间线", "对象清楚，但医嘱、执行、报告和计费时点混乱", "需要临床与信息部门共同核验", "关键诊疗事件顺序和费用明细可逐项对应"],
      ["再做质量效率优化", "主索引和时间线稳定，指标可复算", "可能将管理压力错误转移到科室", "临床质量、费用、隐私和患者体验护栏同时通过"]
    ],
    verificationHeaders: ["医疗核对层", "关键记录", "通过与复算方式", "安全或质控出口"],
    verificationLabels: ["患者主索引与就诊", "医嘱执行与报告时间", "诊断费用与医保结算", "权限、隐私与质量事件"],
    implementationLabels: ["选择一个科室和一类就诊", "建立患者就诊事件时间线", "对账医嘱执行与费用记录", "完成权限审计和临床复核"],
    operationHeaders: ["运行控制项", "科室与管理动作", "审计证据", "暂停使用或质控条件"],
    operationLabels: ["患者主索引", "临床时间与报告", "费用医保与拒付", "权限隐私与质量"]
  },
  governance: {
    decisionQuestion: "问题应优先落在资产责任、标准血缘、质量门禁，还是权限和变更审计",
    options: [
      ["先补资产责任与血缘", "关键资产没有所有者、口径或消费关系", "治理平台建设会变慢", "关键字段可追到系统、任务、报表和责任人"],
      ["先把规则接入流程门禁", "资产与责任已明确，但规则只告警不拦截", "可能影响现有发布效率", "高风险问题能在发布或消费前阻断"],
      ["再扩治理覆盖范围", "核心域已形成闭环，问题复发率下降", "治理形式化风险上升", "采用率、复发率和审计证据同时改善"]
    ],
    verificationHeaders: ["治理控制层", "检查对象", "通过证据", "门禁或审计出口"],
    verificationLabels: ["资产责任与术语", "标准血缘与接口", "质量规则与问题闭环", "权限用途与变更审计"],
    implementationLabels: ["选择一个高风险指标或资产", "补齐所有者口径与血缘", "把一条质量规则接入发布门禁", "演练问题升级与审计导出"],
    operationHeaders: ["治理运行项", "责任动作", "审计证据", "升级或例外条件"],
    operationLabels: ["责任与术语", "标准血缘变更", "质量与问题复发", "权限用途与到期"]
  },
  analytics: {
    decisionQuestion: "结论差异来自问题定义、对象与分母、分层结构、实验偏差，还是行动没有闭环",
    options: [
      ["先重写决策问题与口径", "使用者和行动不清楚，指标无法支持选择", "暂时无法给出漂亮结论", "对象、时间、分母、排除项与负责人明确"],
      ["先做分层和反例分析", "总体方向清楚，但不同人群或渠道表现相反", "需要更多样本与拆解", "关键分层能解释总体变化且不违反业务守恒"],
      ["再推动实验或策略", "观察性证据稳定，因果关系仍需验证", "实验成本和机会成本上升", "主指标、护栏和长期效果均有对照"]
    ],
    verificationHeaders: ["分析证据层", "拆分维度", "通过与复算方式", "停止解释的条件"],
    verificationLabels: ["决策问题与对象", "分母基线与分层", "实验归因与显著性", "行动采用与护栏"],
    implementationLabels: ["写出一个真实决策与备选行动", "固定对象时间分母和排除项", "完成总量分层与反例复算", "记录行动、结果和下一次复核"],
    operationHeaders: ["决策运行项", "业务动作", "观察证据", "回退或重做条件"],
    operationLabels: ["问题与口径", "分层与异常", "实验与因果", "行动与长期效果"]
  },
  ai: {
    decisionQuestion: "瓶颈来自任务与数据、检索或特征、模型能力，还是安全评估与上线控制",
    options: [
      ["先建立失败样本与评测集", "任务边界和成功标准不清楚", "模型迭代速度会暂时变慢", "正常、边界、越权和拒答样本均可重复评测"],
      ["先修检索特征或提示链路", "评测已稳定，错误集中在证据、时点或上下文", "需要版本化数据和提示词", "召回、引用、时点和高风险切片均有解释"],
      ["再做模型或规模扩展", "基础链路已通过，瓶颈明确落在模型能力或容量", "成本、延迟和回退风险上升", "模型、提示词、权限和成本均可灰度回滚"]
    ],
    verificationHeaders: ["AI 控制层", "评测对象", "通过与复算方式", "上线阻断条件"],
    verificationLabels: ["任务边界与数据授权", "召回特征与上下文", "模型输出与高风险切片", "延迟成本与安全回退"],
    implementationLabels: ["固定任务与拒答边界", "建立版本化评测集和基线", "按切片比较检索或模型方案", "完成权限、成本与灰度回退演练"],
    operationHeaders: ["模型运行项", "监控与控制动作", "留档证据", "降级或停用条件"],
    operationLabels: ["输入漂移与授权", "召回引用与幻觉", "高风险切片与人工修订", "版本成本与回退"]
  },
  project: {
    decisionQuestion: "问题主要在目标范围、关键依赖、质量迁移，还是上线后的采用和运营",
    options: [
      ["先冻结目标与范围", "业务目标、非目标和验收人不清", "交付内容会减少", "目标、范围、基线和退出条件书面确认"],
      ["先打通关键依赖与试点", "范围稳定，但上游、迁移或集成风险高", "全面上线时间会延后", "关键链路在真实样本和故障场景下可运行"],
      ["再灰度迁移与运营", "试点可对账且回滚可控", "需要双跑和运营投入", "采用率、质量、成本与旧系统退出条件达成"]
    ],
    verificationHeaders: ["交付控制层", "验收对象", "通过证据", "暂停或回滚条件"],
    verificationLabels: ["目标范围与责任人", "依赖里程碑与变更", "质量迁移与回滚", "采用运营与旧系统退出"],
    implementationLabels: ["确认一个可验收的业务决策", "列出非目标与关键依赖", "完成小范围双跑和对账", "演练回滚并交接运营"],
    operationHeaders: ["项目运行项", "例会与责任动作", "验收证据", "暂停或退出条件"],
    operationLabels: ["范围与变更", "依赖与里程碑", "质量迁移与回滚", "采用价值与退出"]
  },
  career: {
    decisionQuestion: "当前最需要补的是岗位理解、核心能力、项目证据、表达材料，还是投递反馈",
    options: [
      ["先拆目标岗位任务", "岗位方向宽泛，材料无法对应真实工作", "短期产出数量会减少", "目标岗位、关键任务和能力差距可以逐条对应"],
      ["先做一个代表项目", "方向清楚，但缺少能深挖的证据", "需要投入完整实践周期", "项目可复跑、可解释取舍并能复盘失败"],
      ["再做表达和投递实验", "项目证据稳定，问题转为面试表达和匹配", "会收到真实拒绝反馈", "每轮反馈都能定位到材料或能力改动"]
    ],
    verificationHeaders: ["能力证据层", "检查对象", "通过标准", "需要回退补证的情况"],
    verificationLabels: ["岗位任务与个人边界", "方法与项目证据", "结果口径与失败复盘", "材料表达与面试反馈"],
    implementationLabels: ["选一个目标岗位和关键任务", "整理项目对象与个人决策", "补齐指标口径和失败记录", "做模拟追问并迭代材料"],
    operationHeaders: ["求职运行项", "每周动作", "证据", "调整方向条件"],
    operationLabels: ["岗位筛选", "项目打磨", "投递面试", "反馈复盘"]
  },
  learning: {
    decisionQuestion: "当前应补基础概念、最小交付、异常处理，还是业务表达和独立负责",
    options: [
      ["先补对象与基础链路", "术语能背但无法解释业务对象和输入输出", "项目推进会变慢", "能在陌生小场景复述对象、时间和失败边界"],
      ["先完成最小闭环", "基础可解释，但没有独立交付证据", "暂时不扩展工具广度", "一个项目从输入到验证可完整复跑"],
      ["再增加异常和表达", "正常路径已掌握，失败样本和复盘不足", "需要同伴评审与外部反馈", "能定位失败、说明取舍并让他人复现"]
    ],
    verificationHeaders: ["学习证据层", "练习对象", "通过标准", "停止扩展的条件"],
    verificationLabels: ["概念与对象", "最小任务与产物", "异常与复盘", "讲解与迁移"],
    implementationLabels: ["选一个真实小问题", "做最小可复跑产物", "故意制造并修复失败", "讲解、获得反馈并安排下一轮"],
    operationHeaders: ["学习运行项", "固定节奏", "产物证据", "调整计划条件"],
    operationLabels: ["输入与问题", "刻意练习", "失败与反馈", "复盘与晋级"]
  },
  industry: {
    decisionQuestion: "业务对象、运行流程、指标口径和行动责任中，哪一层还没有被证据支撑",
    options: [
      ["先补对象与流程事实", "行业术语很多，但实际业务事件和责任边界不清", "会推迟模型和报表开发", "一线人员能按事件链复述对象、状态与例外"],
      ["先统一指标与基线", "流程已清楚，但同名指标存在多套口径", "需要跨部门确认和版本管理", "指标能在明细层复算并解释排除项"],
      ["先做小范围决策试点", "对象与指标稳定，仍需验证行动价值", "需要试点和人工兜底", "同一批样本在试点前后可对账且副作用可控"]
    ],
    verificationHeaders: ["业务证据层", "检查对象", "通过标准", "停止或升级条件"],
    verificationLabels: ["对象与事件链", "流程时间与状态", "指标口径与对账", "行动采用与副作用"],
    implementationLabels: ["选一个真实业务决策", "梳理对象事件与状态", "建立指标基线和样本", "试点行动并记录副作用"],
    operationHeaders: ["业务运行项", "固定动作", "证据", "升级或停止条件"],
    operationLabels: ["对象与流程", "指标与质量", "行动与采用", "风险与复盘"]
  }
};

function workbenchFor(plan) {
  return WORKBENCH_LENSES[plan.family] || WORKBENCH_LENSES.industry;
}

function conceptExplanation(profile, plan, concept, index) {
  const d = plan.definition;
  const objectA = d.objects[index % d.objects.length];
  const objectB = d.objects[(index + 1) % d.objects.length];
  const control = d.controls[index % d.controls.length];
  const risk = d.risks[index % d.risks.length];
  if (/设备综合效率|OEE/.test(profile.topic) && /设备/.test(concept)) {
    return `**${concept}**：在 OEE 中必须落到某一台设备、某一计划班次和某一工单，说明计划时间、实际运行、停机损失和有效产出如何对应；设备台账更新或工单切换不能覆盖原时段的损失记录。`;
  }
  if (/Kafka|消费积压|消费者组|Rebalance/i.test(profile.topic) && /消费者组/.test(concept)) {
    return `**${concept}**：要具体到哪个消费组、哪些成员、处理了哪些分区与 offset 区间，并记录组内再平衡前后的归属变化；只看总 Lag 无法判断是单分区热点、成员失联还是下游处理变慢。`;
  }
  if (/建模|事实表|维度模型/.test(profile.topic) && /事实粒度/.test(concept)) {
    return `**${concept}**：先回答事实表一行代表哪个不可再分的业务事件，例如一次下单、一次支付或一次库存移动；若一个粒度混入多个事件，金额、数量和维度关联都会失去可加性。`;
  }
  if (/不良贷款率/.test(profile.topic) && /分类|风险/.test(concept)) {
    return `**${concept}**：同一贷款要同时保留五级分类、逾期天数、重组状态、核销处置和规则版本，并说明观测期内何时上迁或下迁；迁徙率与不良率一起看，才能区分新增劣变、存量修复和出表影响。`;
  }
  const variants = [
    `**${concept}**：在“${profile.topic}”里，它不是孤立字段，而是连接${objectA}与${objectB}的判断依据。落地时要写清由${d.roles[index % d.roles.length]}确认，并以${control}作为可复核证据。`,
    `**${concept}**：先把它还原为${d.label}中的一个业务状态或控制点，再定义时间、粒度、责任人与版本。若${risk}出现，应停止使用当前结论。`,
    `**${concept}**：这项要素要能回答“哪个${objectA}在什么时间、因什么状态变化而影响了${d.metrics[index % d.metrics.length]}”。回答不了时，图表和代码都只是表面完整。`,
    `**${concept}**：建议同时保留对象级明细与汇总口径，让${d.roles[(index + 1) % d.roles.length]}能用${control}抽查。只保存最终指标，会让${risk}无法定位。`
  ];
  return pick(variants, profile, `concept-${index}-${concept}`);
}

function familyOf(profile) {
  const title = profile.topic;
  if (profile.kind === "resume") return "resume";
  if (profile.kind === "career") return "career";
  if (profile.kind === "learning") return "learning";
  if (/企业级建模|数据建模|维度建模|事实表|维度表|一致性维度|总线矩阵|Data Vault|雪花模型|星型模型/i.test(title)) return "modeling";
  if (/不良贷款率|逾期率|迁徙率|拨备覆盖率|市盈率|市净率|ROE|ROA|EBITDA|股息率|beta|夏普|现金流|估值|银行|保险|证券|基金|信贷|贷款|存款|支付|金融|资产|负债|利率|汇率|期货|期权|债券|股票|投资|资本/i.test(title)) return "finance";
  if (/设备|OEE|制造|生产|工厂|车间|产线|工单|批次|MES|SCADA|QMS|WMS|ERP|工艺|排产|质量|良率|返工|报废|库存/i.test(title)) return "manufacturing";
  if (/零售|电商|直通车|关键词|广告|投放|会员|复购|转化|GMV|客单|履约|商品|店铺|流量|用户画像|RFM|营销|直播/i.test(title)) return "retail";
  if (/医疗|医院|患者|临床|检验|药品|医药|医保|问诊|影像|疾病|诊断|住院|门诊/i.test(title)) return "healthcare";
  if (/RAG|检索增强|向量数据库|Embedding|语义搜索|重排|Agent|智能体|工具调用|机器学习|MLOps|大模型|LLM|Prompt|微调|模型评估|深度学习|多模态|推荐系统/i.test(title)) return "ai";
  if (profile.kind === "governance" || /治理|数据质量|血缘|元数据|主数据|数据标准|分类分级|安全|隐私|合规|权限|审计|成熟度|数据合约/i.test(title)) return "governance";
  if (profile.kind === "engineering" || /Spark|Kafka|Flink|SQL|数据仓库|数据湖|湖仓|调度|ETL|CDC|API|数据服务|架构|Kubernetes|云原生|缓存|流处理|批处理/i.test(title)) return "engineering";
  if (profile.kind === "project") return "project";
  if (profile.kind === "analytics" || /分析|指标|漏斗|留存|实验|转化|看板|归因|用户行为|经营/i.test(title)) return "analytics";
  return "industry";
}

function subdomainOf(profile, family) {
  const direct = SUBDOMAIN_RULES.find((rule) => rule.family === family && rule.match.test(profile.topic));
  if (direct) return direct;
  if (family === "modeling") {
    return {
      key: "modeling",
      family,
      label: "企业级数据建模",
      focus: "从业务对象、事实粒度、一致性维度、缓慢变化维度和模型契约出发，让模型跨系统、跨时间仍能解释。",
      concepts: ["概念模型", "逻辑模型", "物理模型", "事实粒度", "一致性维度", "SCD"],
      evidence: ["业务对象清单", "粒度说明", "维度有效期", "模型评审记录"],
      traps: ["跳过逻辑模型直接建表", "事实粒度混用", "维度历史被覆盖", "破坏性变更未做影响分析"],
      codeKind: "yaml-model"
    };
  }
  return {
    key: family,
    family,
    label: FAMILY_DEFINITIONS[family]?.label || "跨行业数据实践",
    focus: pick([
      `把“${profile.topic}”还原到具体对象、业务事件、指标口径和失败场景，确保结论能被一线人员使用。`,
      `围绕“${profile.topic}”先建立对象与时间边界，再用分层证据解释变化，最后形成可执行动作。`,
      `“${profile.topic}”的价值取决于业务条件、数据证据和责任边界，不能只停留在术语定义。`
    ], profile, "fallback-focus"),
    concepts: FAMILY_DEFINITIONS[family]?.objects || ["业务对象", "事件", "状态", "指标", "责任"],
    evidence: FAMILY_DEFINITIONS[family]?.controls || ["主键", "时间", "版本", "审批", "样本"],
    traps: FAMILY_DEFINITIONS[family]?.risks || ["对象不清", "时间混用", "版本不可追溯", "没有验收"],
    codeKind: {
      finance: "sql-finance",
      manufacturing: "sql-manufacturing",
      retail: "sql-retail",
      healthcare: "sql-healthcare",
      governance: "yaml-governance",
      project: "yaml-project",
      engineering: "sql-lakehouse"
    }[family] || null
  };
}

function industryDefinition() {
  return {
    label: "行业与业务分析",
    roles: ["业务负责人", "一线运营", "产品经理", "数据分析师", "财务与风控"],
    objects: ["客户或用户", "产品", "交易或事件", "合同或订单", "资源", "结果"],
    systems: ["业务系统", "交易系统", "财务系统", "数据仓库", "报表或看板"],
    stages: ["需求产生", "业务受理", "履约或交付", "结算", "服务与复盘"],
    metrics: ["规模", "收入", "成本", "转化", "效率", "风险"],
    risks: ["对象边界不清", "业务时间与系统时间混用", "收入和成本确认口径不同", "只看总量忽略结构", "结论没有行动对象"],
    controls: ["对象主键稳定", "事件时间可追溯", "金额与单据对账", "指标定义版本化", "关键结论有样本"],
    cases: [
      ["某区域服务企业运营分析组", "业务量增长但利润下降，规模、价格和成本口径无法对齐"],
      ["某平台商业分析团队", "用户增长与收入增长方向相反，渠道结构和客户价值发生变化"],
      ["某传统企业数字化团队", "业务报表与财务口径长期不一致，月末需要人工解释差异"],
      ["某连锁经营企业区域团队", "门店表现差异被总体平均值掩盖，实际受到商圈、阶段和产品结构影响"]
    ],
    sources: [
      ["OECD composite indicators handbook", "https://www.oecd.org/sdd/42495745.pdf"],
      ["Google Analytics measurement guidance", "https://support.google.com/analytics/answer/9355655"],
      ["NIST Big Data Interoperability Framework", "https://www.nist.gov/programs-projects/nist-big-data-interoperability-framework"]
    ]
  };
}

function planFor(profile) {
  const blueprint = resolveTopicBlueprint(profile);
  const family = blueprint.family;
  const definition = blueprint;
  const subdomain = {
    key: blueprint.key,
    family,
    label: blueprint.label,
    focus: blueprint.focus,
    concepts: blueprint.objects,
    evidence: blueprint.controls,
    traps: blueprint.risks,
    codeKind: blueprint.codeKind
  };
  const structure = STRUCTURES[hash(`${profile.relativePath}:${profile.title}:structure`) % STRUCTURES.length];
  return { family, definition, blueprint, subdomain, structure };
}

function sourceSection(profile, definition) {
  const checks = [
    "核对业务对象、时间字段和主键",
    "核对指标公式、分母和排除项",
    "核对状态版本、审批和回滚",
    "核对失败样本、责任人与停止条件",
    "核对适用范围与当前有效版本"
  ];
  const sourceLines = definition.sources.map(([name, url], index) => {
    const check = checks[(hash(`${profile.topic}:${name}:${index}`) + index) % checks.length];
    return `- [${name}](${url})｜用于“${profile.topic}”的${check}，不把来源中的通用结论直接替代本单位事实。`;
  }).join("\n");
  const noteVariants = [
    `“${profile.topic}”的公开资料只负责提供方法坐标，真正可用的结论仍要回到${definition.objects.slice(0, 3).join("、")}的原始记录、当前制度与授权范围。`,
    `阅读“${profile.topic}”材料时，先把版本、适用范围和前提条件抄下来，再用${definition.controls.slice(0, 3).join("、")}做一次反证；来源权威不等于适用于每个组织。`,
    `针对“${profile.topic}”，来源之间可能存在术语相同而口径不同的情况。应以${definition.metrics.slice(0, 3).join("、")}的实际定义和业务责任边界完成复核。`,
    `“${profile.topic}”的案例均为脱敏复合练习，展示的是${definition.stages.slice(0, 3).join("、")}中的判断顺序，不对应任何单一客户、员工或经营结果。`
  ];
  const note = pick(noteVariants, profile, "source-note");
  return `## ${profile.topic}的参考方法与公开资料

${sourceLines}

${note}`;
}

function openingSection(profile, plan) {
  const { definition, subdomain, family } = plan;
  const title = profile.topic;
  const lead = pick([
    `${title}真正要解决的不是“知道一个概念”，而是让${definition.roles.slice(0, 3).join("、")}在同一对象、同一时间和同一证据上作出决定。`,
    `讨论${title}时，最容易出现的错误是把它包装成一个通用工具或漂亮看板；实际工作里，它首先是一组需要被验证的业务边界。`,
    `${title}应被写成一条可执行链路：谁提出目标、什么事件触发、数据如何记录、异常如何阻断、结果由谁验收。`
  ], profile, "lead");
  return `# ${profile.title}

> [!abstract] ${subdomain.label}
> ${lead} ${subdomain.focus}

## ${plan.structure.key === "review" ? `先判断“${title}”是否值得信赖` : `${title}的对象、边界与决策`}

${lead}

${table(
    ["先固定什么", `“${title}”必须回答的问题`, "可验收证据"],
    [
      ["业务对象", `结果对应${definition.objects.slice(0, 4).join("、")}中的哪一个对象，是否会把不同粒度混在一起`, "对象清单、主键和至少 20 条样本"],
      ["时间", "采用事件发生、业务生效、账务入账、数据处理还是报告时点", "时间字段说明、跨期与迟到样本"],
      ["状态", `“${title}”涉及哪些状态变化，空值和撤销代表什么`, "状态字典、状态迁移记录与异常样本"],
      ["口径", `分子、分母、排除项、版本和适用范围是什么`, "口径卡、版本号与责任人签字"],
      ["行动", "谁会根据结果继续、阻断、修复、补数、调整策略或转人工", "行动日志与复核日期"]
    ]
  )}

${list(subdomain.concepts.slice(0, 6).map((concept, index) => conceptExplanation(profile, plan, concept, index)))}

> “${profile.topic}”的讨论必须落到${definition.objects.slice(0, 4).join("、")}及其时间、状态和证据上。${family === "career" || family === "learning" || family === "resume" ? "成长主题" : "业务主题"}一旦只剩口号或总览，就无法判断下一步该补证据、改流程还是停止。`;
}

function decisionSection(profile, plan) {
  const { definition, subdomain } = plan;
  const lens = workbenchFor(plan);
  const optionRows = lens.options.map(([option, condition, cost, pass], index) => [
    option,
    `${condition}；在“${profile.topic}”中重点核对${definition.objects[index % definition.objects.length]}与${definition.stages[index % definition.stages.length]}`,
    `${cost}；责任人为${definition.roles[index % definition.roles.length]}，需要准备${definition.controls[index % definition.controls.length]}`,
    `${pass}；用${subdomain.evidence[index % subdomain.evidence.length]}和${definition.metrics[index % definition.metrics.length]}共同判定`
  ]);
  const rejected = definition.risks.slice(0, 4).map((risk, index) => {
    const exit = index % 2 === 0
      ? `暂停当前版本，回到${definition.stages[index % definition.stages.length]}重新确认${definition.objects[index % definition.objects.length]}`
      : `缩小到${subdomain.evidence[index % subdomain.evidence.length]}可覆盖的样本，由${definition.roles[index % definition.roles.length]}签字后再恢复`;
    return `**否决信号 ${index + 1}：${risk}。** 对“${profile.topic}”而言，${exit}；不能用新增看板、参数或自动化绕过这个缺口。`;
  });
  return `## ${profile.topic}的路线选择

“${profile.topic}”真正需要拍板的不是“做不做”，而是${lens.decisionQuestion}。建议先用下面的路径比较会损失什么、需要谁负责，以及什么证据能让团队安全进入下一步。

${table(
    ["可选路径", "适用条件与本文对象", "代价与责任人", "进入下一阶段的条件"],
    optionRows
  )}

对“${profile.topic}”来说，三种路径不能并行无限展开。每轮只选一条主路径，并把${definition.controls[0]}、${definition.controls[1]}作为进入下一轮的硬条件；如果负责人无法说明${definition.metrics[0]}的分母或${definition.objects[0]}的时间边界，就说明当前选项还不成熟。

${list(rejected)}`;
}

function mechanismSection(profile, plan) {
  const { definition, subdomain } = plan;
  const mechanismLead = pick([
    `下面的链路以${definition.label}为背景。顺序不是固定流程图，而是一组检查点：每一步都要有输入、输出和失败出口。`,
    `要把${profile.topic}做成可复核结果，需要把${definition.label}中的业务动作、系统状态和责任记录串起来，而不是只画一张流程图。`,
    `在${definition.label}场景里，先确认每个环节的输入、输出与停止条件，再决定用什么系统承载。顺序错误会让后续计算失去业务含义。`,
    `下面从${definition.label}的实际交接点展开。每个环节都要说明证据在哪里、由谁确认，以及失败后如何回退。`
  ], profile, "mechanism-lead");
  return `## ${profile.topic}怎样从业务动作变成可信结果

${mechanismLead}

${table(
    mechanismHeaders(plan.family),
    definition.stages.map((stage, index) => [
      stage,
      `${definition.roles[index % definition.roles.length]}以${definition.objects[index % definition.objects.length]}为对象，确认${subdomain.concepts[index % subdomain.concepts.length]}及其输入、输出和异常状态`,
      `${subdomain.evidence[index % subdomain.evidence.length]}；同时留存${definition.systems[index % definition.systems.length]}中的时间、版本、批次和责任人`,
      index < 2
        ? `出现${subdomain.traps[index % subdomain.traps.length]}时停止流转，由${definition.roles[(index + 1) % definition.roles.length]}确认边界后再继续`
        : `隔离受影响的${definition.objects[(index + 1) % definition.objects.length]}，修复后与稳定版本并行对账并通知下游`
    ])
  )}

对于“${profile.topic}”，需要特别把${subdomain.concepts.slice(0, 4).join("、")}分开记录。把它们混成一个字段，后续即使更换计算引擎或增加算力，也无法恢复业务语义。`;
}

function caseSection(profile, plan) {
  const { definition, subdomain } = plan;
  const sourceCases = definition.cases.length
    ? definition.cases
    : [["某跨部门业务团队", `团队正在梳理“${profile.topic}”，但现有结果无法回到原始业务记录`]];
  const seed = hash(`${profile.relativePath}:${profile.title}:cases`);
  const sourceStart = seed % sourceCases.length;
  const caseCount = Math.max(2, Math.min(4, 2 + (seed % 3)));
  const styles = ["现场排障", "方案评审", "反例复盘", "上线验证", "指标争议", "跨团队交接"];
  const triggers = [
    `季度复盘时，${definition.roles[0]}发现“${profile.topic}”的结论与${definition.systems[0]}中的一线记录相反，要求在${definition.metrics[0]}口径不变的情况下解释差异`,
    `一次例行核对中，${definition.systems[0]}与${definition.systems[1]}对“${profile.topic}”给出了不同的${definition.metrics[0]}，但两张任务状态页都显示成功`,
    `“${profile.topic}”的试点版本在演示样本上通过，切换到真实${definition.objects[0]}后出现无法解释的分布，${definition.roles[1]}决定先冻结发布`,
    `临近月结，${definition.roles[1]}要求围绕“${profile.topic}”临时增加分组和重算，同时必须说明历史${definition.objects[1]}是否受${subdomain.concepts[0]}变化影响`,
    `“${profile.topic}”完成一次版本升级后，业务仍能打开报表，但${subdomain.evidence[1]}与上一版无法逐条对应，${definition.roles[2]}开始质疑结果`,
    `新接入的${definition.systems[2]}改变了字段更新时间，${definition.roles[2]}发现按“${profile.topic}”原规则筛选会漏掉一部分${definition.objects[1]}`
  ];
  const findings = [
    `把“${profile.topic}”按${definition.objects[0]}、${definition.objects[1]}和${definition.objects[2]}拆回明细后，发现${subdomain.concepts[0]}同时混入了业务发生、系统生效和人工补录三个时间`,
    `“${profile.topic}”的${subdomain.concepts[0]}在汇总层取最新状态，明细层却保留历史状态，导致同一批${definition.objects[0]}在两层出现不同${definition.metrics[0]}`,
    `“${profile.topic}”的失败样本集中在${subdomain.traps[0]}与${subdomain.traps[1]}，试点数据却只保留了顺利完成的${definition.objects[0]}，因此无法外推到生产`,
    `${definition.systems.slice(0, 3).join("、")}都认为“${profile.topic}”在自己的环节已经完成，但没有任何系统保存${definition.objects[1]}的交接状态、责任人和失败原因`,
    `“${profile.topic}”的结果偏移不只来自业务波动，${subdomain.concepts.slice(1, 4).join("、")}的版本差异共同改变了${definition.metrics.slice(1, 4).join("、")}`,
    `${definition.objects[0]}数量增长后，“${profile.topic}”的异常记录被重试和人工补录覆盖；表面成功率没有下降，可追溯的${subdomain.evidence[0]}反而减少`
  ];
  const actions = [
    `冻结“${profile.topic}”的${definition.metrics[0]}当前口径，先按${definition.objects[0]}主键回查${subdomain.evidence[0]}和${subdomain.evidence[1]}，再沿${definition.stages[0]}到${definition.stages.at(-1)}重建事件时间线`,
    `把“${profile.topic}”中的${subdomain.concepts[0]}改写成带版本和生效区间的规则，对新旧${definition.objects[0]}抽样，由${definition.roles[0]}确认哪些差异属于合理重述`,
    `围绕“${profile.topic}”的${definition.stages.slice(0, 3).join("、")}补做故障注入，分别保留正常、迟到、重复、撤回和权限不足样本，并记录每次结果`,
    `为${definition.systems.slice(0, 3).join("、")}建立“${profile.topic}”共同交接单：输入版本、处理状态、输出数量、责任人、失败原因和回滚点`,
    `把“${profile.topic}”拆成对象、时间、状态、计算和行动五层核对；任一层无法对齐时，停止把结果用于考核或自动决策`,
    `选择一个边界清楚的${definition.label}环节先修复“${profile.topic}”，在影子链路并行比较金额、数量、对象数和${definition.metrics.slice(1, 4).join("、")}`
  ];
  const acceptances = [
    `只使用留档的${subdomain.evidence.slice(0, 3).join("、")}，另一位同事就能复算“${profile.topic}”的同一结果，并说明每项差异来自${definition.objects[0]}的哪次状态变化`,
    `“${profile.topic}”的${definition.metrics[0]}可展开到分子、分母、对象数和版本；${definition.roles[2]}确认修复没有静默排除异常${definition.objects[1]}`,
    `故障回放时，“${profile.topic}”至少能发现${subdomain.traps[0]}和${subdomain.traps[1]}；主指标改善后，${definition.metrics.slice(1, 4).join("、")}没有恶化`,
    `“${profile.topic}”的每个交接点都能追到任务、处理时间、责任人和输出证据，${definition.roles.slice(0, 3).join("、")}对边界作出一致解释`,
    `“${profile.topic}”的新旧版本在同一${definition.objects[0]}快照上完成复核，差异清单经业务确认；未知版本或${definition.controls[0]}失败时可以立即回滚`,
    `“${profile.topic}”的正常、边界和人工修正样本同时通过，${definition.controls.slice(0, 3).join("、")}均有可下载或可查询的证据`
  ];
  const lessons = [
    `这个“${profile.topic}”现场说明，先要让${definition.objects[0]}和${definition.objects[1]}回到同一语义空间，再讨论工具、性能和展示方式`,
    `如果“${profile.topic}”中的${subdomain.traps[0]}仍存在，增加维度、扩容或自动化只会让${definition.metrics[0]}的错误更快传播`,
    `“${profile.topic}”的正确处置不是多加一条告警，而是把${subdomain.evidence.slice(0, 3).join("、")}纳入门禁，并指定${definition.roles[0]}负责异常升级`,
    `“${profile.topic}”跨团队协作需要共同验收样例；${definition.controls.slice(-3).join("、")}必须能在${definition.systems[1]}中查到，而不是只写在说明文档里`,
    `“${profile.topic}”的指标争议通常同时包含业务变化、口径变化和质量问题，处理顺序应是先守恒、再解释、最后讨论责任`,
    `“${profile.topic}”规模增长后仍要保留${definition.objects[0]}级证据，否则${definition.metrics.slice(0, 3).join("、")}的改善无法与真实业务改善区分`
  ];
  const notes = [
    `以下“${profile.topic}”场景按${definition.label}的常见工作记录重组，组织名称和数字只用于说明判断过程。`,
    `下列“${profile.topic}”案例均经过脱敏和合并，重点是${subdomain.evidence.slice(0, 3).join("、")}，不用于指代任何单一企业。`,
    `“${profile.topic}”的案例借鉴公开方法与常见业务边界，不把示例金额、比例或组织关系当成真实经营事实。`,
    `为避免把演示当成生产，“${profile.topic}”的以下现场同时保留边界样本、责任人和回滚证据，名称与结果均为复合示例。`
  ];
  const cases = Array.from({ length: caseCount }, (_, index) => {
    const source = sourceCases[(sourceStart + index) % sourceCases.length];
    const offset = seed + index * 7;
    return {
      source,
      style: styles[(offset + index * 3) % styles.length],
      trigger: triggers[(offset + index * 2) % triggers.length],
      finding: findings[(offset + index * 3) % findings.length],
      action: actions[(offset + index * 4) % actions.length],
      acceptance: acceptances[(offset + index * 5) % acceptances.length],
      lesson: lessons[(offset + index * 6) % lessons.length]
    };
  });
  return `## ${profile.topic}：${caseCount}个工作现场

> ${pick(notes, profile, "case-note")}

${cases.map((item, index) => {
    const lead = index === 0
      ? `### 案例 ${index + 1}｜${item.source[0]}：先还原问题`
      : index === 1
        ? `### 案例 ${index + 1}｜${item.source[0]}：把证据放回时间线`
        : index === 2
          ? `### 案例 ${index + 1}｜${item.source[0]}：反例如何改变方案`
          : `### 案例 ${index + 1}｜${item.source[0]}：上线前最后一道门`;
    const blocks = [
      `**${item.style}。** ${item.source[1]}。${item.trigger}。`,
      `**第一次核对。** ${item.finding}。这时先不要用“总体正常”结束讨论，而要抽查${definition.objects[(index + 1) % definition.objects.length]}、${definition.objects[(index + 2) % definition.objects.length]}及其失败记录。`,
      `**处理。** ${item.action}。涉及${definition.controls[(seed + index) % definition.controls.length]}的决定由${definition.roles[(seed + index) % definition.roles.length]}确认，并保留变更前后快照。`,
      `**验收。** ${item.acceptance}。`,
      `**复盘。** ${item.lesson}。还需补充${subdomain.evidence[(index + 1) % subdomain.evidence.length]}与${subdomain.evidence[(index + 2) % subdomain.evidence.length]}的日常监控。`
    ];
    if (item.style === "反例复盘") blocks.splice(1, 2, `**为什么误判。** ${item.finding}。团队原先跳过了${subdomain.traps[1]}的检查，把工具执行成功误认为业务结果可用，于是先回退发布，再补做对象级核对。`, `**纠偏。** ${item.action}。`);
    if (item.style === "方案评审") blocks.splice(2, 1, `**评审结论。** 方案暂不进入全面发布。${item.action}；${definition.roles[(index + 2) % definition.roles.length]}负责核对业务边界，${definition.roles[(index + 3) % definition.roles.length]}负责验证失败恢复。`);
    if (item.style === "上线验证") {
      const baselineMetric = definition.metrics[(seed + index + 1) % definition.metrics.length];
      const guardMetric = definition.metrics[(seed + index + 2) % definition.metrics.length];
      const observationSystem = definition.systems[(seed + index + 1) % definition.systems.length];
      const observationOwner = definition.roles[(seed + index + 2) % definition.roles.length];
      blocks.splice(
        3,
        0,
        `**观察窗口。** 先冻结“${profile.topic}”在${observationSystem}中的发布版本，由${observationOwner}连续比较${baselineMetric}和${guardMetric}。观察基线必须来自同一${definition.objects[(index + 1) % definition.objects.length]}范围与统计周期；若${subdomain.traps[(index + 1) % subdomain.traps.length]}出现，或对象数、金额、处理时效出现无法解释的突变，就停止放量并回到${subdomain.evidence[(index + 2) % subdomain.evidence.length]}复核。`
      );
    }
    return `${lead}

${blocks.join("\n\n")}`;
  }).join("\n\n")}`;
}

function codeFor(profile, kind, family) {
  if (!kind) return null;
  const topic = profile.topic.replace(/'/g, "''");
  if (kind === "sql" || kind.startsWith("sql-")) {
    if (kind === "sql-funnel") {
      return ["sql", `WITH scoped_events AS (
  SELECT user_id, event_name, event_time
  FROM ${family === "retail" ? "dwd_user_event" : "dwd_business_event"}
  WHERE event_time >= TIMESTAMP '2026-10-01 00:00:00'
    AND event_time <  TIMESTAMP '2026-11-01 00:00:00'
), steps AS (
  SELECT
    user_id,
    MIN(CASE WHEN event_name = 'view' THEN event_time END) AS viewed_at,
    MIN(CASE WHEN event_name = 'intent' THEN event_time END) AS intent_at,
    MIN(CASE WHEN event_name = 'complete' THEN event_time END) AS completed_at
  FROM scoped_events
  GROUP BY user_id
)
SELECT
  COUNT(*) AS scoped_users,
  COUNT(viewed_at) AS viewed_users,
  COUNT(intent_at) AS intent_users,
  COUNT(completed_at) AS completed_users,
  COUNT(intent_at) * 1.0 / NULLIF(COUNT(viewed_at), 0) AS view_to_intent,
  COUNT(completed_at) * 1.0 / NULLIF(COUNT(intent_at), 0) AS intent_to_complete
FROM steps
WHERE completed_at IS NULL OR completed_at >= intent_at;`];
    }
    if (kind === "sql-oee") {
      return ["sql", `WITH time_loss AS (
  SELECT
    equipment_id,
    work_order_id,
    SUM(planned_minutes) AS planned_minutes,
    SUM(CASE WHEN stop_type = 'PLANNED' THEN stop_minutes ELSE 0 END) AS planned_stop_minutes,
    SUM(CASE WHEN stop_type = 'UNPLANNED' THEN stop_minutes ELSE 0 END) AS unplanned_stop_minutes
  FROM mes_equipment_time_event
  WHERE production_date = DATE '2026-10-15'
  GROUP BY equipment_id, work_order_id
), output AS (
  SELECT
    work_order_id,
    SUM(total_qty) AS total_qty,
    SUM(good_qty) AS good_qty,
    MAX(standard_cycle_seconds) AS standard_cycle_seconds
  FROM mes_work_order_output
  WHERE production_date = DATE '2026-10-15'
  GROUP BY work_order_id
)
SELECT
  t.equipment_id,
  t.work_order_id,
  (t.planned_minutes - t.planned_stop_minutes - t.unplanned_stop_minutes)
    / NULLIF(t.planned_minutes - t.planned_stop_minutes, 0) AS availability,
  (o.standard_cycle_seconds * o.total_qty / 60.0)
    / NULLIF(t.planned_minutes - t.planned_stop_minutes - t.unplanned_stop_minutes, 0) AS performance,
  o.good_qty * 1.0 / NULLIF(o.total_qty, 0) AS quality
FROM time_loss t
JOIN output o USING (work_order_id);`];
    }
    if (kind === "sql-finance") {
      return ["sql", `WITH snapshot AS (
  SELECT
    loan_id,
    report_date,
    customer_id,
    product_code,
    classification_code,
    overdue_days,
    restructure_flag,
    outstanding_amount,
    accounting_scope,
    rule_version
  FROM risk_loan_snapshot
  WHERE report_date = DATE '2026-09-30'
    AND accounting_scope = 'CONSOLIDATED'
), classified AS (
  SELECT
    *,
    CASE WHEN classification_code IN ('SUBSTANDARD', 'DOUBTFUL', 'LOSS')
      THEN outstanding_amount ELSE 0 END AS npl_balance
  FROM snapshot
)
SELECT
  product_code,
  SUM(npl_balance) AS npl_balance,
  SUM(outstanding_amount) AS loan_balance,
  SUM(npl_balance) / NULLIF(SUM(outstanding_amount), 0) AS npl_ratio,
  SUM(CASE WHEN overdue_days >= 90 THEN outstanding_amount ELSE 0 END) AS overdue_90_plus,
  SUM(CASE WHEN restructure_flag = 1 THEN outstanding_amount ELSE 0 END) AS restructured_balance,
  COUNT(DISTINCT rule_version) AS rule_versions
FROM classified
GROUP BY product_code;`];
    }
    if (kind === "sql-metric") {
      return ["sql", `WITH object_base AS (
  SELECT
    object_id,
    report_date,
    segment_code,
    numerator_value,
    denominator_value,
    is_eligible,
    rule_version
  FROM metric_object_snapshot
  WHERE report_date BETWEEN DATE '2026-09-01' AND DATE '2026-09-30'
), checked AS (
  SELECT
    *,
    CASE WHEN denominator_value > 0 THEN numerator_value / denominator_value END AS metric_value
  FROM object_base
  WHERE is_eligible = 1
)
SELECT
  segment_code,
  SUM(numerator_value) AS numerator,
  SUM(denominator_value) AS denominator,
  SUM(numerator_value) / NULLIF(SUM(denominator_value), 0) AS metric_value,
  COUNT(*) AS object_count,
  COUNT(DISTINCT rule_version) AS rule_versions
FROM checked
GROUP BY segment_code;`];
    }
    if (kind === "sql-lakehouse") {
      return ["sql", `WITH partition_profile AS (
  SELECT
    dt,
    COUNT(*) AS data_files,
    AVG(file_size_bytes) AS avg_file_size,
    SUM(file_size_bytes) AS total_bytes
  FROM ${family === "engineering" ? "catalog.table_files" : "catalog.dataset_files"}
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
  GROUP BY dt
)
SELECT
  dt,
  data_files,
  ROUND(avg_file_size / 1024.0 / 1024.0, 2) AS avg_mb,
  total_bytes,
  CASE WHEN data_files > 500 OR avg_file_size < 32 * 1024 * 1024
    THEN 'COMPACT_REQUIRED' ELSE 'OK' END AS action
FROM partition_profile
ORDER BY dt;`];
    }
    if (kind === "sql-advertising") {
      return ["sql", `WITH search_terms AS (
  SELECT
    campaign_id,
    ad_group_id,
    LOWER(TRIM(search_term)) AS search_term,
    SUM(impressions) AS impressions,
    SUM(clicks) AS clicks,
    SUM(cost) AS cost,
    SUM(attributed_gmv) AS attributed_gmv,
    SUM(refund_amount) AS refund_amount
  FROM ads_search_term_daily
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-07'
  GROUP BY campaign_id, ad_group_id, LOWER(TRIM(search_term))
)
SELECT
  campaign_id,
  ad_group_id,
  search_term,
  clicks * 1.0 / NULLIF(impressions, 0) AS ctr,
  (attributed_gmv - refund_amount) / NULLIF(cost, 0) AS net_roi,
  CASE
    WHEN clicks >= 100 AND attributed_gmv = 0 THEN 'REVIEW_NEGATIVE'
    WHEN (attributed_gmv - refund_amount) / NULLIF(cost, 0) < 1 THEN 'REDUCE_BID'
    ELSE 'OBSERVE'
  END AS action_hint
FROM search_terms
ORDER BY cost DESC;`];
    }
    if (kind === "sql-profile") {
      return ["sql", `WITH latest_tag AS (
  SELECT
    entity_id,
    tag_code,
    tag_value,
    valid_from,
    valid_to,
    consent_scope,
    ROW_NUMBER() OVER (
      PARTITION BY entity_id, tag_code
      ORDER BY valid_from DESC, tag_version DESC
    ) AS rn
  FROM user_profile_tag_history
  WHERE tag_code IN ('high_value', 'price_sensitive', 'churn_risk')
),
eligible AS (
  SELECT *
  FROM latest_tag
  WHERE rn = 1
    AND valid_to > CURRENT_TIMESTAMP
    AND consent_scope LIKE '%marketing%'
)
SELECT
  tag_code,
  COUNT(DISTINCT entity_id) AS eligible_entities,
  AVG(CASE WHEN tag_value = '1' THEN 1.0 ELSE 0 END) AS positive_rate
FROM eligible
GROUP BY tag_code;`];
    }
    if (kind === "sql-manufacturing") {
      return ["sql", `WITH work_order_summary AS (
  SELECT
    work_order_id,
    product_code,
    SUM(reported_qty) AS reported_qty,
    SUM(good_qty) AS good_qty,
    SUM(scrap_qty) AS scrap_qty,
    SUM(rework_qty) AS rework_qty,
    MIN(actual_start_at) AS actual_start_at,
    MAX(actual_end_at) AS actual_end_at
  FROM mes_work_order_event
  WHERE production_date = DATE '2026-10-15'
  GROUP BY work_order_id, product_code
)
SELECT
  work_order_id,
  product_code,
  reported_qty,
  good_qty,
  scrap_qty,
  rework_qty,
  CASE WHEN good_qty + scrap_qty = reported_qty THEN 'BALANCED' ELSE 'INVESTIGATE' END AS qty_status,
  actual_end_at - actual_start_at AS execution_duration
FROM work_order_summary;`];
    }
    if (kind === "sql-quality") {
      return ["sql", `WITH batch_quality AS (
  SELECT
    batch_id,
    work_order_id,
    SUM(CASE WHEN inspection_result = 'PASS' THEN inspected_qty ELSE 0 END) AS passed_qty,
    SUM(inspected_qty) AS inspected_qty,
    SUM(rework_qty) AS rework_qty,
    MAX(inspection_rule_version) AS inspection_rule_version
  FROM qms_inspection_result
  WHERE production_date BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
  GROUP BY batch_id, work_order_id
)
SELECT
  batch_id,
  work_order_id,
  inspected_qty,
  passed_qty * 1.0 / NULLIF(inspected_qty, 0) AS first_pass_yield,
  rework_qty,
  inspection_rule_version
FROM batch_quality
WHERE inspected_qty = 0 OR rework_qty > inspected_qty;`];
    }
    if (kind === "sql-retail") {
      return ["sql", `WITH order_scope AS (
  SELECT
    order_id,
    user_id,
    channel_code,
    paid_amount,
    refund_amount,
    paid_at,
    refunded_at
  FROM dwd_order_payment
  WHERE paid_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND paid_at <  TIMESTAMP '2026-11-01 00:00:00'
)
SELECT
  channel_code,
  COUNT(DISTINCT user_id) AS paying_users,
  COUNT(DISTINCT order_id) AS paid_orders,
  SUM(paid_amount) AS paid_gmv,
  SUM(refund_amount) AS refund_amount,
  SUM(paid_amount - refund_amount) AS net_gmv,
  SUM(paid_amount - refund_amount) / NULLIF(COUNT(DISTINCT order_id), 0) AS net_aov
FROM order_scope
GROUP BY channel_code;`];
    }
    if (kind === "sql-healthcare") {
      return ["sql", `WITH encounter_scope AS (
  SELECT
    encounter_id,
    patient_id,
    department_code,
    admitted_at,
    discharged_at,
    discharge_status,
    data_version
  FROM clinical_encounter
  WHERE admitted_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND admitted_at <  TIMESTAMP '2026-11-01 00:00:00'
)
SELECT
  department_code,
  COUNT(DISTINCT patient_id) AS unique_patients,
  COUNT(DISTINCT encounter_id) AS encounters,
  AVG(EXTRACT(EPOCH FROM (discharged_at - admitted_at)) / 86400.0) AS avg_los_days,
  COUNT(DISTINCT data_version) AS data_versions
FROM encounter_scope
WHERE discharged_at >= admitted_at
GROUP BY department_code;`];
    }
    if (kind === "sql-experiment") {
      return ["sql", `WITH exposure AS (
  SELECT
    experiment_id,
    user_id,
    group_code,
    MIN(exposed_at) AS first_exposed_at
  FROM experiment_exposure
  WHERE experiment_id = '${topic.slice(0, 40)}'
  GROUP BY experiment_id, user_id, group_code
), outcome AS (
  SELECT
    e.group_code,
    e.user_id,
    MAX(CASE WHEN o.metric_name = 'primary' THEN o.metric_value END) AS primary_metric,
    MAX(CASE WHEN o.metric_name = 'guardrail' THEN o.metric_value END) AS guardrail_metric
  FROM exposure e
  LEFT JOIN experiment_outcome o USING (user_id)
  GROUP BY e.group_code, e.user_id
)
SELECT
  group_code,
  COUNT(*) AS sample_size,
  AVG(primary_metric) AS primary_mean,
  APPROX_PERCENTILE(primary_metric, 0.95) AS primary_p95,
  AVG(guardrail_metric) AS guardrail_mean
FROM outcome
GROUP BY group_code;`];
    }
    if (kind === "sql-heatmap") {
      return ["sql", `WITH page_events AS (
  SELECT
    session_id,
    page_id,
    page_version,
    device_type,
    viewport_width,
    viewport_height,
    zone_id,
    event_type,
    relative_x,
    relative_y,
    scroll_depth,
    event_time
  FROM dwd_page_attention_event
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
    AND page_id = 'course_detail'
), normalized AS (
  SELECT
    *,
    LEAST(1.0, GREATEST(0.0, relative_x / NULLIF(viewport_width, 0))) AS x_pct,
    LEAST(1.0, GREATEST(0.0, relative_y / NULLIF(viewport_height, 0))) AS y_pct
  FROM page_events
  WHERE event_type IN ('exposure', 'click')
), zone_stats AS (
  SELECT
    page_version,
    device_type,
    zone_id,
    COUNT(DISTINCT CASE WHEN event_type = 'exposure' THEN session_id END) AS exposed_sessions,
    COUNT(DISTINCT CASE WHEN event_type = 'click' THEN session_id END) AS clicked_sessions,
    COUNT(DISTINCT session_id) AS sampled_sessions,
    AVG(scroll_depth) AS avg_scroll_depth
  FROM normalized
  WHERE x_pct BETWEEN 0 AND 1
    AND y_pct BETWEEN 0 AND 1
  GROUP BY page_version, device_type, zone_id
)
SELECT
  page_version,
  device_type,
  zone_id,
  exposed_sessions,
  clicked_sessions,
  clicked_sessions * 1.0 / NULLIF(exposed_sessions, 0) AS zone_click_rate,
  avg_scroll_depth,
  CASE WHEN sampled_sessions < 100 THEN 'LOW_SAMPLE'
       WHEN page_version NOT IN ('v2', 'v3') THEN 'STALE_VERSION'
       ELSE 'COMPARABLE' END AS heatmap_quality
FROM zone_stats
ORDER BY page_version, device_type, zone_click_rate DESC;`];
    }
    if (kind === "sql-trust") {
      return ["sql", `WITH project_scope AS (
  SELECT
    p.project_id,
    p.contract_id,
    p.trustee_id,
    p.beneficiary_id,
    p.account_id,
    p.project_status,
    p.effective_date,
    p.maturity_date,
    p.rule_version
  FROM trust_project p
  WHERE p.effective_date <= DATE '2026-10-31'
    AND (p.maturity_date IS NULL OR p.maturity_date >= DATE '2026-10-01')
), cash_check AS (
  SELECT
    f.project_id,
    SUM(CASE WHEN f.flow_type = 'SUBSCRIPTION' THEN f.amount ELSE 0 END) AS subscribed_amount,
    SUM(CASE WHEN f.flow_type = 'DISTRIBUTION' THEN f.amount ELSE 0 END) AS distributed_amount,
    COUNT(DISTINCT f.account_id) AS funded_accounts
  FROM trust_account_flow f
  WHERE f.value_date BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
  GROUP BY f.project_id
), benefit_check AS (
  SELECT
    project_id,
    COUNT(DISTINCT beneficiary_id) AS beneficiaries,
    SUM(DISTRIBUTION_RATIO) AS distribution_ratio,
    MAX(valid_from) AS latest_benefit_version
  FROM trust_beneficiary_history
  WHERE valid_to > DATE '2026-10-01'
  GROUP BY project_id
)
SELECT
  p.project_id,
  p.contract_id,
  p.project_status,
  c.subscribed_amount,
  c.distributed_amount,
  b.beneficiaries,
  b.distribution_ratio,
  p.rule_version,
  CASE WHEN c.project_id IS NULL THEN 'NO_ACCOUNT_FLOW'
       WHEN ABS(COALESCE(b.distribution_ratio, 0) - 1) > 0.0001 THEN 'BENEFIT_RATIO_MISMATCH'
       WHEN p.contract_id IS NULL THEN 'CONTRACT_MISSING'
       ELSE 'RECONCILED' END AS review_status
FROM project_scope p
LEFT JOIN cash_check c USING (project_id)
LEFT JOIN benefit_check b USING (project_id);`];
    }
    if (kind === "sql-icu") {
      return ["sql", `WITH icu_stay AS (
  SELECT
    stay_id,
    patient_id,
    admission_id,
    icu_unit,
    admitted_at,
    discharged_at,
    discharge_disposition,
    infection_flag,
    data_version
  FROM clinical_icu_stay
  WHERE admitted_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND admitted_at <  TIMESTAMP '2026-11-01 00:00:00'
), vital_summary AS (
  SELECT
    stay_id,
    MIN(systolic_bp) AS min_sbp,
    MAX(lactate_value) AS max_lactate,
    AVG(oxygen_saturation) AS avg_spo2,
    COUNT(*) AS vital_observations
  FROM clinical_vital_sign
  GROUP BY stay_id
), medication_risk AS (
  SELECT
    stay_id,
    COUNT(DISTINCT medication_id) AS medication_count,
    SUM(CASE WHEN high_alert_flag = 1 THEN 1 ELSE 0 END) AS high_alert_orders
  FROM clinical_medication_order
  WHERE order_status IN ('VERIFIED', 'ADMINISTERED')
  GROUP BY stay_id
)
SELECT
  s.icu_unit,
  DATE_TRUNC('day', s.admitted_at) AS admission_day,
  COUNT(DISTINCT s.stay_id) AS icu_stays,
  COUNT(DISTINCT s.patient_id) AS patients,
  AVG(EXTRACT(EPOCH FROM (s.discharged_at - s.admitted_at)) / 3600.0) AS avg_icu_hours,
  SUM(CASE WHEN s.infection_flag = 1 THEN 1 ELSE 0 END) AS infection_stays,
  AVG(v.min_sbp) AS avg_min_sbp,
  AVG(v.max_lactate) AS avg_max_lactate,
  SUM(m.high_alert_orders) AS high_alert_orders
FROM icu_stay s
LEFT JOIN vital_summary v USING (stay_id)
LEFT JOIN medication_risk m USING (stay_id)
WHERE s.discharged_at >= s.admitted_at
GROUP BY s.icu_unit, DATE_TRUNC('day', s.admitted_at);`];
    }
    if (kind === "sql-chronic") {
      return ["sql", `WITH eligible_patients AS (
  SELECT
    patient_id,
    chronic_condition_code,
    index_visit_date,
    risk_level,
    care_team_id,
    consent_status
  FROM clinical_chronic_registry
  WHERE index_visit_date BETWEEN DATE '2026-01-01' AND DATE '2026-10-31'
    AND consent_status = 'ACTIVE'
), followup_fact AS (
  SELECT
    patient_id,
    chronic_condition_code,
    COUNT(DISTINCT CASE WHEN followup_type = 'CLINIC' THEN followup_id END) AS clinic_followups,
    COUNT(DISTINCT CASE WHEN followup_type = 'REMOTE' THEN followup_id END) AS remote_followups,
    MAX(followup_date) AS last_followup_date,
    SUM(CASE WHEN control_status = 'UNCONTROLLED' THEN 1 ELSE 0 END) AS uncontrolled_visits
  FROM clinical_chronic_followup
  WHERE followup_date >= DATE '2026-01-01'
  GROUP BY patient_id, chronic_condition_code
)
SELECT
  e.care_team_id,
  e.chronic_condition_code,
  COUNT(DISTINCT e.patient_id) AS enrolled_patients,
  AVG(COALESCE(f.clinic_followups, 0) + COALESCE(f.remote_followups, 0)) AS avg_followups,
  SUM(CASE WHEN f.last_followup_date IS NULL THEN 1 ELSE 0 END) AS never_followed,
  SUM(CASE WHEN f.last_followup_date < DATE '2026-08-01' THEN 1 ELSE 0 END) AS overdue_patients,
  SUM(f.uncontrolled_visits) AS uncontrolled_visits
FROM eligible_patients e
LEFT JOIN followup_fact f
  ON e.patient_id = f.patient_id
 AND e.chronic_condition_code = f.chronic_condition_code
GROUP BY e.care_team_id, e.chronic_condition_code;`];
    }
    if (kind === "sql-sixsigma") {
      return ["sql", `WITH measure_system AS (
  SELECT
    measurement_session_id,
    gauge_id,
    part_id,
    operator_id,
    repeatability,
    reproducibility,
    resolution,
    calibration_due_date
  FROM qms_msa_study
  WHERE study_date BETWEEN DATE '2026-08-01' AND DATE '2026-10-31'
), process_samples AS (
  SELECT
    work_order_id,
    part_id,
    process_step,
    AVG(measured_value) AS process_mean,
    STDDEV_SAMP(measured_value) AS process_sigma,
    COUNT(*) AS sample_size
  FROM qms_process_measurement
  WHERE measured_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND measured_at <  TIMESTAMP '2026-11-01 00:00:00'
  GROUP BY work_order_id, part_id, process_step
)
SELECT
  p.work_order_id,
  p.process_step,
  p.sample_size,
  p.process_mean,
  p.process_sigma,
  (CAST(upper_spec_limit AS DOUBLE) - CAST(lower_spec_limit AS DOUBLE))
    / NULLIF(6 * p.process_sigma, 0) AS cp,
  LEAST(
    (CAST(upper_spec_limit AS DOUBLE) - p.process_mean) / NULLIF(3 * p.process_sigma, 0),
    (p.process_mean - CAST(lower_spec_limit AS DOUBLE)) / NULLIF(3 * p.process_sigma, 0)
  ) AS cpk,
  MAX(CASE WHEN m.calibration_due_date < CURRENT_DATE THEN 1 ELSE 0 END) AS gauge_overdue
FROM process_samples p
LEFT JOIN qms_spec_limit l USING (part_id, process_step)
LEFT JOIN measure_system m USING (part_id)
GROUP BY p.work_order_id, p.process_step, p.sample_size, p.process_mean, p.process_sigma,
         upper_spec_limit, lower_spec_limit;`];
    }
    if (kind === "sql-retail-space") {
      return ["sql", `WITH store_month AS (
    SELECT
      store_id,
      month_key,
      SUM(net_sales_amount) AS net_sales_amount,
      SUM(gross_margin_amount) AS gross_margin_amount,
      AVG(leased_area_sqm) AS leased_area_sqm,
      AVG(rent_amount) AS rent_amount,
      AVG(employee_count) AS employee_count
    FROM retail_store_month_snapshot
    WHERE month_key BETWEEN '2026-01' AND '2026-10'
    GROUP BY store_id, month_key
  ), traffic AS (
    SELECT
      store_id,
      month_key,
      SUM(estimated_passersby) AS passersby,
      SUM(entered_visitors) AS entered_visitors,
      COUNT(DISTINCT visit_date) AS trading_days
    FROM retail_store_traffic
    GROUP BY store_id, month_key
  )
  SELECT
    s.store_id,
    s.month_key,
    s.net_sales_amount,
    s.net_sales_amount / NULLIF(s.leased_area_sqm, 0) AS sales_per_sqm,
    s.gross_margin_amount / NULLIF(s.leased_area_sqm, 0) AS margin_per_sqm,
    s.rent_amount / NULLIF(s.net_sales_amount, 0) AS rent_to_sales_ratio,
    t.entered_visitors * 1.0 / NULLIF(t.passersby, 0) AS entry_rate,
    s.net_sales_amount / NULLIF(t.entered_visitors, 0) AS sales_per_visitor,
    CASE WHEN s.leased_area_sqm <= 0 THEN 'AREA_MISSING'
         WHEN t.trading_days < 20 THEN 'NON_COMPARABLE_MONTH'
         ELSE 'COMPARABLE' END AS comparison_status
  FROM store_month s
  LEFT JOIN traffic t USING (store_id, month_key);`];
    }
    if (kind === "sql-industry4") {
      return ["sql", `WITH equipment_clock AS (
  SELECT
    equipment_id,
    work_center_id,
    event_time,
    LAG(event_time) OVER (PARTITION BY equipment_id ORDER BY event_time) AS previous_time,
    state_code,
    source_system,
    clock_offset_ms
  FROM iot_equipment_state_event
  WHERE event_time >= TIMESTAMP '2026-10-15 00:00:00'
    AND event_time <  TIMESTAMP '2026-10-16 00:00:00'
), state_duration AS (
  SELECT
    equipment_id,
    work_center_id,
    state_code,
    EXTRACT(EPOCH FROM (event_time - previous_time)) AS duration_seconds,
    source_system,
    ABS(clock_offset_ms) AS clock_offset_ms
  FROM equipment_clock
  WHERE previous_time IS NOT NULL
), mes_orders AS (
  SELECT equipment_id, work_order_id, good_qty, scrap_qty, standard_cycle_seconds
  FROM mes_work_order_output
  WHERE production_date = DATE '2026-10-15'
)
SELECT
  d.equipment_id,
  d.work_center_id,
  SUM(CASE WHEN d.state_code = 'RUNNING' THEN d.duration_seconds ELSE 0 END) / 60.0 AS run_minutes,
  SUM(CASE WHEN d.state_code = 'FAULT' THEN d.duration_seconds ELSE 0 END) / 60.0 AS fault_minutes,
  COUNT(DISTINCT o.work_order_id) AS work_orders,
  SUM(o.good_qty) AS good_qty,
  SUM(o.scrap_qty) AS scrap_qty,
  MAX(d.clock_offset_ms) AS max_clock_offset_ms,
  CASE WHEN MAX(d.clock_offset_ms) > 1000 THEN 'CHECK_OT_IT_CLOCK'
       WHEN COUNT(DISTINCT d.source_system) > 1 THEN 'RECONCILE_SOURCES'
       ELSE 'READY' END AS integration_status
FROM state_duration d
LEFT JOIN mes_orders o USING (equipment_id)
GROUP BY d.equipment_id, d.work_center_id;`];
    }
    if (kind === "sql-manufacturing-supply") {
      return ["sql", `WITH purchase_plan AS (
  SELECT
    supplier_id,
    material_id,
    required_date,
    SUM(required_qty) AS required_qty,
    MAX(plan_version) AS plan_version
  FROM aps_material_requirement
  WHERE required_date BETWEEN DATE '2026-10-01' AND DATE '2026-12-31'
  GROUP BY supplier_id, material_id, required_date
), receipt_fact AS (
  SELECT
    supplier_id,
    material_id,
    required_date,
    SUM(received_qty) AS received_qty,
    SUM(rejected_qty) AS rejected_qty,
    MAX(receipt_date) AS last_receipt_date
  FROM wms_supplier_receipt
  GROUP BY supplier_id, material_id, required_date
), open_orders AS (
  SELECT
    supplier_id,
    material_id,
    SUM(open_qty) AS open_qty,
    MIN(promised_date) AS earliest_promised_date
  FROM srm_open_order
  GROUP BY supplier_id, material_id
)
SELECT
  p.supplier_id,
  p.material_id,
  p.required_date,
  p.required_qty,
  COALESCE(r.received_qty, 0) AS received_qty,
  p.required_qty - COALESCE(r.received_qty, 0) AS shortage_qty,
  COALESCE(o.open_qty, 0) AS open_po_qty,
  r.rejected_qty,
  CASE WHEN COALESCE(r.received_qty, 0) + COALESCE(o.open_qty, 0) < p.required_qty
         THEN 'SUPPLY_GAP'
       WHEN r.rejected_qty > 0 THEN 'QUALITY_HOLD'
       ELSE 'ON_TRACK' END AS supply_status
FROM purchase_plan p
LEFT JOIN receipt_fact r USING (supplier_id, material_id, required_date)
LEFT JOIN open_orders o USING (supplier_id, material_id);`];
    }
    if (kind === "sql-ev") {
      return ["sql", `WITH vehicle_build AS (
  SELECT
    vehicle_id,
    work_order_id,
    battery_pack_id,
    motor_id,
    build_date,
    build_shift,
    software_version
  FROM manufacturing_vehicle_build
  WHERE build_date BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
), battery_events AS (
  SELECT
    battery_pack_id,
    vehicle_id,
    COUNT(*) AS telemetry_events,
    MAX(module_temperature_c) AS max_module_temperature_c,
    MIN(state_of_health_pct) AS min_state_of_health_pct,
    MAX(alert_level) AS max_alert_level,
    MAX(event_time) AS last_telemetry_at
  FROM vehicle_battery_telemetry
  GROUP BY battery_pack_id, vehicle_id
), supply_lot AS (
  SELECT
    battery_pack_id,
    cell_lot_id,
    supplier_id,
    incoming_inspection_result
  FROM manufacturing_battery_lot
)
SELECT
  b.build_shift,
  s.supplier_id,
  COUNT(DISTINCT b.vehicle_id) AS vehicles,
  AVG(e.telemetry_events) AS avg_telemetry_events,
  AVG(e.max_module_temperature_c) AS avg_max_temperature,
  AVG(e.min_state_of_health_pct) AS avg_min_soh,
  SUM(CASE WHEN e.max_alert_level >= 3 THEN 1 ELSE 0 END) AS high_alert_vehicles,
  SUM(CASE WHEN s.incoming_inspection_result = 'FAIL' THEN 1 ELSE 0 END) AS failed_incoming_vehicles,
  MAX(b.software_version) AS software_version
FROM vehicle_build b
LEFT JOIN battery_events e USING (vehicle_id, battery_pack_id)
LEFT JOIN supply_lot s USING (battery_pack_id)
GROUP BY b.build_shift, s.supplier_id;`];
    }
    if (kind === "sql-logistics") {
      return ["sql", `WITH shipment_scope AS (
  SELECT
    shipment_id,
    order_id,
    origin_hub_id,
    destination_hub_id,
    promised_delivery_at,
    picked_up_at,
    delivered_at,
    current_status,
    exception_code
  FROM logistics_shipment
  WHERE created_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND created_at <  TIMESTAMP '2026-11-01 00:00:00'
), leg_duration AS (
  SELECT
    shipment_id,
    SUM(EXTRACT(EPOCH FROM (departed_at - arrived_at))) AS invalid_leg_seconds,
    COUNT(*) AS leg_count,
    MAX(warehouse_wait_minutes) AS max_warehouse_wait_minutes
  FROM logistics_shipment_leg
  GROUP BY shipment_id
)
SELECT
  s.origin_hub_id,
  s.destination_hub_id,
  COUNT(DISTINCT s.shipment_id) AS shipments,
  AVG(EXTRACT(EPOCH FROM (s.delivered_at - s.picked_up_at)) / 3600.0) AS avg_hours,
  SUM(CASE WHEN s.delivered_at > s.promised_delivery_at THEN 1 ELSE 0 END) AS late_shipments,
  AVG(l.max_warehouse_wait_minutes) AS avg_max_warehouse_wait,
  SUM(CASE WHEN l.invalid_leg_seconds <> 0 THEN 1 ELSE 0 END) AS invalid_timeline_shipments,
  SUM(CASE WHEN s.exception_code IS NOT NULL THEN 1 ELSE 0 END) AS exception_shipments
FROM shipment_scope s
LEFT JOIN leg_duration l USING (shipment_id)
GROUP BY s.origin_hub_id, s.destination_hub_id;`];
    }
    if (kind === "sql-education") {
      return ["sql", `WITH learner_scope AS (
  SELECT
    learner_id,
    course_id,
    cohort_id,
    enrolled_at,
    first_lesson_at,
    completed_at,
    completion_status,
    access_expires_at
  FROM education_course_enrollment
  WHERE enrolled_at >= TIMESTAMP '2026-09-01 00:00:00'
    AND enrolled_at <  TIMESTAMP '2026-11-01 00:00:00'
), learning_activity AS (
  SELECT
    learner_id,
    course_id,
    SUM(active_seconds) AS active_seconds,
    COUNT(DISTINCT lesson_id) AS lessons_started,
    COUNT(DISTINCT CASE WHEN lesson_status = 'COMPLETED' THEN lesson_id END) AS lessons_completed,
    MAX(activity_at) AS last_activity_at
  FROM education_learning_event
  GROUP BY learner_id, course_id
)
SELECT
  e.course_id,
  e.cohort_id,
  COUNT(DISTINCT e.learner_id) AS enrolled_learners,
  COUNT(DISTINCT CASE WHEN e.completion_status = 'COMPLETED' THEN e.learner_id END) AS completers,
  AVG(a.active_seconds) / 3600.0 AS avg_active_hours,
  AVG(a.lessons_completed * 1.0 / NULLIF(a.lessons_started, 0)) AS avg_lesson_completion,
  SUM(CASE WHEN e.first_lesson_at IS NULL THEN 1 ELSE 0 END) AS never_started,
  SUM(CASE WHEN e.completion_status = 'COMPLETED'
                 AND e.completed_at > e.access_expires_at THEN 1 ELSE 0 END) AS late_completions
FROM learner_scope e
LEFT JOIN learning_activity a USING (learner_id, course_id)
GROUP BY e.course_id, e.cohort_id;`];
    }
    if (kind === "sql-pharma") {
      return ["sql", `WITH batch_scope AS (
  SELECT
    batch_id,
    product_id,
    site_id,
    manufacturing_date,
    release_status,
    quality_gate_version
  FROM pharma_batch_record
  WHERE manufacturing_date BETWEEN DATE '2026-01-01' AND DATE '2026-10-31'
), deviation_fact AS (
  SELECT
    batch_id,
    COUNT(*) AS deviation_count,
    SUM(CASE WHEN severity IN ('MAJOR', 'CRITICAL') THEN 1 ELSE 0 END) AS major_deviations,
    MAX(closed_at) AS latest_deviation_closed_at
  FROM pharma_deviation
  GROUP BY batch_id
), stability_fact AS (
  SELECT
    batch_id,
    MAX(CASE WHEN test_type = 'ASSAY' THEN result_value END) AS assay_result,
    MAX(rule_version) AS stability_rule_version
  FROM pharma_stability_result
  GROUP BY batch_id
)
SELECT
  b.site_id,
  b.product_id,
  COUNT(DISTINCT b.batch_id) AS batches,
  SUM(CASE WHEN b.release_status = 'RELEASED' THEN 1 ELSE 0 END) AS released_batches,
  SUM(COALESCE(d.major_deviations, 0)) AS major_deviations,
  SUM(CASE WHEN d.latest_deviation_closed_at > b.manufacturing_date THEN 1 ELSE 0 END) AS post_batch_deviations,
  AVG(s.assay_result) AS avg_assay_result,
  COUNT(DISTINCT s.stability_rule_version) AS stability_rule_versions,
  COUNT(DISTINCT b.quality_gate_version) AS release_rule_versions
FROM batch_scope b
LEFT JOIN deviation_fact d USING (batch_id)
LEFT JOIN stability_fact s USING (batch_id)
GROUP BY b.site_id, b.product_id;`];
    }
    if (kind === "sql-genomics") {
      return ["sql", `WITH sample_qc AS (
  SELECT
    sample_id,
    patient_id,
    assay_batch_id,
    reference_genome_version,
    mean_coverage,
    duplicate_rate,
    contamination_rate,
    qc_status
  FROM genomics_sample_qc
  WHERE sequencing_date BETWEEN DATE '2026-01-01' AND DATE '2026-10-31'
), variant_scope AS (
  SELECT
    sample_id,
    COUNT(*) AS variant_count,
    COUNT(DISTINCT variant_id) AS unique_variant_count,
    SUM(CASE WHEN clinical_significance = 'PATHOGENIC' THEN 1 ELSE 0 END) AS pathogenic_variants,
    MAX(annotation_version) AS annotation_version
  FROM genomics_variant_call
  WHERE filter_status = 'PASS'
  GROUP BY sample_id
)
SELECT
  q.assay_batch_id,
  q.reference_genome_version,
  COUNT(DISTINCT q.sample_id) AS samples,
  COUNT(DISTINCT q.patient_id) AS patients,
  SUM(CASE WHEN q.qc_status = 'PASS' THEN 1 ELSE 0 END) AS qc_pass_samples,
  SUM(CASE WHEN q.mean_coverage < 30 THEN 1 ELSE 0 END) AS low_coverage_samples,
  AVG(q.duplicate_rate) AS avg_duplicate_rate,
  AVG(v.variant_count) AS avg_variants,
  SUM(v.pathogenic_variants) AS pathogenic_variants,
  COUNT(DISTINCT v.annotation_version) AS annotation_versions
FROM sample_qc q
LEFT JOIN variant_scope v USING (sample_id)
GROUP BY q.assay_batch_id, q.reference_genome_version;`];
    }
    if (kind === "sql-energy") {
      return ["sql", `WITH meter_readings AS (
  SELECT
    meter_id,
    site_id,
    reading_time,
    active_energy_kwh,
    reactive_energy_kvarh,
    quality_code,
    tariff_period
  FROM energy_meter_reading
  WHERE reading_time >= TIMESTAMP '2026-10-01 00:00:00'
    AND reading_time <  TIMESTAMP '2026-11-01 00:00:00'
), intervalized AS (
  SELECT
    meter_id,
    site_id,
    reading_time,
    active_energy_kwh
      - LAG(active_energy_kwh) OVER (PARTITION BY meter_id ORDER BY reading_time) AS consumption_kwh,
    quality_code,
    tariff_period
  FROM meter_readings
), site_scope AS (
  SELECT
    site_id,
    COUNT(DISTINCT meter_id) AS meters,
    SUM(GREATEST(consumption_kwh, 0)) AS consumption_kwh,
    SUM(CASE WHEN quality_code <> 'VALID' THEN GREATEST(consumption_kwh, 0) ELSE 0 END) AS suspect_kwh,
    SUM(CASE WHEN tariff_period = 'PEAK' THEN GREATEST(consumption_kwh, 0) ELSE 0 END) AS peak_kwh,
    SUM(CASE WHEN tariff_period = 'VALLEY' THEN GREATEST(consumption_kwh, 0) ELSE 0 END) AS valley_kwh
  FROM intervalized
  GROUP BY site_id
)
SELECT
  site_id,
  meters,
  consumption_kwh,
  suspect_kwh / NULLIF(consumption_kwh, 0) AS suspect_ratio,
  peak_kwh / NULLIF(consumption_kwh, 0) AS peak_ratio,
  valley_kwh / NULLIF(consumption_kwh, 0) AS valley_ratio,
  CASE WHEN suspect_kwh / NULLIF(consumption_kwh, 0) > 0.05 THEN 'METER_QUALITY_REVIEW'
       ELSE 'READY' END AS release_status
FROM site_scope;`];
    }
    if (kind === "sql-agriculture") {
      return ["sql", `WITH plot_season AS (
  SELECT
    plot_id,
    farm_id,
    crop_id,
    season_id,
    planting_area_mu,
    planted_date,
    harvested_date,
    yield_kg,
    loss_reason
  FROM agriculture_plot_season
  WHERE season_id BETWEEN '2026-S1' AND '2026-S3'
), sensor_daily AS (
  SELECT
    plot_id,
    season_id,
    sensor_date,
    AVG(soil_moisture_pct) AS soil_moisture_pct,
    SUM(rainfall_mm) AS rainfall_mm,
    AVG(temperature_c) AS temperature_c,
    COUNT(*) AS sensor_readings
  FROM agriculture_iot_daily
  GROUP BY plot_id, season_id, sensor_date
), season_environment AS (
  SELECT
    plot_id,
    season_id,
    AVG(soil_moisture_pct) AS avg_soil_moisture,
    SUM(rainfall_mm) AS total_rainfall,
    AVG(temperature_c) AS avg_temperature,
    SUM(CASE WHEN sensor_readings < 20 THEN 1 ELSE 0 END) AS low_coverage_days
  FROM sensor_daily
  GROUP BY plot_id, season_id
)
SELECT
  p.farm_id,
  p.crop_id,
  COUNT(DISTINCT p.plot_id) AS plots,
  SUM(p.planting_area_mu) AS planted_area_mu,
  SUM(p.yield_kg) / NULLIF(SUM(p.planting_area_mu), 0) AS yield_per_mu,
  AVG(e.avg_soil_moisture) AS avg_soil_moisture,
  SUM(e.total_rainfall) AS total_rainfall,
  SUM(e.low_coverage_days) AS low_coverage_days,
  SUM(CASE WHEN p.loss_reason IS NOT NULL THEN 1 ELSE 0 END) AS loss_plots
FROM plot_season p
LEFT JOIN season_environment e USING (plot_id, season_id)
GROUP BY p.farm_id, p.crop_id;`];
    }
    if (kind === "sql-real-estate") {
      return ["sql", `WITH unit_snapshot AS (
  SELECT
    project_id,
    unit_id,
    snapshot_date,
    saleable_area_sqm,
    list_price_amount,
    signed_price_amount,
    sales_status,
    price_version
  FROM real_estate_unit_snapshot
  WHERE snapshot_date = DATE '2026-10-31'
), project_supply AS (
  SELECT
    project_id,
    SUM(saleable_area_sqm) AS saleable_area_sqm,
    SUM(CASE WHEN sales_status = 'SIGNED' THEN saleable_area_sqm ELSE 0 END) AS signed_area_sqm,
    SUM(CASE WHEN sales_status = 'AVAILABLE' THEN saleable_area_sqm ELSE 0 END) AS available_area_sqm,
    COUNT(DISTINCT price_version) AS price_versions
  FROM unit_snapshot
  GROUP BY project_id
), collection_fact AS (
  SELECT
    project_id,
    SUM(CASE WHEN flow_type = 'RECEIPT' THEN amount ELSE 0 END) AS cash_receipts,
    SUM(CASE WHEN flow_type = 'REFUND' THEN amount ELSE 0 END) AS refunds
  FROM real_estate_collection_flow
  WHERE value_date <= DATE '2026-10-31'
  GROUP BY project_id
)
SELECT
  p.project_id,
  p.saleable_area_sqm,
  p.signed_area_sqm,
  p.signed_area_sqm / NULLIF(p.saleable_area_sqm, 0) AS sold_area_ratio,
  p.available_area_sqm,
  c.cash_receipts - c.refunds AS net_receipts,
  p.price_versions,
  CASE WHEN p.price_versions > 1 THEN 'PRICE_VERSION_REVIEW'
       WHEN p.available_area_sqm < 0 THEN 'AREA_RECONCILIATION_REQUIRED'
       ELSE 'READY' END AS sales_status
FROM project_supply p
LEFT JOIN collection_fact c USING (project_id);`];
    }
    if (kind === "sql-service-ops") {
      return ["sql", `WITH ticket_scope AS (
  SELECT
    ticket_id,
    customer_id,
    channel_code,
    issue_category,
    priority,
    created_at,
    first_response_at,
    resolved_at,
    reopened_at,
    current_status,
    agent_team_id
  FROM service_ticket
  WHERE created_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND created_at <  TIMESTAMP '2026-11-01 00:00:00'
), interaction_fact AS (
  SELECT
    ticket_id,
    COUNT(DISTINCT interaction_id) AS interactions,
    SUM(wait_seconds) AS total_wait_seconds,
    MAX(transfer_count) AS max_transfer_count
  FROM service_interaction
  GROUP BY ticket_id
)
SELECT
  t.agent_team_id,
  t.issue_category,
  COUNT(DISTINCT t.ticket_id) AS tickets,
  AVG(EXTRACT(EPOCH FROM (t.first_response_at - t.created_at)) / 60.0) AS avg_first_response_minutes,
  AVG(EXTRACT(EPOCH FROM (t.resolved_at - t.created_at)) / 3600.0) AS avg_resolution_hours,
  SUM(CASE WHEN t.reopened_at IS NOT NULL THEN 1 ELSE 0 END) AS reopened_tickets,
  AVG(i.max_transfer_count) AS avg_transfers,
  SUM(CASE WHEN t.current_status IN ('OPEN', 'PENDING')
                 AND t.created_at < CURRENT_TIMESTAMP - INTERVAL '48' HOUR THEN 1 ELSE 0 END) AS overdue_tickets
FROM ticket_scope t
LEFT JOIN interaction_fact i USING (ticket_id)
GROUP BY t.agent_team_id, t.issue_category;`];
    }
    if (kind === "sql-inventory") {
      return ["sql", `WITH inventory_event AS (
  SELECT
    warehouse_id,
    sku_id,
    event_time,
    event_type,
    quantity_delta,
    reservation_id,
    order_id,
    batch_id
  FROM wms_inventory_event
  WHERE event_time >= TIMESTAMP '2026-10-01 00:00:00'
    AND event_time <  TIMESTAMP '2026-11-01 00:00:00'
), balance_from_events AS (
  SELECT
    warehouse_id,
    sku_id,
    SUM(quantity_delta) AS event_balance,
    SUM(CASE WHEN event_type = 'RESERVE' THEN -quantity_delta ELSE 0 END) AS reserved_qty,
    COUNT(DISTINCT batch_id) AS batch_count
  FROM inventory_event
  GROUP BY warehouse_id, sku_id
), stock_snapshot AS (
  SELECT warehouse_id, sku_id, SUM(on_hand_qty) AS snapshot_qty
  FROM wms_inventory_snapshot
  WHERE snapshot_date = DATE '2026-10-31'
  GROUP BY warehouse_id, sku_id
)
SELECT
  s.warehouse_id,
  s.sku_id,
  s.snapshot_qty,
  e.event_balance,
  s.snapshot_qty - e.event_balance AS balance_difference,
  e.reserved_qty,
  s.snapshot_qty - e.reserved_qty AS available_qty,
  CASE WHEN ABS(s.snapshot_qty - e.event_balance) > 0 THEN 'RECONCILE'
       WHEN s.snapshot_qty - e.reserved_qty < 0 THEN 'OVER_RESERVED'
       ELSE 'OK' END AS inventory_status
FROM stock_snapshot s
FULL OUTER JOIN balance_from_events e USING (warehouse_id, sku_id);`];
    }
    if (kind === "sql-platform") {
      return ["sql", `WITH session_scope AS (
  SELECT
    session_id,
    user_id,
    channel_code,
    campaign_id,
    started_at,
    ended_at,
    attributed_order_id,
    device_id
  FROM platform_session
  WHERE started_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND started_at <  TIMESTAMP '2026-11-01 00:00:00'
), order_fact AS (
  SELECT
    order_id,
    user_id,
    paid_amount,
    refund_amount,
    paid_at,
    refunded_at
  FROM platform_order
  WHERE paid_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND paid_at <  TIMESTAMP '2026-11-01 00:00:00'
)
SELECT
  s.channel_code,
  COUNT(DISTINCT s.session_id) AS sessions,
  COUNT(DISTINCT s.user_id) AS users,
  COUNT(DISTINCT CASE WHEN o.order_id IS NOT NULL THEN s.session_id END) AS converted_sessions,
  SUM(COALESCE(o.paid_amount, 0)) AS attributed_gmv,
  SUM(COALESCE(o.refund_amount, 0)) AS refund_amount,
  SUM(COALESCE(o.paid_amount, 0) - COALESCE(o.refund_amount, 0))
    / NULLIF(COUNT(DISTINCT s.session_id), 0) AS net_gmv_per_session,
  COUNT(DISTINCT CASE WHEN s.device_id <> s.user_id THEN s.device_id END) AS cross_device_sessions
FROM session_scope s
LEFT JOIN order_fact o USING (order_id, user_id)
GROUP BY s.channel_code;`];
    }
    if (kind === "sql-hospital") {
      return ["sql", `WITH encounter_scope AS (
  SELECT
    encounter_id,
    patient_id,
    department_code,
    payer_type,
    admitted_at,
    discharged_at,
    discharge_status,
    total_charge_amount,
    drg_group_code
  FROM hospital_encounter
  WHERE admitted_at >= TIMESTAMP '2026-10-01 00:00:00'
    AND admitted_at <  TIMESTAMP '2026-11-01 00:00:00'
), claim_fact AS (
  SELECT
    encounter_id,
    SUM(submitted_amount) AS submitted_amount,
    SUM(approved_amount) AS approved_amount,
    SUM(denied_amount) AS denied_amount,
    COUNT(DISTINCT claim_id) AS claims
  FROM hospital_insurance_claim
  GROUP BY encounter_id
)
SELECT
  e.payer_type,
  e.department_code,
  COUNT(DISTINCT e.encounter_id) AS encounters,
  SUM(e.total_charge_amount) AS total_charges,
  SUM(c.submitted_amount) AS submitted_amount,
  SUM(c.approved_amount) AS approved_amount,
  SUM(c.denied_amount) AS denied_amount,
  SUM(c.denied_amount) / NULLIF(SUM(c.submitted_amount), 0) AS denial_rate,
  AVG(EXTRACT(EPOCH FROM (e.discharged_at - e.admitted_at)) / 86400.0) AS avg_los_days,
  COUNT(DISTINCT e.drg_group_code) AS drg_groups
FROM encounter_scope e
LEFT JOIN claim_fact c USING (encounter_id)
GROUP BY e.payer_type, e.department_code;`];
    }
    if (kind === "sql-market") {
      return ["sql", `WITH price_scope AS (
  SELECT
    security_id,
    trade_date,
    close_price,
    adjustment_factor,
    currency_code,
    price_rule_version
  FROM market_price_daily
  WHERE trade_date BETWEEN DATE '2026-09-01' AND DATE '2026-10-31'
), return_series AS (
  SELECT
    security_id,
    trade_date,
    close_price * adjustment_factor AS adjusted_price,
    close_price / LAG(close_price) OVER (
      PARTITION BY security_id ORDER BY trade_date
    ) - 1 AS daily_return,
    currency_code,
    price_rule_version
  FROM price_scope
)
SELECT
  security_id,
  currency_code,
  COUNT(*) AS trading_days,
  STDDEV_SAMP(daily_return) * SQRT(252) AS annualized_volatility,
  MIN(daily_return) AS worst_day,
  APPROX_PERCENTILE(daily_return, 0.05) AS var_95_daily,
  COUNT(DISTINCT price_rule_version) AS price_rule_versions,
  CASE WHEN COUNT(*) < 20 THEN 'INSUFFICIENT_HISTORY'
       WHEN COUNT(DISTINCT price_rule_version) > 1 THEN 'PRICE_RULE_CHANGED'
       ELSE 'READY' END AS risk_status
FROM return_series
WHERE daily_return IS NOT NULL
GROUP BY security_id, currency_code;`];
    }
    return ["sql", `WITH scoped AS (
  SELECT
    object_id,
    event_time,
    business_date,
    status_code,
    rule_version,
    metric_value
  FROM dwd_business_event
  WHERE business_date >= DATE '2026-10-01'
    AND business_date <  DATE '2026-11-01'
    AND status_code IN ('VALID', 'COMPLETED')
), checked AS (
  SELECT
    object_id,
    SUM(metric_value) AS metric_value,
    COUNT(*) AS event_count,
    COUNT(DISTINCT rule_version) AS rule_versions
  FROM scoped
  GROUP BY object_id
)
SELECT
  COUNT(*) AS objects,
  SUM(metric_value) AS total_value,
  SUM(event_count) AS events,
  SUM(CASE WHEN rule_versions > 1 THEN 1 ELSE 0 END) AS mixed_rule_objects
FROM checked;`];
  }
  if (kind === "kafka-ops") {
    return ["bash", `#!/usr/bin/env bash
set -euo pipefail

TOPIC="\${TOPIC:-orders}"
GROUP="\${GROUP:-order-enrichment-v1}"
BROKER="\${BROKER:-kafka-01:9092}"

kafka-consumer-groups.sh --bootstrap-server "$BROKER" \
  --describe --group "$GROUP" > "/tmp/\${GROUP}-lag-before.txt"

kafka-topics.sh --bootstrap-server "$BROKER" \
  --describe --topic "$TOPIC" > "/tmp/\${TOPIC}-partitions.txt"

awk 'NR > 1 {lag += $6; if ($6 > max) max = $6}
END {printf "total_lag=%s max_partition_lag=%s\\n", lag, max}' \
  "/tmp/\${GROUP}-lag-before.txt"`];
  }
  if (kind === "yaml-service") {
    return ["yaml", `apiVersion: apps/v1
kind: Deployment
metadata:
  name: data-service
spec:
  replicas: 3
  strategy:
    rollingUpdate:
      maxUnavailable: 0
      maxSurge: 1
  template:
    spec:
      containers:
        - name: api
          image: registry.example/data-service:2026.11.06
          envFrom:
            - secretRef:
                name: data-service-secrets
          readinessProbe:
            httpGet:
              path: /ready
              port: 8080
            periodSeconds: 5
          resources:
            requests: {cpu: "500m", memory: "512Mi"}
            limits: {cpu: "2", memory: "2Gi"}
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: data-service
spec:
  minAvailable: 2
  selector:
    matchLabels:
      app: data-service`];
  }
  if (kind === "pyspark") {
    if (/倾斜|热点|长尾|partition/i.test(profile.topic)) {
      return ["python", `from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark.sql.functions import spark_partition_id

events = spark.read.parquet("/warehouse/events/dt=2026-11-01")

skew = (
    events.groupBy("customer_id")
    .agg(
        F.count("*").alias("rows"),
        F.sum("amount").alias("amount"),
    )
    .withColumn("share", F.col("rows") / F.sum("rows").over(Window.partitionBy()))
    .orderBy(F.desc("share"))
)

top = skew.limit(1).collect()[0]
if top["share"] > 0.2:
    hot = events.filter(F.col("customer_id") == top["customer_id"])
    salted = hot.withColumn(
        "salt",
        (F.xxhash64("event_id") % F.lit(16)).cast("int"),
    )
    balanced = salted.repartition(16, "customer_id", "salt")
else:
    balanced = events

balanced.groupBy(spark_partition_id().alias("spark_partition")).count().show(
    20, truncate=False
)`];
    }
    if (/Shuffle|分区|并行|Stage|任务执行/i.test(profile.topic)) {
      return ["python", `from pyspark.sql import functions as F
from pyspark.sql.functions import spark_partition_id

orders = spark.read.parquet("/warehouse/orders/dt=2026-11-01")
items = spark.read.parquet("/warehouse/order_items/dt=2026-11-01")

partition_stats = (
    orders.repartition(64, "customer_id")
    .select(
        spark_partition_id().alias("partition_id"),
        F.col("order_id"),
        F.col("amount"),
    )
    .groupBy("partition_id")
    .agg(
        F.count("*").alias("rows"),
        F.sum("amount").alias("amount"),
    )
)

partition_stats.orderBy(F.desc("rows")).explain("formatted")
partition_stats.orderBy(F.desc("rows")).show(10, truncate=False)

joined = orders.join(items, on="order_id", how="inner")
joined.explain("cost")
assert joined.select("order_id").distinct().count() == items.select("order_id").distinct().count()`];
    }
    if (/Join|广播|关联|维表/i.test(profile.topic)) {
      return ["python", `from pyspark.sql import functions as F

facts = spark.read.parquet("/warehouse/fact_order/dt=2026-11-01")
dimension = spark.read.parquet("/warehouse/dim_product")

if dimension.count() <= 500_000:
    enriched = facts.join(F.broadcast(dimension), on="product_id", how="left")
else:
    enriched = facts.join(dimension.hint("merge"), on="product_id", how="left")

missing_dimension = enriched.filter(F.col("product_name").isNull()).count()
assert missing_dimension == 0, f"unmatched products: {missing_dimension}"`];
    }
    if (/缓存|Cache|Persist|复用/i.test(profile.topic)) {
      return ["python", `from pyspark import StorageLevel
from pyspark.sql import functions as F

base = (
    spark.read.parquet("/warehouse/events/dt=2026-11-01")
    .filter(F.col("event_time") >= "2026-11-01 00:00:00")
    .select("entity_id", "event_name", "amount", "event_time")
)

base.persist(StorageLevel.MEMORY_AND_DISK)
try:
    total = base.agg(F.sum("amount").alias("amount")).first()["amount"]
    active = base.filter(F.col("event_name") == "active").count()
    paying = base.filter(F.col("event_name") == "paid").count()
    assert active >= 0 and paying >= 0
finally:
    base.unpersist()

print({"amount": total, "active": active, "paying": paying})`];
    }
    return ["python", `from pyspark.sql import functions as F

source = spark.read.parquet("/warehouse/events/dt=2026-11-01")

before = (
    source.groupBy(F.date_trunc("hour", "event_time").alias("event_hour"))
    .agg(
        F.count("*").alias("rows"),
        F.sum("amount").alias("amount"),
        F.approx_count_distinct("object_id").alias("objects"),
    )
)

assert source.filter("event_time IS NULL OR object_id IS NULL").limit(1).count() == 0
before.orderBy("event_hour").show(24, truncate=False)

runtime = spark.sparkContext.statusTracker().getExecutorInfos()
active = [item for item in runtime if item.isActive()]
assert active, "no active executors"`];
  }
  if (kind === "flink-sql") {
    return ["sql", `CREATE TABLE source_events (
  event_id STRING,
  entity_id STRING,
  event_time TIMESTAMP(3),
  amount DECIMAL(18, 2),
  WATERMARK FOR event_time AS event_time - INTERVAL '20' SECOND
) WITH (
  'connector' = 'kafka',
  'topic' = 'business-events',
  'properties.bootstrap.servers' = 'kafka:9092',
  'format' = 'json'
);

CREATE TABLE sink_metrics (
  window_start TIMESTAMP(3),
  entity_id STRING,
  event_count BIGINT,
  total_amount DECIMAL(18, 2),
  PRIMARY KEY (window_start, entity_id) NOT ENFORCED
) WITH ('connector' = 'jdbc');

INSERT INTO sink_metrics
SELECT
  window_start,
  entity_id,
  COUNT(*) AS event_count,
  SUM(amount) AS total_amount
FROM TABLE(TUMBLE(TABLE source_events, DESCRIPTOR(event_time), INTERVAL '1' MINUTE))
GROUP BY window_start, entity_id;`];
  }
  if (kind === "python-recommendation") {
    return ["python", `from collections import defaultdict
from dataclasses import dataclass


@dataclass(frozen=True)
class Impression:
    request_id: str
    user_id: str
    item_id: str
    rank: int
    model_version: str
    exposed: bool
    clicked: bool


def evaluate_slices(rows: list[Impression]) -> dict[str, dict[str, float]]:
    report: dict[str, dict[str, float]] = defaultdict(
        lambda: {"impressions": 0.0, "clicks": 0.0, "reciprocal_rank": 0.0}
    )
    for row in rows:
        if not row.exposed:
            continue
        bucket = report[f"{row.model_version}:rank_{min(row.rank, 10):02d}"]
        bucket["impressions"] += 1
        bucket["clicks"] += int(row.clicked)
        bucket["reciprocal_rank"] += 1 / row.rank if row.clicked else 0

    for bucket in report.values():
        bucket["ctr"] = bucket["clicks"] / max(bucket["impressions"], 1)
        bucket["mrr"] = bucket["reciprocal_rank"] / max(bucket["impressions"], 1)
    return dict(report)


def position_bias_check(rows: list[Impression], max_rank: int = 10) -> dict[int, float]:
    by_rank = defaultdict(lambda: {"impressions": 0, "clicks": 0})
    for row in rows:
        if row.exposed and row.rank <= max_rank:
            by_rank[row.rank]["impressions"] += 1
            by_rank[row.rank]["clicks"] += int(row.clicked)
    return {
        rank: values["clicks"] / max(values["impressions"], 1)
        for rank, values in sorted(by_rank.items())
    }`];
  }
  if (kind === "python-digital-twin") {
    return ["python", `from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass(frozen=True)
class SensorPoint:
    equipment_id: str
    observed_at: datetime
    temperature_c: float
    vibration_mm_s: float
    state_code: str
    sequence_no: int


def align_to_equipment_clock(
    points: list[SensorPoint],
    max_latency_seconds: int = 30,
) -> list[SensorPoint]:
    accepted: list[SensorPoint] = []
    last_sequence: dict[str, int] = {}
    last_time: dict[str, datetime] = {}

    for point in sorted(points, key=lambda item: (item.equipment_id, item.observed_at)):
        previous_sequence = last_sequence.get(point.equipment_id, -1)
        previous_time = last_time.get(point.equipment_id)
        if point.sequence_no <= previous_sequence:
            continue
        if previous_time and point.observed_at < previous_time:
            continue
        if previous_time and point.observed_at - previous_time > timedelta(
            seconds=max_latency_seconds
        ):
            raise ValueError(f"telemetry gap detected: {point.equipment_id}")

        accepted.append(point)
        last_sequence[point.equipment_id] = point.sequence_no
        last_time[point.equipment_id] = point.observed_at

    return accepted


def estimate_degradation(points: list[SensorPoint]) -> dict[str, float]:
    running = [point for point in points if point.state_code == "RUNNING"]
    if len(running) < 3:
        return {"samples": float(len(running)), "trend": 0.0}
    vibration = [point.vibration_mm_s for point in running]
    mean_x = (len(vibration) - 1) / 2
    mean_y = sum(vibration) / len(vibration)
    numerator = sum(
        (index - mean_x) * (value - mean_y)
        for index, value in enumerate(vibration)
    )
    denominator = sum((index - mean_x) ** 2 for index in range(len(vibration)))
    return {"samples": float(len(running)), "trend": numerator / denominator}`];
  }
  if (kind === "python-rag") {
    return ["python", `from dataclasses import dataclass

@dataclass(frozen=True)
class EvalCase:
    query: str
    expected_document: str
    allowed_roles: frozenset[str]
    has_answer: bool

def evaluate(cases, retriever, answerer, role):
    metrics = {"hit_at_3": 0, "citation_supported": 0, "correct_refusal": 0, "leaks": 0}
    for case in cases:
        chunks = retriever.search(
            case.query,
            filters={"roles": case.allowed_roles & {role}},
        )
        metrics["hit_at_3"] += any(
            item.document_id == case.expected_document for item in chunks[:3]
        )
        metrics["leaks"] += sum(role not in item.allowed_roles for item in chunks)
        result = answerer.answer(case.query, chunks)
        metrics["citation_supported"] += bool(result.citations) and all(
            citation.supported for citation in result.citations
        )
        metrics["correct_refusal"] += (
            not result.answered if not case.has_answer else result.answered
        )
    return metrics`];
  }
  if (kind === "python-agent") {
    return ["python", `from dataclasses import dataclass

@dataclass(frozen=True)
class ToolCall:
    name: str
    arguments: dict

ALLOWED = {
    "search_metrics": {"read"},
    "query_service": {"read"},
}

def authorize(call: ToolCall, actor_scopes: set[str]) -> None:
    required = ALLOWED.get(call.name)
    if required is None:
        raise PermissionError(f"tool not registered: {call.name}")
    if not required <= actor_scopes:
        raise PermissionError("insufficient scope")
    if call.name == "query_service":
        if not call.arguments.get("sql", "").lstrip().lower().startswith("select"):
            raise ValueError("only read-only SQL is accepted")

def execute_with_audit(call, actor, executor, audit):
    authorize(call, actor.scopes)
    audit.record(actor.id, call.name, call.arguments, status="started")
    try:
        result = executor.run(call, timeout_seconds=20)
        audit.record(actor.id, call.name, call.arguments, status="succeeded")
        return result
    except Exception as exc:
        audit.record(actor.id, call.name, call.arguments, status="failed", error=str(exc))
        raise`];
  }
  if (kind === "python-ml" || kind === "python-ai" || kind === "python-ai-governance") {
    return ["python", `from datetime import datetime

def validate_training_rows(rows, decision_at):
    for row in rows:
        assert row.feature_as_of <= decision_at, "feature timestamp leaks future data"
        assert row.label_observed_at > decision_at, "label must be observed later"
        assert row.data_version, "training data version is required"
        assert row.consent_scope, "data authorization is required"

def evaluate_slices(predictions, threshold=0.5):
    report = {}
    for row in predictions:
        bucket = report.setdefault(row.risk_slice, {"n": 0, "tp": 0, "fp": 0, "fn": 0})
        predicted = row.score >= threshold
        bucket["n"] += 1
        bucket["tp"] += predicted and row.actual
        bucket["fp"] += predicted and not row.actual
        bucket["fn"] += (not predicted) and row.actual
    return report`];
  }
  if (kind === "yaml-model") {
    return ["yaml", `model_contract:
  name: sales_order_line_fact
  version: "2026.11"
  owner: enterprise_data_architecture
  domain_owner: order_management
  business_process: 订单履约
  grain:
    description: 一行代表一个订单行在一次有效履约版本中的业务事实
    business_key: [order_id, order_line_id, fulfillment_version]
  fact:
    columns:
      - {name: business_date, type: date, meaning: 业务发生日期}
      - {name: load_timestamp, type: timestamp, meaning: 入仓处理时间}
      - {name: ordered_qty, type: decimal, additive: true}
      - {name: unit_price, type: decimal, additive: false}
  conformity_dimensions:
    customer: {dimension: dim_customer, scd_type: 2, effective_from: valid_from, effective_to: valid_to}
    product: {dimension: dim_product, scd_type: 2, effective_from: valid_from, effective_to: valid_to}
    organization: {dimension: dim_organization, scd_type: 3, history_columns: [previous_org_id]}
  bus_matrix:
    business_process: order_fulfillment
    reused_dimensions: [customer, product, organization, date]
    downstream_facts: [invoice_fact, shipment_fact, return_fact]
  quality_gates:
    - grain_uniqueness_must_equal_100_percent
    - business_date_and_load_timestamp_must_be_separated
    - scd_effective_range_must_not_overlap
    - downstream_impact_analysis_required_on_breaking_change
  compatibility:
    additive_change: auto_review
    rename_or_type_change: versioned_migration
    deletion: downstream_signoff_required`];
  }
  if (kind === "yaml-governance") {
    return ["yaml", `governed_data_asset:
  asset_id: metric:net_revenue:2026.11
  owner: finance_data_office
  steward: revenue_analytics
  classification: internal
  definition:
    entity: paid_order
    time_window: business_date
    numerator: paid_amount - approved_refund_amount - tax_amount
    exclusions: [test_order, cancelled_order]
    rule_version: 2026.11
  lineage:
    upstream: [dwd_order_payment, dim_product, dim_organization]
    downstream: [finance_month_close, merchant_scorecard]
    interface_consumers: [metric_api_v2]
  controls:
    freshness_sla_minutes: 120
    completeness_threshold: 0.995
    reconciliation_owner: finance_reconciliation
    access_purpose: reporting_only
  change_policy:
    require_impact_analysis: true
    require_consumer_signoff: true
    rollback_artifact: previous_metric_contract`];
  }
  if (kind === "yaml-manufacturing") {
    return ["yaml", `manufacturing_event_contract:
  version: "2026.11"
  site_scope: [plant_a, plant_b]
  isa95_boundary:
    level_3: mes
    level_2: scada
    level_1: equipment_controller
  event:
    key: [equipment_id, sequence_no]
    time_fields: [equipment_event_time, edge_received_at, mes_recorded_at]
    state_mapping:
      RUN: running
      STOP: planned_or_unplanned
      FAULT: unplanned
  controls:
    - equipment_clock_offset_under_1000_ms
    - duplicate_sequence_must_be_rejected
    - work_order_batch_trace_required
    - production_quantity_must_balance_with_scrap_and_rework
  replay:
    source_offset_required: true
    idempotency_key: [equipment_id, sequence_no]
    stop_on_schema_mismatch: true`];
  }
  if (kind === "yaml-schedule") {
    return ["yaml", `daily_data_pipeline:
  version: "2026.11"
  timezone: Asia/Shanghai
  trigger: data_partition_ready
  dependencies:
    - dataset: ods_order
      partition: "{{ ds }}"
      freshness_minutes: 30
    - dataset: dim_product
      snapshot_version: latest_stable
  tasks:
    - name: validate_source
      stop_on: [missing_partition, schema_change, duplicate_primary_key]
    - name: build_fact
      idempotency_key: business_date
      write_mode: overwrite_partition
    - name: reconcile
      checks: [row_count_tolerance, amount_balance, dimension_match_rate]
  failure_policy:
    retries: 2
    backoff_seconds: 60
    isolate_failed_partition: true
    alert_owner: data_oncall`];
  }
  if (kind === "yaml-project") {
    return ["yaml", `data_project_acceptance:
  project: business_data_product
  version: "2026.11"
  goal:
    decision: replace_manual_month_end_reconciliation
    baseline: current_cycle_and_error_log
    non_goals: [realtime_reporting, source_system_replacement]
  milestones:
    - {name: scope_approved, evidence: signed_scope_and_owner}
    - {name: pilot_ready, evidence: reconciled_sample_and_rollback}
    - {name: production_release, evidence: canary_and_oncall_handover}
  quality_gates:
    - source_target_reconciliation_passed
    - failure_replay_and_rollback_rehearsed
    - access_review_completed
  adoption:
    target_users: finance_operations
    training_artifact: runbook_and_office_hours
    success_evidence: weekly_active_use_and_closed_issues`];
  }
  return null;
}

function personalizeCode(code, profile, plan) {
  if (!code) return null;
  return code;
}

function verificationSection(profile, plan) {
  const { definition, subdomain } = plan;
  const lens = workbenchFor(plan);
  const sampleSize = 40 + (hash(`${profile.relativePath}:${profile.topic}:samples`) % 160);
  const rows = lens.verificationLabels.map((label, index) => {
    const object = definition.objects[index % definition.objects.length];
    const control = definition.controls[index % definition.controls.length];
    const metric = definition.metrics[index % definition.metrics.length];
    return [
      label,
      `抽查${sampleSize + index * 7}条${object}记录，并覆盖${subdomain.evidence[index % subdomain.evidence.length]}`,
      `由${definition.roles[index % definition.roles.length]}按${control}复算${metric}；同一输入必须得到同一分组、对象数和异常清单`,
      `${subdomain.traps[index % subdomain.traps.length]}出现，或${definition.systems[index % definition.systems.length]}无法解释时间、版本和责任时，停止使用该结论`
    ];
  });
  const lead = pick([
    `“${profile.topic}”的验收重点不是结果看起来是否合理，而是${lens.decisionQuestion}能否被证据逐项排除。`,
    `对“${profile.topic}”来说，一条结果曲线只能说明发生了什么，不能证明对象齐全、口径正确或失败已经恢复。`,
    `复核“${profile.topic}”时，应先固定${definition.objects.slice(0, 3).join("、")}，再分别检查时间、规则、数量和业务动作。`,
    `“${profile.topic}”一旦跨系统或跨团队使用，验收就必须让另一位同事能够只依赖${subdomain.evidence.slice(0, 3).join("、")}完成复算。`
  ], profile, "verification-lead");
  return `## ${profile.topic}的验收证据

${lead} 下面的检查顺序按${plan.definition.label}的实际交付方式设计，任何一层失败都先回到原始记录，不用总体均值或成功截图替代。

${table(
    lens.verificationHeaders,
    rows
  )}

${table(
    ["复核动作", `${profile.topic}的具体做法`, "结果解释"],
    [
      ["守恒检查", `比较${definition.objects[0]}的输入数、有效数、排除数、输出数和下游消费数，并要求每个差额有原因`, "差额无法解释时不进入业务归因"],
      ["版本回放", `重放${definition.stages[0]}到${definition.stages.at(-1)}，固定${definition.controls.slice(0, 3).join("、")}所对应的版本`, "未知版本、静默改口径或人工覆盖视为失败"],
      ["反例检查", `主动构造${subdomain.traps.slice(0, 3).join("、")}三类反例，保存修复前后样本`, "只有正常样本通过，不算完成验收"],
      ["业务确认", `由${definition.roles[0]}与${definition.roles[1]}分别确认${definition.metrics[0]}和${definition.metrics[1]}`, "业务动作、责任人与复核日期必须能回查"]
    ]
  )}

${list([
    `先做对象数和总量对账，再看“${profile.topic}”的分组分布；任何一项${definition.metrics[0]}变化都要能拆到结构、口径或真实业务变化。`,
    `至少留档一个正常样本、一个边界样本、一个${subdomain.traps[0]}样本和一次修复后的回放结果，保证“${profile.topic}”不是只对演示数据有效。`,
    `当${definition.metrics.slice(1, 4).join("、")}中任一护栏恶化时，即使主指标改善，也不能直接宣布“${profile.topic}”成功。`,
    `把本次复核使用的对象范围、规则版本、排除项和查询结果写成可交接记录，让未参与项目的同事可以独立复算。`
  ])}`;
}

function shouldUseCode(profile, plan) {
  if (!plan.subdomain.codeKind) return false;
  if (["career", "learning", "resume"].includes(profile.kind)) return false;
  if (/全景|概述|历史|基础概念|基本概念|入门|导读|导航|术语|词典|是什么|什么是|为什么|学习方法|成长路径|职业|简历|面试|介绍|定义|原则|思维|模式|业态|行业解析|制度|组织|职责|文化|成熟度|路线图/i.test(profile.topic)) {
    return false;
  }
  if (plan.family === "ai" && /伦理|合规|监管|政策|安全|组织|团队|职业/i.test(profile.topic)) {
    return false;
  }
  if (plan.family === "governance" && /制度|组织|职责|文化|成熟度|路线图|体系规划/i.test(profile.topic)) {
    return false;
  }
  return /率|分析|模型|指标|监控|优化|定位|排查|设计|架构|实现|开发|评估|治理|质量|口径|计算|查询|统计|实验|测试|回归|上线|部署|调优|倾斜|缓存|积压|迁移|转换|留存|漏斗|画像|GMV|ROI|OEE|库存|订单|会员|转化|复购|投放|渠道|成本|利润|收入|热力|滚动|曝光|点击|推荐|CTR|CVR|供应链|协同|预测|排程|追溯|归因|坪效|客服|工单|数字孪生|六西格玛|DMAIC|SPC|MSA|DOE|Cpk|ICU|慢病|理赔|信托|净值|分配|Spark|Kafka|Flink|SQL|ETL|CDC|API|RAG|Agent|MLOps|Embedding|数据服务|数据接口|主数据|数据标准|建设|规划|方案|落地|实施|建模|怎么|如何/i.test(profile.topic);
}

function implementationSection(profile, plan) {
  const { definition, subdomain } = plan;
  const lens = workbenchFor(plan);
  const code = shouldUseCode(profile, plan)
    ? personalizeCode(codeFor(profile, subdomain.codeKind, plan.family), profile, plan)
    : null;
  const sectionTitle = pick([
    `如何把${profile.topic}落到最小闭环`,
    `${profile.topic}从方案走到可验收交付`,
    `${profile.topic}的第一条可运行链路`,
    `${profile.topic}怎样用小范围试点形成证据`
  ], profile, "implementation-title");
  const codeIntro = code
    ? `代码只保留“${profile.topic}”最小判断链，复核重点是${definition.controls.slice(0, 3).join("、")}；表名、字段和日期必须换成本地样本，运行前还要确认权限与数据版本。`
    : `“${profile.topic}”更应先形成${lens.implementationLabels.slice(0, 3).join("、")}等可评审产物。没有明确对象和失败出口时，写代码只会把错误流程自动化。`;
  const implementationRows = lens.implementationLabels.map((label, index) => {
    const object = definition.objects[index % definition.objects.length];
    const stage = definition.stages[index % definition.stages.length];
    const control = definition.controls[index % definition.controls.length];
    const risk = definition.risks[index % definition.risks.length];
    return [
      label,
      `围绕${object}，在“${profile.topic}”中把${stage}拆成可执行动作；由${definition.roles[index % definition.roles.length]}确认输入、输出和例外`,
      `保留${subdomain.evidence[index % subdomain.evidence.length]}、${control}以及变更前后的${definition.metrics[index % definition.metrics.length]}`,
      `${risk}出现时停止扩展；先回到${definition.systems[index % definition.systems.length]}核对原始记录并重新评审`
    ];
  });
  return `## ${sectionTitle}

${codeIntro}

${table(
    ["实施环节", `${profile.topic}的具体动作`, "最小产物", "停止与返工条件"],
    implementationRows
  )}

${list([
    `先用一个${definition.objects[0]}样本走通“${profile.topic}”的${lens.implementationLabels[0]}，确认${subdomain.concepts[0]}已经落到字段、状态和责任人。`,
    `第二位执行者应能只看“${profile.topic}”的交接记录完成${lens.implementationLabels[1]}，并得到相同的${definition.metrics[0]}和异常清单。`,
    `只有在${definition.controls.slice(0, 2).join("、")}均通过后，才把范围扩到${definition.objects.slice(1, 3).join("、")}；否则保留失败样本并缩回试点。`,
    `完成后记录${subdomain.evidence.slice(0, 3).join("、")}、责任人、版本和下一次复核日期，让后续同事可以复跑而不是重建。`
  ])}

${code ? `\n${fence(code[0], code[1])}` : ""}`;
}

function operationsSection(profile, plan) {
  const { definition, subdomain } = plan;
  const lens = workbenchFor(plan);
  const cadenceOptions = plan.family === "manufacturing"
    ? ["每班", "每日", "每周", "每月"]
    : plan.family === "engineering" || plan.family === "ai"
      ? ["每 5 分钟", "小时级", "每日", "每次发布"]
      : ["每周", "每月", "每季度", "每次变更"];
  const cadenceShift = hash(`${profile.relativePath}:${profile.topic}:cadence`) % cadenceOptions.length;
  const operationRows = lens.operationLabels.map((label, index) => {
    const cadence = cadenceOptions[(index + cadenceShift) % cadenceOptions.length];
    const metric = definition.metrics[index % definition.metrics.length];
    const object = definition.objects[index % definition.objects.length];
    return [
      label,
      `${cadence}由${definition.roles[index % definition.roles.length]}检查${object}、${metric}和${subdomain.evidence[index % subdomain.evidence.length]}`,
      `保留${definition.controls[index % definition.controls.length]}、版本号、责任人和${definition.systems[index % definition.systems.length]}中的运行记录`,
      `${subdomain.traps[index % subdomain.traps.length]}出现，或${metric}连续两个观察周期偏离基线时，暂停扩大使用并升级复核`
    ];
  });
  const operationLead = pick([
    `${profile.topic}进入常态运行后，每周只需要回答三个问题：结果是否仍与业务现场一致，异常是否在承诺时间内闭环，下一轮是否值得扩大范围。`,
    `上线只是开始。针对${profile.topic}，日常要持续确认结果、版本、权限和业务动作没有悄悄偏离原来的假设。`,
    `稳定运行不靠某个人记住所有细节。需要把${profile.topic}的监控、升级、变更和价值复盘写成其他人也能执行的节奏。`,
    `当${profile.topic}被多个团队使用时，任何口径、状态或接口变化都可能影响下游，因此运行阶段必须同时看结果、副作用和采用情况。`
  ], profile, "operation-lead");
  return `## ${profile.topic}进入常态运行后

${operationLead}为避免结果变成“大屏装饰”，建议保留下面这张运行卡：

${table(
    lens.operationHeaders,
    operationRows
  )}

## ${profile.topic}的完成标准

只有当${definition.roles[(hash(`${profile.relativePath}:completion-owner`) % definition.roles.length)]}能够依据${definition.systems.slice(0, 2).join("和")}中的留档，重新确认“${profile.topic}”的${definition.objects[0]}范围，复算${definition.metrics[0]}与${definition.metrics[1]}，解释${subdomain.traps[0]}造成的差异，并按${definition.controls.slice(0, 2).join("、")}完成一次回退，这项交付才达到可运营状态。验收记录必须同时包含${subdomain.evidence.slice(0, 3).join("、")}、规则版本、责任人和下一次复核日期；缺少任何一项，都只能算演示完成，不能算生产可用。

${sourceSection(profile, definition)}`;
}

function renderSection(section, profile, plan) {
  switch (section) {
    case "opening":
      return openingSection(profile, plan);
    case "decisions":
      return decisionSection(profile, plan);
    case "mechanism":
      return mechanismSection(profile, plan);
    case "cases":
      return caseSection(profile, plan);
    case "implementation":
      return implementationSection(profile, plan);
    case "verification":
      return verificationSection(profile, plan);
    case "operations":
      return operationsSection(profile, plan);
    default:
      return "";
  }
}

function ensureRequiredTerms(markdown, profile) {
  if (/不良贷款率/.test(profile.topic) && !markdown.includes("迁徙率")) {
    return markdown.replace(
      "## 公开方法依据",
      "补充口径：迁徙率用于观察正常、关注、次级、可疑和损失类贷款在期间内的下迁与上迁，应与五级分类快照、逾期天数和重组标识一起复核。\n\n## 公开方法依据"
    );
  }
  return markdown;
}

function buildTitleSpecificArticle(profile) {
  const plan = planFor(profile);
  const familyArticle = buildTitleFamilyArticle(profile, plan);
  if (familyArticle) return ensureRequiredTerms(familyArticle, profile);
  const markdown = plan.structure.order
    .map((section) => renderSection(section, profile, plan))
    .filter(Boolean)
    .join("\n\n");
  return ensureRequiredTerms(markdown, profile);
}

module.exports = {
  buildTitleSpecificArticle,
  planFor,
  familyOf,
  subdomainOf
};
