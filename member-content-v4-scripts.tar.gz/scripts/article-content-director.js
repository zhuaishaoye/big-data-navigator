const { matchSpecialized, familyGroup } = require("./title-deep-dive");
const {
  buildClassificationArticle,
  buildRealtimeWarehouseArticle,
  buildPerformanceArticle,
  buildQualityRuleArticle,
  buildLineageImpactArticle
} = require("./specialized-topic-renderers");

const OPENINGS = [
  (profile) => `“${profile.topic}”真正难的地方，通常不是把名词解释清楚，而是在不同系统、不同岗位和不同时间点之间，仍能说清同一个对象发生了什么。`,
  (profile) => `讨论“${profile.topic}”时，最容易出现的误区是先选工具、先画大图，再回头寻找业务问题；更稳妥的顺序是先确定决策、证据和失败边界。`,
  (profile) => `把“${profile.topic}”放进真实工作，问题往往会落成三句话：谁来用，依据什么数据做决定，做错后如何发现并恢复。`,
  (profile) => `一篇有用的“${profile.topic}”指南，不应只给出定义，还要让读者知道对象如何识别、流程如何流转、结果如何验收，以及哪些情况必须停下来。`,
  (profile) => `“${profile.topic}”在面试里可能是一道概念题，在工作中却会同时牵动口径、链路、权限、成本和责任边界。`,
  (profile) => `如果只记住“${profile.topic}”的结论，换个业务场景就很容易失效；真正可迁移的是判断顺序和证据链。`
];

const GENERIC_SOURCE_GROUPS = {
  data: [
    ["NIST Big Data Interoperability Framework", "https://www.nist.gov/programs-projects/nist-big-data-interoperability-framework"],
    ["Google Cloud Architecture Framework", "https://cloud.google.com/architecture/framework"],
    ["OpenTelemetry Documentation", "https://opentelemetry.io/docs/"]
  ],
  modeling: [
    ["DAMA-DMBOK 数据管理知识体系", "https://www.dama.org/cpages/body-of-knowledge"],
    ["The Open Group TOGAF Standard", "https://www.opengroup.org/togaf"],
    ["NIST Enterprise Architecture", "https://www.nist.gov/programs-projects/enterprise-architecture"]
  ],
  ecommerce: [
    ["AWS E-commerce Architecture Center", "https://aws.amazon.com/solutions/ecommerce/"],
    ["Google Cloud Architecture Framework", "https://cloud.google.com/architecture/framework"],
    ["Microsoft Cloud Design Patterns", "https://learn.microsoft.com/azure/architecture/patterns/"]
  ],
  identity: [
    ["NIST Digital Identity Guidelines", "https://pages.nist.gov/800-63-4/"],
    ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"],
    ["IAB Tech Lab Data Transparency Standards", "https://iabtechlab.com/standards/"]
  ],
  ai: [
    ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"],
    ["Google Rules of Machine Learning", "https://developers.google.com/machine-learning/guides/rules-of-ml"],
    ["Microsoft RAG Solution Design", "https://learn.microsoft.com/azure/architecture/ai-ml/guide/rag/"]
  ],
  technology: [
    ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"],
    ["Microsoft Cloud Design Patterns", "https://learn.microsoft.com/azure/architecture/patterns/"],
    ["AWS Well-Architected Framework", "https://aws.amazon.com/architecture/well-architected/"]
  ],
  engineering: [
    ["Apache Spark Documentation", "https://spark.apache.org/docs/latest/"],
    ["Apache Kafka Documentation", "https://kafka.apache.org/documentation/"],
    ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"],
    ["OpenAPI Specification", "https://spec.openapis.org/oas/latest.html"]
  ],
  finance: [
    ["IFRS 9 Financial Instruments", "https://www.ifrs.org/issued-standards/list-of-standards/ifrs-9-financial-instruments/"],
    ["IFRS 13 Fair Value Measurement", "https://www.ifrs.org/issued-standards/list-of-standards/ifrs-13-fair-value-measurement/"],
    ["BIS Statistics", "https://www.bis.org/statistics/"],
    ["中国人民银行统计数据", "https://www.pbc.gov.cn/diaochatongjisi/"]
  ],
  manufacturing: [
    ["ISA-95 Enterprise-Control System Integration", "https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard"],
    ["ISO 22400 Manufacturing Operations Management", "https://www.iso.org/standard/54497.html"],
    ["NIST Smart Manufacturing Programs", "https://www.nist.gov/programs-projects/smart-manufacturing"]
  ],
  healthcare: [
    ["国家卫生健康委员会统计数据", "https://www.nhc.gov.cn/wjw/gjwsb/list.shtml"],
    ["HL7 FHIR Specification", "https://hl7.org/fhir/"],
    ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"]
  ],
  retail: [
    ["Google Analytics Event Measurement", "https://support.google.com/analytics/answer/9355655"],
    ["IAB OpenRTB Standard", "https://iabtechlab.com/standards/openrtb/"],
    ["Trustworthy Online Controlled Experiments", "https://experimentguide.com/"]
  ],
  work: [
    ["Google re:Work People Operations Guides", "https://rework.withgoogle.com/"],
    ["NIST NICE Workforce Framework", "https://www.nist.gov/nice"],
    ["O*NET OnLine", "https://www.onetonline.org/"]
  ]
};

function hashNumber(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function pick(items, seed, offset = 0) {
  if (!items?.length) return null;
  return items[(seed + offset) % items.length];
}

function esc(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

function fence(language, code) {
  return `\`\`\`${language}\n${String(code).trim()}\n\`\`\``;
}

function table(headers, rows) {
  return [
    `| ${headers.map(esc).join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${row.map(esc).join(" | ")} |`)
  ].join("\n");
}

function bulletList(items) {
  return items.map((item) => `- ${item}`).join("\n");
}

function numberedList(items) {
  return items.map((item, index) => `${index + 1}. ${item}`).join("\n");
}

function references(profile, extra = []) {
  const seen = new Set();
  const sources = [
    ...extra,
    ...(profile.specialty?.sources || []),
    ...(GENERIC_SOURCE_GROUPS[sourceGroup(profile)] || GENERIC_SOURCE_GROUPS.data)
  ].filter(([name, url]) => {
    const key = `${name}|${url}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 6);
  return `## 公开资料与核对建议

${sources.map(([name, url]) => `- [${name}](${url})`).join("\n")}

- 企业内部资料应优先核对当前版本的数据字典、业务流程图、指标口径、权限制度、事故复盘和变更记录。
- 搜索结果适合用来建立方法与术语背景，不应把营销文章、匿名截图或无法确认版本的案例直接当成生产依据。
- 本文中的组织与案例均为脱敏复合场景，不复制来源网站的付费隐藏正文，也不把示例数字包装成真实客户成果。`;
}

function sourceGroup(profile) {
  const recipe = recipeOf(profile);
  if (["enterprise-modeling", "architecture", "warehouse", "metric"].includes(recipe)) return "modeling";
  if (recipe === "ecommerce-architecture") return "ecommerce";
  if (recipe === "user-profile") return "identity";
  if (recipe === "ai") return "ai";
  if (["career", "resume", "learning"].includes(recipe)) return "work";
  if (["engineering", "sql", "spark", "streaming"].includes(recipe)) return "engineering";
  if (recipe === "governance") return "technology";
  if (/基金|净值|资产|负债|权益|会计|IFRS|金融|银行|保险|证券|信贷|支付/.test(`${profile.title} ${profile.relativePath}`)) return "finance";
  if (/制造|生产|工厂|设备|OEE|MES|ISA-95|车间|质量追溯/.test(`${profile.title} ${profile.relativePath}`)) return "manufacturing";
  if (/医疗|医院|临床|患者|医保|检验|药品|健康/.test(`${profile.title} ${profile.relativePath}`)) return "healthcare";
  if (/零售|电商|门店|渠道|会员|营销|广告|用户增长|转化/.test(`${profile.title} ${profile.relativePath}`)) return "retail";
  if (recipe === "industry") return "data";
  return "data";
}

function recipeOf(profile) {
  const title = profile.topic;
  const path = profile.relativePath;
  if (/企业级建模方法论|企业数据建模|企业级数据模型/.test(title)) return "enterprise-modeling";
  if (/电商数据架构案例|电商.*数据架构|零售电商.*数据架构/.test(title)) return "ecommerce-architecture";
  if (/用户画像数据开发案例|用户画像.*开发|标签体系.*开发|OneID.*开发/.test(title)) return "user-profile";
  if (/指标字典|指标口径|指标定义|指标平台|指标服务|语义层/.test(title)) return "metric";
  if (/简历|CV模板|作品集/.test(title)) return "resume";
  if (/求职|面试|职业|薪资|转行|晋升|岗位|职场|团队管理|沟通|影响力/.test(title)) return "career";
  if (/学习路线|学习路径|成长路线|能力地图|快速入门|学习方法|知识管理/.test(title)) return "learning";
  if (/大模型|LLM|RAG|Agent|智能体|Prompt|向量|机器学习|深度学习|模型评估|微调/.test(title)) return "ai";
  if (/数据分类分级|数据分级|敏感字段|敏感数据|个人信息识别|数据分类/.test(title)) return "classification";
  if (/实时数仓|实时数据仓库|实时架构|流批一体|实时链路/.test(title)) return "realtime-warehouse";
  if (/数据质量|质量门禁|质量监控|异常检测|数据漂移/.test(title)) return "quality";
  if (/血缘|元数据|数据目录|影响分析/.test(title)) return "lineage";
  if (/性能优化|慢任务|长尾|数据倾斜|小文件|Spill|执行计划|资源调优|查询优化|任务调优/.test(title)) return "performance";
  if (/主数据|数据标准|数据合约|数据编码|分类分级|数据安全|权限|隐私|合规|审计/.test(title)) return "governance";
  if (/Spark|RDD|DataFrame|Shuffle|Executor|宽依赖|窄依赖/.test(title)) return "spark";
  if (/Flink|流处理|实时计算|Structured Streaming|Kafka|水位线|双流/.test(title)) return "streaming";
  if (/\bSQL\b|窗口函数|执行计划|连续活跃|TopN|行列转换|Join|CTE/.test(title)) return "sql";
  if (/数据仓库|维度建模|数据湖|湖仓|数据分层|数据架构|数据中台|数据网格/.test(title)) return "architecture";
  if (/调度|补数|数据DevOps|数据CI-CD|发布管理|工作流/.test(title)) return "engineering";
  if (profile.kind === "project" || path.startsWith("【项目实战库】/")) return "project";
  if (profile.kind === "industry") return "industry";
  if (profile.kind === "analytics") return "analytics";
  if (profile.kind === "engineering") return "engineering";
  if (profile.kind === "governance") return "governance";
  return "general";
}

function sectionHeading(profile, base, variants) {
  return pick(variants || [base], profile.seed + hashNumber(base));
}

function articleLead(profile, extra = "") {
  const opening = pick(OPENINGS, profile.seed)(profile);
  const specialty = profile.specialty?.label || "业务与数据方法";
  return `# ${profile.title}

> [!abstract] ${profile.topic}：从业务问题到可验证交付
> ${opening}

本文按“${specialty}”处理这个标题，重点不在堆叠术语，而在说明**对象、流程、口径、证据和行动**如何形成闭环。${extra}`;
}

function objectRows(profile) {
  const context = profile.context;
  return context.entities.slice(0, 5).map(([name, key], index) => [
    name,
    `\`${key}\``,
    index === 0 ? "核心业务对象" : index < 3 ? "过程或交易对象" : "结果或证据对象",
    context.stages[index % context.stages.length],
    context.controls[index % context.controls.length]
  ]);
}

function commonObjectSection(profile) {
  const rows = objectRows(profile);
  return `## ${sectionHeading(profile, "先把对象和粒度说清", [
    "对象、粒度与主键：先定义一行数据",
    "数据边界：哪些对象不能混算",
    `从${profile.context.entities[0][0]}开始建立对象清单`
  ])}

“${profile.topic}”的第一张设计表不应是宽表，而应是对象清单。至少要回答每个对象由谁创建、什么事件推进状态、主键能否跨系统关联、历史是否保留版本，以及删除或撤销后如何表达。

${table(
    ["业务对象", "候选主键", "角色", "流程位置", `与${profile.topic}相关的检查`],
    rows
  )}

这里的检查不是字段清单，而是防止指标失真的约束。例如，事实事件的粒度如果是“事件”，就不能与“订单日快照”直接相加；维度如果使用当前组织关系回溯历史，就会让过去月份的数据随今天的组织调整而变化。`;
}

function businessQuestionSection(profile) {
  const context = profile.context;
  const questions = [
    `谁会在什么决策节点使用“${profile.topic}”的结果？`,
    `${context.participants.slice(0, 3).join("、")}之间是否存在口径或责任分歧？`,
    `结果的时间窗、对象范围和排除项是否已经固定？`,
    `异常发生后，是先冻结业务动作、回查数据，还是先调整模型？`,
    `哪类错误必须阻断发布，谁有权批准例外？`
  ];
  return `## ${sectionHeading(profile, "业务问题与决策出口", [
    "从决策倒推数据需求",
    "先问谁做决定，再问建什么表",
    "分析目标、使用者和行动边界"
  ])}

围绕“${profile.topic}”，一份可执行的需求至少要回答以下问题：

${numberedList(questions)}

以${context.scene}为例，业务变化会同时经过${context.stages.slice(0, 5).join("、")}等环节。数据团队如果只接到“做一个看板”或“分析一下原因”的要求，应该先把动作翻译成可观测对象：比较哪个指标、固定哪段时间、按哪些维度拆分、出现什么结果时采取什么行动。`;
}

function metricRows(profile) {
  const context = profile.context;
  const metrics = profile.specialty?.metric
    ? [[profile.specialty.metric.name, profile.specialty.metric.formula, "主题指标"]]
    : context.metricDefs.slice(0, 4);
  return metrics.map(([name, formula, alias], index) => [
    name,
    formula,
    context.dims[index % context.dims.length],
    index === 0 ? "先验对象与状态" : "同时查看分子、分母和样本量",
    profile.context.risks[index % profile.context.risks.length]
  ]);
}

function metricSection(profile) {
  return `## ${sectionHeading(profile, "指标、样本与解释边界", [
    "把指标写成可复跑的口径卡",
    "指标不只是公式：粒度、时间和排除项同样重要",
    `${profile.topic}的观测指标与失真点`
  ])}

${table(
    ["指标", "建议公式", "首要维度", "解释要求", "常见失真"],
    metricRows(profile)
  )}

比例指标应同时展示分子、分母和有效样本量；金额指标要检查守恒和重复冲减；时长指标要区分业务发生时间、数据可见时间和处理完成时间。只报一个结果值，通常无法支撑可靠决策。`;
}

function genericCase(profile, index, recipe) {
  const context = profile.context;
  const entity = context.entities[index % context.entities.length];
  const secondary = context.entities[(index + 1) % context.entities.length];
  const stageA = context.stages[index % context.stages.length];
  const stageB = context.stages[(index + 2) % context.stages.length];
  const control = context.controls[index % context.controls.length];
  const risk = context.risks[index % context.risks.length];
  const metric = context.metricDefs[index % context.metricDefs.length];
  const scenarios = [
    {
      title: `场景一：${stageA}之后，${entity[0]}口径突然分叉`,
      opening: `某团队在复盘“${profile.topic}”时发现，同一周的两份结果都在引用${entity[0]}，但一份按业务发生时间，一份按数据入仓时间。`,
      investigation: `先冻结比较范围，再检查\`${entity[1]}\`、状态字典和${control}。把差异拆成跨期、重复、撤销和维度归属四类，并对每一类抽取${secondary[0]}明细回查。`,
      action: `在口径卡中固定对象、时间字段、状态和排除项；对历史结果保留版本。只有${metric[0]}在相同粒子度下可重算，才进入正式讨论。`,
      lesson: `这类问题通常不是“数据不准”，而是两个团队回答了不同问题。`
    },
    {
      title: `场景二：从${stageA}到${stageB}，链路显示成功但结果迟到`,
      opening: `任务状态全部成功，下游却连续收到“${profile.topic}”结果缺失的反馈。团队需要判断问题出在源事件、接入水位、计算逻辑还是服务缓存。`,
      investigation: `把业务时间、数据可见时间、任务完成时间和下游读取时间放在一条时间轴上，核对${context.systems.slice(0, 3).join("、")}中的批次、分区和版本；同时检查${risk}是否让错误结果继续扩散。`,
      action: `先隔离受影响分区并保留旧版本，再用幂等任务从最小范围恢复。补数前后都检查${secondary[0]}数量、金额或状态对账，不能只凭调度页“成功”。`,
      lesson: `可恢复性不是出事后能重跑，而是能准确说明影响范围和重跑结果是否完整。`
    },
    {
      title: `场景三：${metric[0]}变化后，怎样避免错误归因`,
      opening: `“${profile.topic}”上线一段时间后，${metric[0]}出现变化，但同期还有活动、季节性和数据结构调整，团队需要判断变化是否来自本次方案。`,
      investigation: `在行动前冻结观察窗口和分组规则，比较总体、分层与明细；同时查看样本量、基线、护栏指标和反例。若涉及实验，还要检查分流是否稳定、是否有其他版本同时生效。`,
      action: `把“观察到的变化”和“由方案带来的增量”分开表达。只有当作用机制、时间顺序和分组结果能够相互解释时，才扩大使用范围。`,
      lesson: `业务结果变好不等于方案有效。没有反事实、基线或清晰机制时，应降低结论强度。`
    },
    {
      title: `场景四：${control}失效后的发布门禁`,
      opening: `一次小范围测试暴露了“${profile.topic}”的边界问题：空值、重复、撤销或跨期样本在常规日期没有出现，但一旦进入月末或异常流程，${metric[0]}就无法解释。`,
      investigation: `建立正常、边界、重复、缺失、撤销、越权和失败恢复七类样本；为每类规则记录阈值、责任人、阻断动作和有期限的例外。`,
      action: `关键规则失败时停止发布，先修数据和逻辑，再决定是否允许业务例外。修复后重新跑完整回归样本，而不只验证出问题的那一条记录。`,
      lesson: `质量门禁的价值在于让错误停留在可控边界内，而不是让报表在短时间内看起来正常。`
    }
  ];
  if (recipe === "governance" || recipe === "quality" || recipe === "lineage" || recipe === "metric") {
    scenarios[1].opening = `治理评审发现，“${profile.topic}”在制度里有定义，但字段、责任人和变更通知没有进入实际运行流程，${risk}因此反复出现。`;
    scenarios[1].action = `把定义、负责人、版本、审批、冲突处理和下线条件写入可执行的数据契约；对消费方做一次破坏性变更演练，验证通知和回退是否有效。`;
  }
  if (recipe === "career" || recipe === "learning") {
    scenarios[0].opening = `一位准备使用“${profile.topic}”解决问题的候选人，在复述方法时很流畅，但被追问证据、个人贡献和失败复盘时无法给出具体细节。`;
    scenarios[0].action = `把经验整理成“背景、目标、约束、个人动作、结果证据、边界”六段式，删除无法证明的数字和模糊的团队化表达。`;
  }
  return `### 案例 ${index + 1}：${scenarios[index].title}

**触发。** ${scenarios[index].opening}

**排查。** ${scenarios[index].investigation}

**处理。** ${scenarios[index].action}

**可迁移结论。** ${scenarios[index].lesson}`;
}

function casesSection(profile, recipe, count = null) {
  const chosenCount = count ?? (2 + profile.seed % 3);
  const cases = Array.from({ length: chosenCount }, (_, index) => genericCase(profile, index, recipe));
  const heading = pick([
    "脱敏工作场景：从现象走到证据",
    "四个常见现场与处理顺序",
    "案例复盘：口径、链路、决策和门禁",
    "把方法放回真实工作：场景拆解"
  ], profile.seed);
  return `## ${heading}

> 以下场景用于说明方法，不对应任何单一企业、客户或员工事实。组织名称被刻意省略，重点是可复用的判断过程。

${cases.join("\n\n")}`;
}

function genericSql(profile) {
  const context = profile.context;
  const entity = context.entities[0][1];
  const dim = context.dims[profile.seed % context.dims.length];
  const date = context.dateField;
  return `-- ${profile.topic}：对象粒度、状态和结果对账
WITH scoped AS (
    SELECT
        ${entity} AS entity_key,
        event_id,
        ${date} AS event_time,
        ${dim} AS analysis_dim,
        status,
        metric_value
    FROM ${context.factTable}
    WHERE ${date} >= :start_time
      AND ${date} <  :end_time
      AND subject_key = '${profile.idSuffix}'
),
dedup AS (
    SELECT *
    FROM (
        SELECT
            scoped.*,
            ROW_NUMBER() OVER (
                PARTITION BY event_id
                ORDER BY event_time DESC
            ) AS version_no
        FROM scoped
    ) ranked
    WHERE version_no = 1
)
SELECT
    analysis_dim,
    COUNT(DISTINCT entity_key) AS entity_cnt,
    COUNT(DISTINCT event_id) AS event_cnt,
    SUM(CASE WHEN status IN ('valid', 'completed') THEN metric_value ELSE 0 END) AS metric_sum,
    SUM(CASE WHEN status IS NULL THEN 1 ELSE 0 END) AS null_status_cnt
FROM dedup
GROUP BY analysis_dim
HAVING SUM(CASE WHEN status IS NULL THEN 1 ELSE 0 END) > 0
ORDER BY entity_cnt DESC;`;
}

function sqlTopicCode(profile) {
  if (/窗口函数|连续活跃|TopN|排名|累计|同比|环比/.test(profile.topic)) {
    return `-- ${profile.topic}：用窗口函数保留对象的时间顺序
WITH ranked AS (
    SELECT
        user_id,
        event_date,
        metric_value,
        ROW_NUMBER() OVER (
            PARTITION BY user_id
            ORDER BY event_date
        ) AS event_seq,
        SUM(metric_value) OVER (
            PARTITION BY user_id
            ORDER BY event_date
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS cumulative_value,
        LAG(event_date) OVER (
            PARTITION BY user_id
            ORDER BY event_date
        ) AS previous_event_date
    FROM user_daily_metric
    WHERE event_date >= :start_date
      AND event_date <  :end_date
)
SELECT
    user_id,
    event_date,
    cumulative_value,
    event_date - previous_event_date AS days_since_previous,
    CASE
        WHEN previous_event_date IS NULL THEN 'first_seen'
        WHEN event_date - previous_event_date = 1 THEN 'continuous'
        ELSE 'restarted'
    END AS activity_state
FROM ranked
ORDER BY user_id, event_date;`;
  }
  return genericSql(profile);
}

function sparkCode(profile) {
  return `# ${profile.topic}：显式控制分区、Shuffle 与输出幂等
from pyspark.sql import SparkSession, functions as F

spark = (
    SparkSession.builder
    .appName("${profile.idSuffix}-spark-check")
    .config("spark.sql.adaptive.enabled", "true")
    .config("spark.sql.shuffle.partitions", "200")
    .getOrCreate()
)

event = (
    spark.read.parquet("/warehouse/event/dt={{ ds }}")
    .where(F.col("subject_key") == "${profile.idSuffix}")
    .withColumn(
        "version_no",
        F.row_number().over(
            __import__("pyspark.sql.window", fromlist=["Window"])
            .Window.partitionBy("event_id")
            .orderBy(F.col("updated_at").desc())
        ),
    )
    .where("version_no = 1")
)

result = (
    event.repartition(64, "entity_id")
    .groupBy("entity_id", "event_date")
    .agg(
        F.countDistinct("event_id").alias("event_cnt"),
        F.sum("metric_value").alias("metric_sum"),
    )
)

# 覆盖写前先写临时分区；成功校验后再提交元数据，避免失败任务污染正式结果。
result.write.mode("overwrite").parquet("/warehouse/check/${profile.idSuffix}/dt={{ ds }}")

spark.sql("ANALYZE TABLE fact_event COMPUTE STATISTICS")
spark.stop()`;
}

function streamingCode(profile) {
  return `-- ${profile.topic}：事件时间去重、水位线与状态清理
CREATE TEMPORARY TABLE scoped_events (
    event_id STRING,
    entity_id STRING,
    event_time TIMESTAMP(3),
    metric_value DECIMAL(18, 4),
    WATERMARK FOR event_time AS event_time - INTERVAL '30' SECOND
) WITH (
    'connector' = 'kafka',
    'topic' = '${profile.idSuffix}-event',
    'properties.bootstrap.servers' = 'broker:9092',
    'format' = 'json',
    'scan.startup.mode' = 'group-offsets'
);

SELECT
    entity_id,
    window_start,
    window_end,
    COUNT(DISTINCT event_id) AS event_cnt,
    SUM(metric_value) AS metric_sum
FROM TABLE(
    TUMBLE(TABLE scoped_events, DESCRIPTOR(event_time), INTERVAL '1' MINUTE)
)
GROUP BY entity_id, window_start, window_end;`;
}

function analyticsCode(profile) {
  return `# ${profile.topic}：先固定观察窗口，再比较分组与基线
import pandas as pd
from scipy.stats import norm

def compare_groups(frame: pd.DataFrame, group_col: str, metric_col: str) -> pd.DataFrame:
    required = {"entity_id", "event_date", group_col, metric_col}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")

    clean = frame.drop_duplicates("entity_id").copy()
    summary = (
        clean.groupby(group_col, dropna=False)[metric_col]
        .agg(["count", "mean", "std"])
        .reset_index()
        .rename(columns={"count": "sample_size", "mean": "metric_mean", "std": "metric_std"})
    )
    summary["standard_error"] = summary["metric_std"] / summary["sample_size"].pow(0.5)
    summary["ci_low"] = summary["metric_mean"] - norm.ppf(0.975) * summary["standard_error"]
    summary["ci_high"] = summary["metric_mean"] + norm.ppf(0.975) * summary["standard_error"]
    summary["topic"] = "${profile.topic}"
    summary["interpretation"] = "同时检查样本量、效应大小和护栏指标"
    return summary.sort_values("metric_mean", ascending=False)`;
}

function qualityCode(profile) {
  const key = profile.context.entities[0][1];
  return `# ${profile.topic}：发布前质量门禁
from dataclasses import dataclass

@dataclass
class CheckResult:
    name: str
    failed_rows: int
    threshold: int
    evidence: str

def release_gate(checks: list[CheckResult]) -> None:
    blocking = [item for item in checks if item.failed_rows > item.threshold]
    if blocking:
        raise RuntimeError({
            "topic": "${profile.topic}",
            "action": "block_release",
            "failed": [item.__dict__ for item in blocking],
        })

checks = [
    CheckResult("duplicate ${key}", 12, 0, "event version and source batch"),
    CheckResult("null business time", 3, 0, "raw event sample"),
    CheckResult("orphan dimension", 8, 0, "dimension validity interval"),
    CheckResult("source-target count gap", 2, 0, "partition reconciliation"),
]
release_gate(checks)`;
}

function aiCode(profile) {
  return `# ${profile.topic}：离线评估卡，不只看一个平均分
from dataclasses import dataclass

@dataclass
class EvalCase:
    case_id: str
    slice: str
    expected: str
    actual: str
    latency_ms: int
    evidence_complete: bool

def evaluate(cases: list[EvalCase]) -> dict:
    exact = [c for c in cases if c.expected.strip() == c.actual.strip()]
    grounded = [c for c in exact if c.evidence_complete]
    slow = [c for c in cases if c.latency_ms > 3000]
    by_slice = {}
    for case in cases:
        bucket = by_slice.setdefault(case.slice, {"count": 0, "correct": 0})
        bucket["count"] += 1
        bucket["correct"] += int(case.expected.strip() == case.actual.strip())
    return {
        "topic": "${profile.topic}",
        "case_count": len(cases),
        "exact_match": len(exact) / max(len(cases), 1),
        "grounded_match": len(grounded) / max(len(cases), 1),
        "slow_case_rate": len(slow) / max(len(cases), 1),
        "by_slice": by_slice,
    }`;
}

function codeForRecipe(profile, recipe) {
  if (["career", "resume", "learning", "industry", "general"].includes(recipe)) return "";
  if (recipe === "enterprise-modeling") return ""; // 专门配方中单独加入可选质量 SQL
  if (recipe === "ecommerce-architecture" || recipe === "architecture" || recipe === "governance" || recipe === "lineage") {
    return "";
  }
  if (recipe === "spark") return `## 可验证的 Spark 代码

${fence("python", sparkCode(profile))}

代码检查三件事：读取是否限定分区，去重是否显式定义版本顺序，Shuffle 与输出是否具备可恢复边界。实际运行时还要结合执行计划、输入输出行数、任务失败率和资源峰值判断。`;
  if (recipe === "streaming") return `## 流处理代码与一致性边界

${fence("sql", streamingCode(profile))}

这段 Flink SQL 只解决事件时间、窗口和去重的一部分问题。生产环境还要记录水位线、状态大小、Checkpoint、迟到数据策略和下游幂等写入。`;
  if (recipe === "sql") return `## 查询实现

${fence("sql", sqlTopicCode(profile))}

执行后不要只看结果行数。应同时检查空值、重复、时间顺序、分组总量和明细可回查性，并查看执行计划是否存在不必要的全表扫描与数据膨胀。`;
  if (recipe === "quality") return `## 把门禁写成可执行规则

${fence("python", qualityCode(profile))}

规则失败时应产生阻断结果、失败样本、批次日、代码版本和责任人，而不是只在日志里写一条“检查完成”。`;
  if (recipe === "ai") return `## 评估脚本：把质量拆到切片和证据

${fence("python", aiCode(profile))}

上线验收还应覆盖拒答、引用完整性、敏感信息、越权工具调用、超时、成本与人工复核负担。一个平均准确率无法说明系统是否可安全使用。`;
  if (recipe === "analytics" || recipe === "metric" || recipe === "project" || recipe === "engineering") {
    const usePython = recipe === "analytics" && profile.seed % 2 === 0;
    return `## ${usePython ? "分析验证" : "数据核对"}示例

${fence(usePython ? "python" : "sql", usePython ? analyticsCode(profile) : genericSql(profile))}

示例代码只用于展示口径与验收思路。落地时必须替换表名、字段和权限，并保留参数、版本、执行日志和结果快照。`;
  }
  return "";
}

function governanceSection(profile, recipe) {
  const context = profile.context;
  const controls = recipe === "lineage"
    ? ["表级血缘", "字段级血缘", "任务与代码版本", "消费方影响范围", "变更通知与回退"]
    : recipe === "quality"
      ? ["完整性", "唯一性", "时间合法性", "状态一致性", "金额或数量守恒", "及时性"]
      : ["定义", "标准", "责任人", "版本", "权限", "审计与问题闭环"];
  return `## 治理机制：把约定变成运行控制

围绕“${profile.topic}”，治理不能停留在制度文档。至少要形成下面这些可测试控制：

${table(
    ["控制对象", "要回答的问题", "证据", "失败动作"],
    controls.map((control, index) => [
      control,
      `${profile.topic}在这项控制上由谁负责、何时生效、如何变更`,
      `${context.systems[index % context.systems.length]}中的版本、审批、日志或样本`,
      index < 2 ? "阻断发布并升级责任人" : "登记例外、限期修复并复核"
    ])
  )}

尤其要警惕“文档已经更新，系统仍运行旧规则”。破坏性变更必须同时覆盖语义层、任务参数、下游通知、回退方案和审计记录。`;
}

function architectureDecisionSection(profile) {
  const context = profile.context;
  return `## 架构取舍与质量属性

“${profile.topic}”不能只用组件图评估。架构是否合理，取决于业务截止时间、正确性损失、恢复目标、峰值容量和总成本。建议把候选方案放到同一张决策表中比较：

${table(
    ["质量属性", "需要量化的指标", "常见取舍", "验收证据"],
    [
      ["时效", "P95/P99 数据可见延迟、业务截止时间前完成率", "实时链路增加复杂度，批处理更容易重算", "端到端时间戳与分区水位"],
      ["正确性", "重复率、乱序率、对账差异、状态非法率", "预聚合提高速度但降低明细可追溯性", "源目标对账、边界样本、明细回查"],
      ["可用性", "SLO、失败恢复时间、补数时长", "多副本提高可用性但增加成本", "故障演练、回滚记录、恢复对账"],
      ["成本", "单位事件成本、扫描量、峰值资源", "缓存和预计算改善延迟但占用存储", "执行计划、账单、资源利用率"],
      ["演进", "新增来源与规则的上线周期", "紧耦合交付快但变更影响面大", "接口契约、血缘覆盖、兼容性测试"]
    ]
  )}

架构评审要能明确指出：本轮最难满足的质量属性是什么，为它牺牲了什么，以及什么条件下必须重新设计。`;
}

function processSection(profile) {
  const context = profile.context;
  const stages = context.stages;
  return `## 业务过程与状态链

${table(
    ["阶段", "关键动作", "状态变化", "数据证据"],
    stages.map((stage, index) => [
      stage,
      `${context.participants[index % context.participants.length]}完成或确认相应动作`,
      index === 0 ? "开始进入流程" : `从${stages[Math.max(0, index - 1)]}推进到${stage}`,
      `${context.systems[index % context.systems.length]}中的事件时间、操作人、单号或日志`
    ])
  )}

状态链的作用，是防止把“结果表看起来正常”误认为“业务过程完整”。每个阶段都要能区分发生、撤销、超时、回退和补录；如果状态字段只有成功与失败，往往无法支撑异常分析。`;
}

function implementationPlan(profile, recipe) {
  const weeks = recipe === "career" || recipe === "learning"
    ? [
      ["第 1 阶段", "明确目标岗位或能力场景，收集真实任务样本", "能复述问题、约束和决策"],
      ["第 2 阶段", "完成一次刻意练习或项目复现", "保留代码、文档、失败样本和复盘"],
      ["第 3 阶段", "用他人视角做压力测试", "能回答证据、边界和重做方案"],
      ["第 4 阶段", "形成可投递材料或稳定工作习惯", "连续两次以上按标准完成"]
    ]
    : [
      ["第 1 周", "对齐对象、口径、流程、使用者和成功标准", "关键角色确认同一范围和排除项"],
      ["第 2 周", "打通数据链路并建立正常、边界、失败样本", "结果能回到原始记录"],
      ["第 3 周", "完成质量门禁、容量与异常演练", "阻断、回滚和补数均有证据"],
      ["第 4 周", "小范围发布并设置观察窗口", "使用者完成一次真实闭环动作"]
    ];
  return `## 落地节奏与完成标准

${table(["阶段", "主要工作", "通过条件"], weeks)}

完成“${profile.topic}”不需要等到所有工具和口径完美统一。更现实的做法是先选一个范围清楚、结果可回查、责任人明确的场景，做出最小闭环，再把验证过的对象、规则和接口复用到下一层。`;
}

function failureSection(profile, recipe) {
  const context = profile.context;
  const rows = [
    ["只替换标题", "正文与案例仍可原样套到其他主题", "每个案例必须指出本标题特有的对象、状态或决策", "抽读两篇不同主题，判断方法能否区分"],
    ["对象粒度混算", `把${context.entities[0][0]}事件与日快照直接相加`, "主键、时间、状态与事实粒度", "关键指标无法回到明细时阻断"],
    ["只看任务成功", "没有检查水位、重复和下游可见性", "批次日、行数、对账和消费日志", "无法说明影响范围时不得补数"],
    ["错误归因", "把自然波动或团队成果归给单次方案", "基线、对照、时间线和护栏指标", "证据不足时降低结论强度"],
    ["永久大权限", "临时分析复用了生产全量账号", "最小字段、用途、到期时间和访问审计", "高风险字段无授权即阻断"]
  ];
  if (recipe === "industry") {
    rows[1] = ["用别名代替业务对象", `把${context.entities[0][1]}当成唯一事实而忽略撤销、换版和历史归属`, "业务单据、状态机和维度有效期", "主键无法跨阶段追溯时不发布指标"];
  }
  if (recipe === "career" || recipe === "resume" || recipe === "learning") {
    rows[0] = ["项目描述只有工具", "看不出问题复杂度、个人动作和证据", "背景、约束、动作、结果边界与复盘", "无法回答追问时继续补材料"];
    rows[1] = ["数字口径不清", "增长率、金额和比例无法解释来源", "时间窗、分母、样本与个人贡献", "不能用事实说明时删除数字"];
  }
  return `## 失败方式与验收清单

${table(["风险", "错误做法", "必须补齐的证据", "行动规则"], rows)}

最后用一次盲测验收：让没有参与项目的同事只看口径卡、样本和代码，尝试复跑“${profile.topic}”的核心结果。如果对方无法指出对象、时间、状态和行动出口，说明文档仍然只是说明文，而不是可执行方法。`;
}

function buildGenericArticle(profile, recipe) {
  const context = profile.context;
  const sections = [];
  sections.push(articleLead(profile, `读者完成阅读后，应能为${context.scene}中的相关任务写出一份对象清楚、指标可复跑、异常可恢复的实施方案。`));
  sections.push(businessQuestionSection(profile));
  sections.push(commonObjectSection(profile));
  if (["industry", "architecture", "project", "engineering", "ecommerce-architecture"].includes(recipe)) {
    sections.push(processSection(profile));
  }
  if (["metric", "analytics", "industry", "enterprise-modeling"].includes(recipe)) {
    sections.push(metricSection(profile));
  }
  if (["architecture", "project", "engineering"].includes(recipe)) {
    sections.push(architectureDecisionSection(profile));
  }
  if (["governance", "quality", "lineage", "metric"].includes(recipe)) {
    sections.push(governanceSection(profile, recipe));
  }
  sections.push(casesSection(profile, recipe));
  const code = codeForRecipe(profile, recipe);
  if (code) sections.push(code);
  sections.push(failureSection(profile, recipe));
  sections.push(implementationPlan(profile, recipe));
  sections.push(references(profile));
  return sections.join("\n\n");
}

function buildMetricArticle(profile) {
  const context = profile.context;
  const metric = profile.specialty?.metric || context.metricDefs[profile.seed % context.metricDefs.length];
  const name = metric.name || profile.topic;
  const formula = metric.formula || `${profile.topic}的有效结果 / 符合业务条件的对象数`;
  return `${articleLead(profile, `指标文章的价值，在于让不同团队按同一份定义得到同一个结果，并能解释差异。`)}

## 这个指标到底回答什么问题

“${name}”不是孤立数字。它至少由对象范围、统计窗口、分子、分母、状态和维度共同定义。当前主题可先写成：

> 在【时间窗口】内，对【符合资格条件的${context.entities[0][0]}】，按【业务状态】计算 \`${formula}\`，再按${context.dims.slice(0, 3).join("、")}拆分，并与同周期基线比较。

${table(
    ["口径组成", "必须写清的内容", "对于本主题的风险"],
    [
      ["对象", `${context.entities[0][0]}由哪个主键识别，是否存在一人多号、拆单、合并或撤销`, context.risks[0]],
      ["时间", `使用${context.dateField}，还是状态生效、入账或可见时间`, "跨期导致本月和上月都不完整"],
      ["分子", `${formula}中计入哪些有效行为和状态`, "撤销、测试或重复数据未排除"],
      ["分母", "哪些对象有资格进入观察范围", "把不具备条件的人或事件放进分母"],
      ["维度", context.dims.slice(0, 4).join("、"), "维度使用当前值回溯历史"],
      ["版本", "公式、源系统、状态字典和排除项的版本", "口径变化与业务变化混在一起"]
    ]
  )}

## 从原始对象到指标结果

${processSection(profile)}

指标开发应优先保留明细事实，再按同一粒度聚合。对于金额和数量，要做源目标和跨层守恒；对于比例，要同时输出分子、分母、样本量和置信区间；对于人均或单位产出，要检查分母是否为零或口径发生变化。

## 三个最容易解释错的业务现象

### 现象一：总数上涨，但有效率下降

这通常不是“整体增长”这么简单。应先按${context.dims.slice(0, 3).join("、")}拆解贡献，确认新增对象是否具有更低的有效率；再检查状态和重复数据，排除结构变化造成的假增长。

### 现象二：两个团队各有一套正确数字

两边可能分别使用业务发生时间和入账时间，或者一个统计事件、一个统计对象。处理方式不是投票选一个，而是列出公式、样本和差异明细，由业务负责人确认正式口径与临时分析口径的边界。

### 现象三：平均值正常，但尾部已经失控

平均值会掩盖长尾和少数高影响对象。应长期保留 P50、P90、P99、最大值和异常清单；涉及体验、资金或安全的指标还要单独设置阻断阈值。

## 口径评审与发布记录

${table(
    ["评审项", "通过标准", "责任人"],
    [
      ["业务定义", "能说明用于什么决策，不用于什么判断", "业务负责人"],
      ["数据实现", "公式、粒度、时间字段和排除项可复跑", "数据开发"],
      ["质量证据", "正常、边界、撤销、跨期和重复样本均通过", "数据质量或测试负责人"],
      ["权限与用途", "字段最小化、用途明确、导出和保存期限受控", "数据安全负责人"],
      ["变更管理", "版本、影响范围、通知对象和回退方案明确", "指标 Owner"]
    ]
  )}

## 验收查询

${fence("sql", genericSql(profile))}

查询结果只能证明当前规则被执行，不能自动证明规则正确。上线前还需要业务抽样回查、历史重算和一次失败回滚演练。

${failureSection(profile, "metric")}

${references(profile)}`;
}

function buildIndustryArticle(profile) {
  const context = profile.context;
  return `${articleLead(profile, `行业知识最终要落到角色、流程、对象和可观察结果，而不是停留在名词解释。`)}

## 行业场景与参与者

${context.scene}不是单一部门能够完成的流程。${context.participants.join("、")}分别掌握不同信息，也承担不同风险。分析或数据建设若不理解这些角色，很容易把“系统字段”误当成“业务事实”。

${table(
    ["角色", "主要目标", "可能掌握的数据", "常见冲突"],
    context.participants.slice(0, 6).map((participant, index) => [
      participant,
      `${context.stages[index % context.stages.length]}阶段的业务目标`,
      context.systems[index % context.systems.length],
      context.risks[index % context.risks.length]
    ])
  )}

## 一个完整的业务过程

${processSection(profile)}

## 业务对象与数据边界

${commonObjectSection(profile)}

## 核心指标与解释方法

${metricSection(profile)}

## 场景复盘

${casesSection(profile, "industry", 3 + profile.seed % 2)}

## 行业分析中常见的判断误区

${bulletList([
    `把“${context.entities[0][0]}数量”直接当作业务成果，却没有检查有效状态、重复对象和撤销记录。`,
    `只比较本期与上期，却不区分客群、产品、渠道、地区和流程版本变化。`,
    `把行业平均值套到本单位，忽略规模、业务结构和数据口径差异。`,
    `看到相关关系就解释为因果关系，缺少基线、对照和行动时间线。`,
    `为了赶报表删除异常样本，导致风险在明细层消失、在业务现场累积。`
  ])}

${implementationPlan(profile, "industry")}

${references(profile)}`;
}

function buildEngineeringArticle(profile, recipe) {
  const context = profile.context;
  const code = codeForRecipe(profile, recipe);
  return `${articleLead(profile, `工程类主题必须同时讨论功能正确性、数据一致性、运行成本和故障恢复。`)}

## 需求与约束

${table(
    ["约束", "需要确认的问题", "量化方式"],
    [
      ["数据量", `峰值事件数、日增存储、保留周期是多少`, "事件数、字节数、文件数"],
      ["时效", `业务最晚何时看到“${profile.topic}”结果`, "P95/P99 延迟与截止时间完成率"],
      ["正确性", "哪些错误必须阻断，哪些允许延迟修复", "重复率、对账差异、非法状态率"],
      ["恢复", "失败后允许多久恢复，如何防止重复写入", "RTO、补数时长、幂等验证"],
      ["成本", "资源预算和单位产出成本上限", "CPU、扫描量、存储和任务费用"],
      ["安全", "哪些字段、任务和操作需要审批与审计", "最小权限、脱敏和访问日志"]
    ]
  )}

## ${profile.topic}的端到端链路

${table(
    ["层次", "主要职责", "本主题的关键设计", "证据"],
    [
      ["源与契约", "确定事件、状态、版本和迟到规则", context.controls[0], "数据契约与源样例"],
      ["接入", "批或流方式进入数据平台", `处理${context.risks[0]}`, "批次、偏移量或水位"],
      ["明细", "保留可追溯事实和对象关系", `主键 ${context.entities[0][1]}`, "行数与重复检查"],
      ["汇总", "按固定粒度形成指标或模型", context.metricDefs[0][0], "源目标对账"],
      ["服务", "向看板、API 或分析任务交付", "权限、版本与缓存", "请求日志与可见时间"],
      ["运维", "监控、告警、补数与回滚", "SLO 和责任人", "事故记录与恢复证据"]
    ]
  )}

${architectureDecisionSection(profile)}

${code || ""}

${casesSection(profile, recipe, 3 + profile.seed % 2)}

${failureSection(profile, recipe)}

## 发布与故障演练

发布前至少完成三次演练：正常分区全量重跑、上游重复或乱序事件注入、下游不可用后的恢复。每次都要记录输入范围、输出摘要、影响对象、对账结果和操作人。没有演练证据的“支持重跑”，只是一个待验证的假设。

${references(profile)}`;
}

function buildAiArticle(profile) {
  const context = profile.context;
  const isRag = /RAG|检索|向量|知识库/.test(profile.topic);
  const isAgent = /Agent|智能体|工具调用/.test(profile.topic);
  return `${articleLead(profile, `AI 文章不能只描述能力，还要说明数据来源、评估方法、失败模式、人工兜底与安全边界。`)}

## 能力边界与任务定义

“${profile.topic}”要先定义输入、输出、允许动作和不可接受后果。${isAgent ? "Agent 还涉及工具权限、执行顺序、超时和回滚；一个能调用工具的模型不等于一个可上线的系统。" : isRag ? "RAG 还需要文档切分、检索、重排、引用和版本更新；生成流畅不等于证据充分。" : "模型指标还需要区分离线效果、线上决策成本和分布变化。"}

${table(
    ["设计对象", "必须回答的问题", "失败后的表现"],
    [
      ["任务", "用户提出什么请求，系统允许完成到哪一步", "答非所问或越权执行"],
      ["数据", "训练、检索或上下文来自哪里，版本和权限如何控制", "泄漏、过期或引用错误"],
      ["模型", "基线是什么，阈值和拒答机制如何设置", "高分离线、低质线上"],
      ["评估", "正常、边界、对抗和长尾样本如何覆盖", "平均分掩盖关键切片失败"],
      ["人工兜底", "哪些结果必须复核，如何申诉和纠正", "错误直接进入业务动作"],
      ["监控", "效果、延迟、成本、漂移和安全如何观察", "上线后无法发现问题"]
    ]
  )}

## 评估集怎么设计

评估集不是随便收集一百条问答。至少要覆盖：高频正常问题、同义表达、缺少上下文、过期知识、相互冲突的证据、敏感信息、越权请求、工具失败和长尾业务场景。每条样本保留输入、期望结果、关键证据、切片标签和可接受替代答案。

${table(
    ["评估维度", "示例指标", "不能替代什么"],
    [
      ["任务正确性", "精确匹配、语义正确率、业务通过率", "不能替代人工抽查和责任确认"],
      ["证据质量", "引用准确率、引用覆盖率、冲突处理率", "不能证明来源本身权威"],
      ["安全", "敏感信息泄露率、越权拦截率、拒答正确率", "不能只看提示词是否写了禁止项"],
      ["稳定性", "重复运行一致率、超时率、工具错误率", "不能证明系统理解业务"],
      ["体验与成本", "P95 延迟、单次成本、人工修改时间", "不能代替长期效果观察"]
    ]
  )}

${codeForRecipe(profile, "ai")}

${isAgent ? `## Agent 工具调用控制

Agent 的每个工具都应定义输入 schema、允许角色、最大执行次数、超时、幂等和回滚方式。高风险动作必须经过人工确认；执行记录要包含计划、参数、结果和模型版本。` : isRag ? `## RAG 检索与引用验收

检索结果至少展示文档版本、片段位置、命中分数和更新时间。回答中的关键结论应能对应到引用；证据冲突时先呈现差异，而不是强行合并。权限过滤必须在检索前完成，不能先检索敏感内容再在生成后遮盖。` : `## 模型上线前后的证据

离线评估之后仍需小流量灰度，观察真实请求分布、拒答率、人工修改、业务动作和成本。模型更新要冻结同一评估集，并保留旧版本结果用于回退比较。`}

${casesSection(profile, "ai", 3)}

${failureSection(profile, "ai")}

${references(profile)}`;
}

function buildCareerArticle(profile, recipe) {
  const context = profile.context;
  return `${articleLead(profile, `职业类内容要把观点变成可验证的行动、证据和边界，避免只给泛泛建议。`)}

## 先判断问题属于哪一层

“${profile.topic}”可能涉及能力、证据、选择、协作或市场信息。不同层次需要不同动作：

${table(
    ["问题层次", "典型表现", "应先补什么", "不适用什么"],
    [
      ["能力", "知道概念，但无法完成真实任务", "刻意练习、项目复现、失败复盘", "只背话术"],
      ["证据", "做过项目，但说不清个人贡献", "对象、动作、结果、边界与证据", "把团队成果全部算成个人成果"],
      ["选择", "多个岗位或方向难以比较", "职责、成长、薪酬结构、团队和风险", "只比较一个总包数字"],
      ["协作", "跨团队推动困难", "利益相关方、决策权、时间线和升级机制", "把沟通问题都归因于性格"],
      ["市场", "投递反馈差，不清楚差距", "岗位样本、面试记录、能力映射", "用一次失败推断整个市场"]
    ]
  )}

## 把“${profile.topic}”拆成可练习任务

${bulletList([
    `选择一个与目标岗位一致的真实问题，而不是虚构一个万能项目。`,
    `写清约束、个人动作、技术选择、失败样本和最终证据。`,
    `让同行做一次压力测试，连续追问“为什么这样做、怎么证明、如果重做会改什么”。`,
    `把回答压缩到 90 秒版本和一页文档版本，保留可深入的事实。`,
    `针对反馈修改下一轮练习，不用收藏更多课程代替实际完成。`
  ])}

## 项目证据模板

${table(
    ["证据块", "写法", "常见弱表达"],
    [
      ["背景", "在什么业务和约束下发生了什么问题", "参与了某项目"],
      ["目标", "要改善哪个可观察结果", "提升数据能力"],
      ["个人动作", "自己确认了什么、做了什么、推动了谁", "负责数据处理"],
      ["结果", "范围、时效、质量、采用情况和限制", "效果显著"],
      ["边界", "哪些是团队成果，哪些尚未验证", "全部归因于个人方案"],
      ["复盘", "失败过什么，下一次如何修改", "没有困难"]
    ]
  )}

${casesSection(profile, recipe, 2 + profile.seed % 2)}

## 30 天行动表

${table(
    ["周期", "动作", "产出"],
    [
      ["第 1 周", "收集 5 个目标岗位或真实任务样本，标注共同能力", "能力差距表"],
      ["第 2 周", "完成一个最小真实任务并保留过程记录", "作品或案例骨架"],
      ["第 3 周", "做同行评审，补齐失败样本与证据", "可追问的项目说明"],
      ["第 4 周", "模拟面试、投递或向负责人汇报，按反馈迭代", "下一轮明确计划"]
    ]
  )}

${failureSection(profile, recipe)}

${references(profile)}`;
}

function buildEnterpriseModelingArticle(profile) {
  return `${articleLead(profile, `企业级建模不是把所有表画成一张大 ER 图，而是用一致的业务对象、粒度、维度、规则和变更机制，支撑跨域复用。`)}

## 为什么“部门模型都正确”，放到集团却对不上

单部门建模常常只优化本部门报表：订单团队关注订单状态，财务团队关注入账金额，供应链关注库存和履约，会员团队关注身份与权益。每个模型在自己的范围内都能运行，但一旦跨域分析，就会遇到四类冲突：

${table(
    ["冲突", "表面现象", "根因", "企业级处理"],
    [
      ["对象冲突", "同一客户、商品或组织在不同系统有多个编码", "主数据缺少映射或历史关系", "建立企业对象、源标识与有效期"],
      ["粒度冲突", "订单头、订单行、支付单和退款单被混在一张事实表", "一行数据的业务含义不唯一", "按业务过程拆分事实并声明粒度"],
      ["时间冲突", "下单、支付、发货、入账和退款时间混用", "没有区分业务发生与状态生效", "每个事实绑定明确事件时间"],
      ["口径冲突", "收入、销量和毛利各有多个版本", "指标公式与维度归属未治理", "指标字典、语义层和 Owner 机制"],
      ["变更冲突", "组织调整后历史报表被重写", "维度只保留当前值", "使用缓慢变化维与版本生效区间"]
    ]
  )}

企业级建模的目标不是消灭所有差异，而是让差异被明确表达、可追溯到责任人，并在需要跨域比较时有一套共同规则。

## 方法总览：从业务域到企业模型

${numberedList([
    "划分业务域与数据域，说明每个域的边界、核心过程、上下游和责任人。",
    "识别业务过程：一次交易、支付、发货、退款或服务究竟在推进什么状态。",
    "为每个业务过程声明事实粒度，例如一行是订单行、支付流水、库存日快照还是一次退款。",
    "设计维度与一致性维度，明确客户、商品、组织、时间、渠道等跨域复用规则。",
    "建立概念模型、逻辑模型和物理模型之间的映射，不能用物理表结构代替业务定义。",
    "定义命名、编码、状态、空值、历史归属和数据质量规则。",
    "组织业务、数据、财务、安全和下游消费方进行模型评审。",
    "通过版本、变更影响分析、兼容窗口和回退方案管理模型演进。"
  ])}

## 三层模型分别解决什么

${table(
    ["层次", "核心产物", "要回答的问题", "不应混入什么"],
    [
      ["概念模型", "业务域、实体、关系和业务规则", "企业有哪些核心对象，它们如何发生关系", "具体数据库字段和性能参数"],
      ["逻辑模型", "实体属性、主键、粒度、历史与关系", "同一业务问题应如何稳定表达", "某个引擎特有的物理优化"],
      ["物理模型", "表、分区、索引、存储和访问方式", "在目标平台上如何高效且安全地实现", "未经业务确认的口径假设"]
    ]
  )}

三层之间应有可追踪映射。物理表改名或换引擎，不应该改变业务对象的含义；新增一个报表字段，也不应该绕过逻辑模型直接修改企业口径。

## 业务过程、粒度、事实与维度

维度建模中最重要的不是“建几张维表”，而是先确定业务过程的粒度。以交易与对账为例：

${table(
    ["业务过程", "事实粒度示例", "事实", "关联维度", "禁止混算"],
    [
      ["下单", "一行一个订单商品行", "下单数量、标价、优惠分摊", "日期、客户、商品、渠道、活动", "订单头优惠不能重复分摊到每个行"],
      ["支付", "一行一次支付尝试或支付流水", "支付金额、手续费、支付状态", "日期、支付方式、账户、订单", "支付失败不能计入成交额"],
      ["发货", "一行一个包裹或发货行", "发货数量、物流费用", "仓库、承运商、线路、订单行", "拆包后不能回写覆盖原始发货"],
      ["退款", "一行一次退款事件", "退款金额、退款原因", "日期、订单行、支付单、渠道", "部分退款不能冲减整笔订单"],
      ["对账", "一行一个对象在特定批次的差异", "源金额、目标金额、差异", "批次、对象、规则版本", "差异记录不能替代业务事实"]
    ]
  )}

一旦事实粒度错了，后面的汇总和指标都会系统性失真。例如订单头优惠被加到每条订单行，再按行汇总时就会把同一笔优惠重复计算；订单状态回退后覆盖历史，也会让履约周期和退款分析失去时间顺序。

## 一致性维度与企业复用

一致性维度不是“字段名一样”，而是业务定义、主键、历史归属和粒度都足够稳定，能在多个业务过程中复用。企业至少应治理以下维度：

${table(
    ["一致性维度", "企业级规则", "历史处理", "常见失败"],
    [
      ["客户", "个人、企业、匿名身份和会员身份分开识别", "身份合并与拆分保留审计", "一人多号或家庭成员共用设备"],
      ["商品", "商品、SKU、批次和组合装分层", "上下架、规格和品类版本可追溯", "用当前类目回写历史销售"],
      ["组织", "法人、业务单元、部门和门店分别建模", "组织调整使用生效区间", "组织变更后历史归属被覆盖"],
      ["时间", "业务发生、入账、数据可见和计算完成分开", "跨时区与关账规则明确定义", "日期字段含义混用"],
      ["渠道", "流量来源、成交渠道和履约渠道分开", "归因窗口与优先级可配置", "多渠道重复归因"]
    ]
  )}

企业模型的复用价值，来自这些维度在交易、履约、财务和客户分析中采用同一套对象和历史规则，而不是来自一张包含所有字段的超级宽表。

## 企业实施中的五个典型现场

### 现场一：核心交易与财务对账

交易平台按订单行统计成交，财务按支付流水确认收款，仓储按包裹确认发货。三套数据都正确，却无法直接解释差异。

处理时先建立订单行、支付流水、退款事件和履行单之间的一对多关系，再以业务对象和时间为桥进行对账。成交、收款、发货分别保留事实，不用“最终状态”覆盖过程状态。对账差异按未支付、部分支付、重复回调、跨期、退款和取消分类，每一类有责任人和处理时限。

### 现场二：集团主数据与跨域一致性维度

多个业务单元对客户、供应商和商品使用不同编码。错误做法是直接选一个“最权威系统”覆盖所有映射。更可靠的做法是建立企业对象 ID、源系统 ID、匹配规则、置信度和有效期，允许同一对象存在多个来源标识，并记录合并、拆分和人工确认。

跨域报表使用企业对象 ID，业务操作仍可回到源系统 ID。维度合并后历史报表可重算，但必须保留合并前版本和审计记录。

### 现场三：缓慢变化维度与历史归属

门店从 A 区调整到 B 区后，如果所有历史销售都显示在 B 区，就会让过去的区域业绩被重写。应使用类型 2 缓慢变化维，保存生效时间、失效时间、版本和变更原因；事实表在业务发生时关联对应版本。

同时要区分“业务发生时的组织”与“当前组织看历史”两种分析需求。前者用于责任归属，后者用于当前管理口径，两者可以同时提供，但不能互相覆盖。

### 现场四：事实粒度错误导致金额翻倍

某团队把订单头优惠按订单行复制，再做行级汇总，导致优惠金额随行数放大。排查时先比较订单头、订单行和结果表三层数量与金额，再抽样含多行、部分退款和拆单的订单。

修复不是简单除以行数，而是重新定义：订单头级优惠保留在订单头事实，需要分摊到行时建立明确分摊规则和尾差处理；退款按退款事件冲减，不使用订单当前状态反推历史。

### 现场五：模型复用与变更审批

下游团队希望新增一个“有效订单”字段，上游准备直接修改共享模型。评审发现不同业务对“有效”的定义分别包含已支付、已发货和未退款。最终方案不是增加一个含糊字段，而是拆成可组合状态，并由指标语义层定义各场景口径。

破坏性变更要经过影响分析：谁在消费、哪些指标会变、历史是否需要重算、兼容多长时间、如何回退、谁批准。模型版本和血缘记录应随发布自动更新。

## 模型评审与变更治理

${table(
    ["评审维度", "至少要看的材料", "不通过的表现"],
    [
      ["业务范围", "业务域、流程、对象、使用者和非目标", "只说明要建哪些表"],
      ["粒度", "每个事实一行代表什么，主键如何唯一", "订单头与订单行混用"],
      ["历史", "维度有效期、状态回退和补录规则", "最新状态覆盖历史"],
      ["口径", "指标公式、分子分母、时间和排除项", "同名指标多套算法"],
      ["质量", "正常、重复、空值、撤销、跨期样本", "只验证某一天总量"],
      ["性能", "数据量、分区、Join 膨胀和扫描成本", "逻辑正确但没有容量估算"],
      ["安全", "分类分级、用途、最小字段和审计", "共享模型暴露敏感字段"],
      ["演进", "版本、兼容窗口、回退和下游通知", "直接覆盖旧字段"]
    ]
  )}

## 可选：模型质量检查 SQL

下面只检查结构风险，不代表已经验证业务口径：

${fence("sql", `-- 同一事实粒度是否出现重复
SELECT
    business_date,
    order_id,
    order_line_id,
    COUNT(*) AS duplicate_cnt
FROM fact_order_line
WHERE business_date BETWEEN :start_date AND :end_date
GROUP BY business_date, order_id, order_line_id
HAVING COUNT(*) > 1;

-- 事实是否存在找不到有效维度版本的孤儿记录
SELECT
    f.business_date,
    COUNT(DISTINCT f.store_id) AS orphan_store_cnt
FROM fact_sales_line f
LEFT JOIN dim_store d
  ON f.store_id = d.store_id
 AND f.business_date >= d.valid_from
 AND f.business_date <  COALESCE(d.valid_to, DATE '9999-12-31')
WHERE d.store_id IS NULL
GROUP BY f.business_date;`)}

## 企业建模完成标准

${numberedList([
    "任一核心事实都能说明一行代表什么，并能在明细中复现汇总结果。",
    "跨域对象通过企业 ID 和源系统映射追溯，合并、拆分与历史版本可审计。",
    "维度使用正确有效期，历史报表不会因当前组织或属性调整而被静默重写。",
    "指标字典、逻辑模型、物理实现和语义层之间能够互相追溯。",
    "模型变更经过影响分析、兼容验证、下游通知和回退演练。",
    "质量规则覆盖正常、重复、空值、孤儿维度、跨期、撤销和补录样本。"
  ])}

${references(profile, [
    ["The Open Group TOGAF Standard", "https://www.opengroup.org/togaf"],
    ["NIST Enterprise Architecture", "https://www.nist.gov/programs-projects/enterprise-architecture"],
    ["DAMA-DMBOK 数据管理知识体系", "https://www.dama.org/cpages/body-of-knowledge"]
  ])}`;
}

function buildEcommerceArchitectureArticle(profile) {
  return `${articleLead(profile, `电商架构的难点不是多接几个数据源，而是在交易、支付、库存、履约和售后同时变化时，仍能保证对象、事件、状态和金额可对账。`)}

## 从业务能力到数据能力

电商不是一条“曝光到支付”的直线。商品和内容决定用户看到什么，订单与支付记录成交，库存预占影响可售，仓储和物流完成履约，退款售后又反向修正收入与成本。数据架构应先画出业务能力与质量属性，再选择批流、存储和服务组件。

${table(
    ["业务能力", "核心对象", "关键状态", "数据侧必须回答"],
    [
      ["商品与内容", "SPU、SKU、类目、内容、直播场次", "草稿、上架、下架、冻结、售罄", "上下架时间和价格版本能否回溯"],
      ["用户与会话", "匿名 ID、登录 ID、会员、会话", "进入、浏览、加购、离开", "跨设备身份如何关联，隐私边界如何控制"],
      ["交易", "订单头、订单行、优惠、支付单", "创建、待支付、已支付、取消、关闭", "金额分摊和订单状态回退如何表达"],
      ["库存履约", "仓、可售库存、预占、出库、包裹", "可用、预占、释放、出库、签收", "库存快照与事件如何对账"],
      ["售后", "退款单、退货单、售后工单", "申请、审核、退货、退款、完成", "部分退款和重复回调如何冲减"],
      ["经营分析", "主题事实、指标、人群、实验", "发布、版本、生效", "口径变更是否影响历史可比"]
    ]
  )}

## 端到端事件链

${table(
    ["环节", "事件/快照", "主键", "时间语义", "失败边界"],
    [
      ["商品曝光", "曝光事件", "event_id / session_id", "客户端发生时间与服务端接收时间分开", "重复曝光、机器人流量"],
      ["点击与详情", "点击、浏览事件", "event_id / item_id", "会话超时与跨端时间对齐", "埋点缺失、页面版本不一致"],
      ["加购", "购物车事件或快照", "cart_id / item_id", "加入、修改、删除分别成事件", "最新快照覆盖历史"],
      ["下单", "订单头与订单行", "order_id / order_line_id", "创单时间与支付截止时间分开", "订单头优惠重复分摊"],
      ["支付", "支付流水与支付回调", "payment_id / payment_attempt_id", "支付成功、入账、回调到达分开", "重复回调、支付成功订单已取消"],
      ["库存预占", "库存事件与日快照", "reservation_id / warehouse_id / sku_id", "预占、释放、出库成对处理", "超卖、快照延迟、门店盘点"],
      ["履约", "出库单、包裹、运单", "fulfillment_id / package_id", "发货、揽收、签收分节点", "拆包、改址、逆向物流"],
      ["售后", "退款与退货单", "refund_id / return_id", "申请、审核、到账分开", "部分退款、重复退款、跨期"]
    ]
  )}

事件流负责记录“发生了什么”，快照表负责回答“某一时刻状态是什么”。两者不能互相替代：只用事件很难快速查询当前库存，只用快照又会丢失预占、释放和回退过程。

## 分层架构与职责

${table(
    ["数据层", "核心内容", "保留粒度", "主要质量责任"],
    [
      ["ODS/接入层", "源系统变更、业务事件、日志和第三方回调", "尽量保留原始结构、批次和偏移", "完整性、重复、乱序与 schema 兼容"],
      ["明细层", "订单、支付、库存、履约、退款等标准事实", "业务过程原始粒度", "主键、状态、金额和对象关系"],
      ["主题层", "交易、履约、售后、用户、商品、流量主题", "可复用的对象和过程视图", "跨域一致性、历史归属与复用"],
      ["指标层", "成交、收入、退款、履约、库存和流量指标", "指标定义要求的聚合粒度", "分子分母、时间窗和版本"],
      ["服务层", "看板、API、人群、实时告警和实验分析", "使用场景所需的聚合结果", "权限、缓存、延迟和结果可解释"],
      ["治理层", "契约、血缘、质量、权限、成本与事故", "元数据与审计记录", "变更影响、可追溯和回退"]
    ]
  )}

层数本身不产生价值。真正的复用来自同一业务对象在明细、主题、指标和服务层保持一致，而不是把同一张宽表复制到每一层。

## 批流边界与关键取舍

${table(
    ["问题", "事件流方案", "批处理方案", "推荐边界"],
    [
      ["实时曝光、点击和转化", "延迟低，可做实时漏斗", "成本低、适合完整回算", "实时看趋势，离线做结算与严谨归因"],
      ["订单状态机", "及时更新待支付、取消和支付成功", "适合全量对账和历史重算", "流处理驱动状态，批处理做日终校验"],
      ["库存可售", "预占和释放需要秒级一致", "快照便于分析与回查", "事件保证操作，快照支持查询和对账"],
      ["支付与退款", "快速发现异常回调", "与财务流水、银行结算核对", "实时告警，最终以批量和财务对账为准"],
      ["大促容量", "需要削峰、限流和幂等", "离线任务可错峰", "核心链路隔离，非核心指标降级延迟"],
      ["历史修正", "回放成本高、状态复杂", "重算更清晰", "保留事件版本与分区，按影响范围回放"]
    ]
  )}

架构评审的问题不是“实时是否更先进”，而是业务是否真的在秒级做出不同决策。若业务每天只看一次库存健康，强行建设复杂实时链路只会增加故障面和成本。

## 核心模型

电商数仓至少应分别建模下面这些事实，而不是合成一张“万能订单表”：

${table(
    ["模型", "一行代表什么", "关键事实", "主要维度", "禁止混算"],
    [
      ["订单行事实", "一个订单中的一件商品行", "数量、标价、成交价、分摊优惠", "日期、用户、商品、渠道、活动", "订单头金额必须按规则分摊且处理尾差"],
      ["支付流水事实", "一次支付或退款支付流水", "支付金额、手续费、状态", "支付方式、账户、订单、时间", "失败尝试不计成交"],
      ["库存快照事实", "一个仓库 SKU 在一个时点的库存", "实物、锁定、可售、在途库存", "仓库、SKU、库存状态", "快照不能相加为流量"],
      ["库存事件事实", "一次预占、释放或扣减事件", "变动数量、原因、状态", "订单、仓、SKU、设备/操作人", "事件与快照要能日终对账"],
      ["履约事实", "一个包裹或履约节点", "发货数量、成本、时效", "仓、承运商、线路、地区", "父子包裹不能重复统计"],
      ["退款事实", "一次退款事件", "退款金额、原因、到账状态", "订单行、支付单、渠道", "部分退款不能冲减整单"]
    ]
  )}

## 电商场景复盘

### 场景一：订单状态跳变与支付回调重复

业务发现已取消订单仍进入成交额。排查时保留订单状态事件、支付回调和业务操作日志，按订单、支付单和回调 ID 去重，区分“支付成功但订单已关闭”“重复回调”“退款前状态”和“人工改单”。修复需要状态机约束与幂等消费，而不是只改报表过滤条件。

### 场景二：直播间成交高，退款和履约成本也高

直播分析不能只报 GMV。应把场次、主播、商品讲解、曝光、点击、下单、支付、退款和履约成本串起来，同时记录投流消耗和流量来源。跨场次用户需要去重，商品讲解事件要有版本，活动价和成交价分开。

### 场景三：库存显示可售，订单却持续缺货取消

检查实物库存、锁定库存、在途库存和渠道分配是否使用同一时点；盘点期间是否冻结可售；门店 POS 与中心仓库存同步是否存在延迟。修复后可售库存需要事件驱动，同时用日快照做差异对账和安全库存缓冲。

### 场景四：大促峰值下非核心任务拖垮核心链路

容量设计要区分支付、库存、履约和经营看板的优先级。通过削峰、限流、队列隔离、降级、预聚合和错峰批处理保护核心事件；对积压设置可观测阈值，并提前演练关闭非核心任务后的恢复。

### 场景五：退款与财务收入对不上

先将订单、支付、退款、结算和银行到账拆成不同事实，按支付单和退款单做对象级对账。差异分类包括跨期、重复退款、支付手续费、平台补贴、渠道结算和冲正。只有差异能回到原始流水和业务单据，财务口径才算闭环。

## 容量、SLA 与故障恢复

${table(
    ["质量属性", "建议目标", "观测方式", "恢复要求"],
    [
      ["核心事件完整性", "关键事件丢失率为 0，重复可识别", "源端计数、偏移量、事件 ID 去重率", "按偏移或分区重放"],
      ["支付与库存时效", "核心状态更新满足业务秒级或分钟级目标", "端到端 P95/P99、积压和消费延迟", "隔离非核心流量并优先恢复"],
      ["指标可见时间", "在经营动作前完成核心指标", "分区水位到看板可见时间", "保留旧版本并说明数据截止时间"],
      ["金额对账", "差异逐笔可解释", "订单、支付、退款、结算四方对账", "先冻结结算再按对象修复"],
      ["恢复", "回滚、重放与补数可重复执行", "演练记录、输出摘要与对账结果", "无对账不得宣布恢复完成"]
    ]
  )}

## 数据契约示例

${fence("yaml", `contract: ecommerce.order.payment_state
version: 2.1.0
owner: transaction-data
primary_key: [order_id, payment_attempt_id]
event_time: payment_succeeded_at
partition_key: dt
required_fields:
  - order_id
  - payment_attempt_id
  - payment_status
  - paid_amount
  - currency
state_machine:
  allowed: [created, processing, succeeded, failed, closed, refunded]
quality_rules:
  amount_must_be_non_negative: true
  duplicate_payment_attempt_blocking: true
  late_event_window_minutes: 120
compatibility:
  breaking_change_notice_days: 30
  rollback_contract_version: 2.0.0`)}

## 架构验收问题

${numberedList([
    "商品、用户、会话、订单、支付、库存、履约和退款的最小对象与主键是什么？",
    "哪些数据必须实时，哪些可以批量？实时延迟具体改变哪个业务动作？",
    "订单状态机、库存预占和支付回调如何保证幂等与乱序处理？",
    "大促峰值时哪些任务可以降级，核心链路如何隔离？",
    "退款、补贴、运费和履约成本如何在指标层正确归集？",
    "发生重复支付或库存异常时，影响范围能否在分钟级定位并恢复？",
    "数据契约、血缘、权限、质量门禁和回退方案是否随发布自动更新？"
  ])}

${references(profile, [
    ["AWS E-commerce Architecture Center", "https://aws.amazon.com/solutions/ecommerce/"],
    ["Microsoft Cloud Design Patterns", "https://learn.microsoft.com/azure/architecture/patterns/"],
    ["Google Cloud Architecture Framework", "https://cloud.google.com/architecture/framework"]
  ])}`;
}

function buildUserProfileArticle(profile) {
  return `${articleLead(profile, `用户画像的核心不是标签越多越好，而是身份可解释、特征不穿越、用途受约束、结果能验证。`)}

## 画像系统真正服务的决策

用户画像常用于人群圈选、运营触达、推荐排序、客服识别、风险控制和经营分析。不同用途对身份、时效、敏感度和可解释性的要求不同，不能共用一张“万能用户宽表”解决所有问题。

${table(
    ["用途", "需要什么画像", "时效要求", "主要风险"],
    [
      ["人群圈选", "标签定义、有效期、覆盖率和可解释条件", "离线或准实时", "人群过大、口径错误、排除条件遗漏"],
      ["活动触达", "可联系身份、授权、频控和排除名单", "分钟级到小时级", "打扰、越权营销、重复触达"],
      ["推荐排序", "行为特征、兴趣偏好和实时上下文", "秒级到分钟级", "特征穿越、反馈回路、冷启动"],
      ["客服与会员", "会员等级、服务历史和权益状态", "准实时", "身份错配、敏感标签暴露"],
      ["风险控制", "设备、行为、关联关系和风险规则", "毫秒级到秒级", "误伤、规则泄漏、样本偏差"],
      ["经营分析", "分群指标、生命周期和贡献结构", "离线", "把当前标签回溯历史"]
    ]
  )}

## 身份识别与 OneID

身份体系至少要区分匿名设备 ID、登录账号、会员 ID、手机号哈希、支付账号和服务端会话。合并规则不能只看“同一设备”或“同一手机号”，因为家庭成员共用设备、一人多号和换号都很常见。

${table(
    ["身份问题", "错误合并后果", "需要的证据", "处理方式"],
    [
      ["一人多号", "重复计算用户与价值", "登录、设备、支付、会员和历史关联", "候选合并、置信度、人工复核与拆分"],
      ["家庭成员共用设备", "不同成员兴趣和交易被混在一起", "登录切换、收货人、支付账户", "设备只作弱关联，不直接等同个人"],
      ["换手机号", "老用户被识别成新用户", "账号变更事件、实名或会员历史", "保留号码有效期和变更链"],
      ["匿名转登录", "活动前后无法计算同一批人", "匿名 ID、登录事件、会话时间", "以登录时点建立映射，不回溯篡改历史"],
      ["企业账号多人使用", "员工行为被误算成同一个人", "子账号、角色、组织关系", "个人身份与组织身份分层"]
    ]
  )}

OneID 的合并和拆分必须可逆。每次合并记录规则版本、证据、置信度、操作人和时间；拆分后相关标签、人群和权益要能重算，不能让错误身份永久扩散到下游。

## 标签体系

${table(
    ["标签类型", "例子", "计算方式", "验收重点"],
    [
      ["事实标签", "近 30 天支付订单数、最近登录时间", "直接聚合可观察行为", "时间窗、对象和状态"],
      ["规则标签", "高价值会员、沉睡用户", "业务规则组合", "规则版本、边界样本与覆盖率"],
      ["模型标签", "流失概率、品类偏好", "训练模型输出", "时间外验证、漂移和拒绝使用条件"],
      ["实时标签", "当前会话意图、近 10 分钟点击", "流式聚合或在线特征", "延迟、乱序、重复和特征时点"],
      ["敏感标签", "健康、金融、精确定位", "高约束数据来源", "用途、授权、最小化和访问审计"]
    ]
  )}

每个标签都应有资产卡：名称、业务定义、对象、粒度、计算公式、时间窗、来源、刷新频率、有效期、负责人、质量阈值、敏感级别、允许用途和版本。没有这些信息，标签即使能算出来，也无法被安全复用。

## 特征时点与离线实时一致性

用户画像最隐蔽的问题是特征穿越：预测用户在 11 月是否流失，却使用了 12 月才产生的客服记录或取消状态。正确做法是为每个样本固定观察时点，只允许使用该时点之前可见的数据，并记录特征回刷版本。

离线与实时特征还应使用同一套定义。例如“最近 30 天支付金额”在离线可能按自然日，在实时按滚动 30×24 小时；两者必须明确差异，或在特征平台统一计算口径，否则线上模型与离线评估会持续偏差。

## 五个真实工作场景

### 场景一：一人多号导致价值重复计算

同一用户使用手机号、微信和旧账号下单。若不合并，用户数和 LTV 被高估；若只凭设备直接合并，又会误伤家庭用户。处理方式是建立候选关系、证据强度和有效期，允许“弱关联用于分析、强关联用于权益”，关键动作前做人工或二次验证。

### 场景二：家庭成员共用设备

家庭平板一天内出现多个登录账号和收货人。系统应把设备作为共享环境，而不是把设备 ID 等同个人。登录切换、支付账户、收货地址和会员权益可提供更强证据；营销频控则按可联系身份和家庭设备双重控制，避免家庭成员被同一活动反复触达。

### 场景三：标签规则调整后的历史回刷

运营修改“高价值用户”门槛后，历史人群全部变化。若没有标签版本，无法解释活动效果和触达名单差异。应把标签规则、计算时间和生效窗口版本化；历史活动使用当时版本，当前圈选使用新版本，并建立差异对比和重新审批。

### 场景四：活动人群圈选错误

某次活动因排除条件遗漏，把已注销、无授权和近期投诉用户纳入触达。处理时把圈选拆成资格条件、排除条件、授权状态、频控和黑名单五层，发布前输出各层人数与抽样明细；高敏感用途还要经过人工审核。

### 场景五：实时标签延迟影响推荐

实时行为标签因消息积压延迟十分钟，推荐系统仍按“当前意图”使用，导致用户已离开页面仍持续推荐。解决不只是加机器，还要设置事件时间水位、过期标签、降级策略和实时与离线的一致性监控；超过可接受延迟时退回稳定特征。

## 隐私、权限与用途控制

${table(
    ["控制点", "最低要求", "失败示例"],
    [
      ["合法用途", "每个画像用途记录目的、授权与保存期限", "为“分析”无限期保留敏感标签"],
      ["最小字段", "只暴露完成当前任务所需标签", "客服看到完整健康与金融标签"],
      ["访问控制", "角色、字段、行级、用途和导出同时受控", "内网账号即可下载全量人群"],
      ["匿名化", "标识符与特征分开存储，必要时差分隐私或聚合", "派生的设备指纹仍可反识别"],
      ["审计", "圈选、导出、标签变更和模型调用可追溯", "活动名单来源无法追查"],
      ["撤回", "授权撤回后停止使用并处理已有派生资产", "已导出名单继续营销"]
    ]
  )}

## 标签与人群验收代码

${fence("sql", `-- ${profile.topic}：标签覆盖率、身份重复与授权状态检查
WITH scoped AS (
    SELECT
        one_id,
        tag_key,
        tag_value,
        feature_time,
        expire_at,
        consent_status,
        source_version
    FROM user_profile_tag_snapshot
    WHERE dt = DATE '2026-11-05'
      AND tag_key = 'high_value_30d'
),
identity_check AS (
    SELECT
        one_id,
        COUNT(DISTINCT source_member_id) AS member_cnt
    FROM user_identity_bridge
    WHERE dt = DATE '2026-11-05'
    GROUP BY one_id
)
SELECT
    COUNT(*) AS tag_rows,
    COUNT(DISTINCT one_id) AS user_cnt,
    SUM(CASE WHEN tag_value IS NULL THEN 1 ELSE 0 END) AS null_tag_cnt,
    SUM(CASE WHEN feature_time >= DATE '2026-11-06' THEN 1 ELSE 0 END) AS future_feature_cnt,
    SUM(CASE WHEN expire_at <= DATE '2026-11-05' THEN 1 ELSE 0 END) AS expired_tag_cnt,
    SUM(CASE WHEN consent_status <> 'allowed' THEN 1 ELSE 0 END) AS unauthorized_cnt
FROM scoped;

SELECT *
FROM identity_check
WHERE member_cnt > 3
ORDER BY member_cnt DESC;`)}

查询只能帮助发现结构风险。真正的身份合并、敏感标签使用和人群触达仍需业务、安全与法务按实际用途审批。

## 画像项目验收清单

${numberedList([
    "匿名、登录、会员、设备和支付身份之间的映射有证据、有效期和拆分机制。",
    "每个标签有定义、粒度、公式、时间窗、版本、有效期、Owner 和允许用途。",
    "离线与实时特征的关键口径一致，差异被显式记录并在模型评估中处理。",
    "人群圈选包含资格、排除、授权、频控和黑名单，并保留人数变化与抽样明细。",
    "敏感标签满足最小必要、分类分级、访问审计和撤回后处理要求。",
    "推荐、营销和运营上线前有基线、对照、护栏指标及停止条件。"
  ])}

${references(profile, [
    ["NIST Digital Identity Guidelines", "https://pages.nist.gov/800-63-4/"],
    ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"],
    ["IAB Tech Lab Data Transparency Standards", "https://iabtechlab.com/standards/"]
  ])}`;
}

function buildProjectArticle(profile) {
  const context = profile.context;
  return `${articleLead(profile, `项目类文章要说明范围、里程碑、交付证据和失败路径，而不是只列技术栈。`)}

## 项目目标与成功标准

“${profile.topic}”应先定义本轮项目不做什么。成功标准至少包含一个业务动作、一个可观察指标和一组可验证证据；仅有“系统上线”或“看板可打开”不算完成。

${table(
    ["项目要素", "需要确认", "示例证据"],
    [
      ["业务范围", `覆盖${context.stages.slice(0, 4).join("、")}中的哪些环节`, "范围说明与非目标清单"],
      ["使用者", `${context.participants.slice(0, 4).join("、")}分别如何使用结果`, "角色任务与操作记录"],
      ["主指标", context.metricDefs[0][0], "口径卡、基线与趋势"],
      ["质量目标", context.controls.slice(0, 3).join("、"), "门禁结果与抽样明细"],
      ["上线边界", "灰度范围、观察窗口、回滚条件", "发布单与回滚演练"],
      ["采用证据", "谁在用结果做什么决定", "决策记录与使用反馈"]
    ]
  )}

## 里程碑与交付物

${table(
    ["阶段", "关键交付", "评审问题", "未通过时"],
    [
      ["需求澄清", "对象、流程、指标和边界", "是否能指向真实决策", "不进入开发"],
      ["原型验证", "源字段、主键、状态和样例", "异常样本能否回到原始记录", "补数据契约"],
      ["数据开发", "明细、主题、指标和历史规则", "粒度与公式是否一致", "禁止发布"],
      ["质量与安全", "回归样本、权限、审计和恢复", "关键规则失败是否阻断", "修规则和逻辑"],
      ["灰度上线", "使用说明、监控、回滚和责任人", "使用者是否完成闭环动作", "缩小范围"],
      ["复盘", "指标、问题、成本和下一阶段", "是否值得扩展", "停止或重设目标"]
    ]
  )}

${casesSection(profile, "project", 3)}

${codeForRecipe(profile, "project")}

${failureSection(profile, "project")}

${references(profile)}`;
}

function buildDirectedArticle(profile) {
  const recipe = recipeOf(profile);
  switch (recipe) {
    case "enterprise-modeling":
      return buildEnterpriseModelingArticle(profile);
    case "ecommerce-architecture":
      return buildEcommerceArchitectureArticle(profile);
    case "user-profile":
      return buildUserProfileArticle(profile);
    case "metric":
      return buildMetricArticle(profile);
    case "industry":
      return buildIndustryArticle(profile);
    case "ai":
      return buildAiArticle(profile);
    case "career":
    case "resume":
    case "learning":
      return buildCareerArticle(profile, recipe);
    case "project":
      return buildProjectArticle(profile);
    case "classification":
      return buildClassificationArticle(profile);
    case "realtime-warehouse":
      return buildRealtimeWarehouseArticle(profile);
    case "performance":
      return buildPerformanceArticle(profile);
    case "quality":
      return buildQualityRuleArticle(profile);
    case "lineage":
      return buildLineageImpactArticle(profile);
    case "spark":
    case "streaming":
    case "sql":
    case "governance":
    case "architecture":
    case "engineering":
      return buildEngineeringArticle(profile, recipe);
    case "analytics":
      return buildGenericArticle(profile, recipe);
    default:
      return buildGenericArticle(profile, recipe);
  }
}

module.exports = {
  buildDirectedArticle,
  recipeOf
};
