const crypto = require("node:crypto");

const DOMAIN_DEFINITIONS = {
  modeling: {
    label: "企业数据建模",
    short: "建模",
    objects: ["客户", "账户", "交易", "产品", "机构", "协议"],
    stages: ["识别业务事件", "确定事实粒度", "定义一致性维度", "落实物理结构", "发布口径与血缘"],
    metrics: ["对象覆盖率", "粒度冲突数", "维度复用率", "历史变更可追溯率", "下游争议单量"],
    roles: ["业务数据负责人", "数据架构师", "模型开发", "指标负责人", "数据治理委员会"],
    systems: ["客户关系系统", "核心业务系统", "数据仓库", "元数据平台", "指标平台"],
    risks: ["事实粒度混用", "维度历史被覆盖", "同名指标多种口径", "模型变更未通知下游", "逻辑模型直接跳过评审"],
    controls: ["业务主键唯一且稳定", "事实表一行代表什么可复述", "维度有效期可关联", "模型变更保留版本", "关键指标通过业务验收"],
    standards: ["Kimball 维度建模技术", "DAMA-DMBOK2 数据建模知识领域", "TOGAF 架构治理方法"],
    cases: [
      ["某股份制银行零售数据团队", "客户、账户、交易三类主题长期各自建模，跨主题客户贡献无法对齐"],
      ["某大型保险集团数据架构组", "代理人、保单、赔付和佣金事件的粒度和历史归属不一致"],
      ["某连锁零售集团数据中台", "门店、商品、会员维度的历史变更覆盖了旧订单归属"],
      ["某券商客户分析平台", "行情、委托、成交和资金流水被错误地合并到同一事实表"],
      ["某公用事业集团主数据团队", "客户地址、服务点和合同版本缺少一致性维度"],
      ["某制造集团供应链数据组", "采购订单、入库批次和发票行的粒度不同，数量重复累计"]
    ]
  },
  finance: {
    label: "金融业务与风险管理",
    short: "金融",
    objects: ["客户", "授信", "账户", "交易", "合同", "资产", "负债"],
    stages: ["客户准入", "业务受理", "风险审批", "交易或放款", "存续期管理", "处置与复盘"],
    metrics: ["业务规模", "收益率", "风险成本", "不良或逾期", "资本占用", "客户贡献"],
    roles: ["客户经理", "风险经理", "资产负债管理", "财务与精算", "合规", "数据管理"],
    systems: ["核心账务系统", "信贷系统", "交易系统", "风险数据集市", "总账与财务系统"],
    risks: ["时点与期间口径混用", "并表范围不一致", "五级分类版本错配", "本金与利息重复计算", "风险缓释未按规则处理"],
    controls: ["业务日期与会计日期可区分", "合同与账户主键可追溯", "风险分类保留版本", "金额平衡关系可核对", "监管与会计口径分别登记"],
    standards: ["巴塞尔委员会资本与风险监管资料", "IFRS 9 金融工具减值框架", "中国人民银行公开统计口径"],
    cases: [
      ["某城市商业银行零售金融部", "季度不良率上升，但新增下迁、处置回收和核销的贡献无法拆清"],
      ["某全国性股份制银行公司业务部", "同一客户在多个分行有授信，集团口径与单户口径并存"],
      ["某保险集团精算数据中心", "保单、准备金和赔付口径在财务与监管报表之间差异扩大"],
      ["某证券公司风险管理部", "融资融券客户的担保品、负债和强平事件跨系统时点不一致"],
      ["某消费金融公司决策科学团队", "申请评分、额度使用和逾期表现无法按客户统一关联"],
      ["某资产托管机构运营部", "资金流水、持仓快照和估值结果缺少可重放的日切规则"],
      ["某区域性农商行业务管理部", "涉农贷款、普惠贷款和一般贷款的标签重复导致统计高估"],
      ["某基金公司投资运营团队", "净值、份额、申赎和费用数据在估值与登记系统间不一致"]
    ]
  },
  manufacturing: {
    label: "制造运营与工业数据",
    short: "制造",
    objects: ["工厂", "产线", "设备", "工单", "批次", "物料", "质量记录"],
    stages: ["计划排产", "物料准备", "生产加工", "质量检验", "入库发运", "异常复盘"],
    metrics: ["计划达成率", "设备利用率", "良品率", "生产周期", "库存周转", "单位制造成本"],
    roles: ["生产计划", "工艺工程师", "设备维护", "质量工程师", "仓储物流", "工业数据团队"],
    systems: ["MES", "APS", "WMS", "SCADA", "QMS", "ERP"],
    risks: ["计划时间与运行时间混淆", "工单和批次关联断裂", "标准节拍版本失效", "停机区间重叠", "质量返工被重复计数"],
    controls: ["设备时间台账连续", "工单与物料批次可追溯", "标准参数按生效日期版本化", "停机原因编码唯一", "产量与质检记录平衡"],
    standards: ["ISA-95 企业与控制系统集成模型", "ISO 22400 制造运行关键绩效指标", "OEE 通行分解方法"],
    cases: [
      ["某精密零部件工厂设备部", "设备频繁报警，但停机、微停和速度损失没有被放在同一时间账上"],
      ["某新能源电池材料工厂", "批次质量波动明显，工单、设备参数和检验结果无法快速串联"],
      ["某食品加工集团生产中心", "换型时间和清洗时间混在计划停机中，导致产能判断偏差"],
      ["某电子组装厂工业工程团队", "产出数量增加但良率下降，返工工时被计入有效产出"],
      ["某装备制造企业计划部", "订单变更频繁，物料齐套、瓶颈工序和交期承诺缺少统一节奏"],
      ["某汽车零部件供应商质量部", "供应商来料、上线批次和售后失效记录无法完成批次追踪"],
      ["某化工集团能源管理团队", "设备能耗、产量和班次数据跨表统计，单位产品能耗无法比较"],
      ["某医药制造企业生产质量部", "批次放行、偏差调查和环境监测记录之间缺少受控关联"]
    ]
  },
  retail: {
    label: "零售、电商与营销运营",
    short: "零售",
    objects: ["用户", "商品", "店铺", "订单", "活动", "流量", "履约单"],
    stages: ["曝光", "点击", "浏览", "加购", "支付", "履约", "售后", "复购"],
    metrics: ["CTR", "CVR", "客单价", "毛利率", "获客成本", "复购率", "退款率", "履约时效"],
    roles: ["商品运营", "用户运营", "投放优化师", "活动运营", "供应链", "数据分析师"],
    systems: ["广告平台", "推荐系统", "订单中心", "会员系统", "履约系统", "客服系统"],
    risks: ["曝光和点击口径不一致", "归因窗口相互重叠", "活动优惠重复计算", "自然增长被误当投放效果", "退款未回到同一用户和订单"],
    controls: ["用户与设备身份可映射", "订单金额按明细对账", "曝光和点击含去重规则", "归因窗口版本可追溯", "活动预算与核销平衡"],
    standards: ["Google Analytics 事件与转化测量原则", "OpenRTB 广告竞价概念", "Trustworthy Online Controlled Experiments 实验方法"],
    cases: [
      ["某全国连锁便利店会员团队", "会员数持续增长，但高价值会员占比和复购贡献无法一致解释"],
      ["某品牌服饰直营电商", "投放 ROI 看似改善，退款和跨渠道归因导致真实贡献被高估"],
      ["某内容电商平台商家运营组", "商品曝光增长但支付转化下降，问题可能同时来自流量质量与详情页"],
      ["某即时零售平台履约团队", "订单增长时配送超时和缺货率同时上升，履约瓶颈无法按区域定位"],
      ["某区域商超促销管理部", "活动券核销、优惠分摊和毛利结果在不同系统中口径不一致"],
      ["某在线教育增长团队", "试听注册、付费转化和续费留存被不同归因窗口重复统计"],
      ["某跨境电商类目运营组", "搜索词、关键词匹配和否定词调整后，广告结构变化无法复盘"],
      ["某会员制电商用户运营团队", "身份合并后同一家庭多账号的消费能力被重复计算"]
    ]
  },
  healthcare: {
    label: "医疗健康业务与数据",
    short: "医疗",
    objects: ["患者", "就诊", "医嘱", "检查检验", "处方", "费用", "随访"],
    stages: ["预约挂号", "接诊", "检查检验", "诊断治疗", "结算", "随访与质量复盘"],
    metrics: ["门急诊人次", "平均住院日", "检查及时率", "复诊率", "费用偏差", "质量事件率"],
    roles: ["临床科室", "护理", "医技", "医务管理", "医保", "信息中心", "数据治理"],
    systems: ["HIS", "EMR", "LIS", "RIS", "PACS", "医保结算", "随访平台"],
    risks: ["患者主索引重复", "临床时间与计费时间混用", "诊断编码版本失效", "检查单位不统一", "敏感数据越权访问"],
    controls: ["患者主索引跨院区唯一", "就诊与医嘱时间有序", "检验结果带单位和参考区间", "费用明细可对账", "访问目的与权限可审计"],
    standards: ["医疗质量安全核心制度", "电子病历应用管理规范", "个人信息保护法最小必要原则"],
    cases: [
      ["某区域三甲医院门诊部", "高峰投诉增加，但号源、接诊、检查和报告回传的断点无法区分"],
      ["某医疗集团运营管理中心", "多院区同一患者被重复计数，重点专科服务量口径不一致"],
      ["某互联网医院运营团队", "在线问诊订单增长，完成率却因医生供给和支付超时下降"],
      ["某医学影像中心质控组", "检查量增长后报告及时率波动，设备等待和复审返工混在一起"],
      ["某连锁药房会员团队", "购药、复购和用药依从性标签缺少授权与有效期管理"],
      ["某医药企业真实世界研究团队", "随访、用药和不良事件记录来自不同系统，时间关系不清晰"],
      ["某区域医保管理部门", "结算、审核和拒付明细无法按同一就诊与费用项目回查"],
      ["某专科医院经营分析组", "项目成本、收费和医保支付之间缺少可解释的桥接"]
    ]
  },
  governance: {
    label: "数据治理与数据管理",
    short: "治理",
    objects: ["数据资产", "业务术语", "指标", "数据标准", "质量规则", "责任角色", "权限策略"],
    stages: ["识别资产", "明确责任", "定义标准", "建立控制", "监测问题", "变更与复盘"],
    metrics: ["资产登记率", "规则通过率", "问题闭环时长", "血缘覆盖率", "变更影响面", "权限合规率"],
    roles: ["数据所有者", "数据管理员", "业务专家", "平台团队", "安全合规", "审计"],
    systems: ["元数据平台", "数据质量平台", "指标平台", "权限系统", "工单系统", "审计平台"],
    risks: ["责任边界不清", "质量规则只有告警没有处置", "血缘断点导致影响分析失真", "权限长期未复核", "标准与系统实现脱节"],
    controls: ["资产有唯一编号和责任人", "规则阈值有业务依据", "问题保留时间线与证据", "变更影响分析完整", "权限按用途和期限审批"],
    standards: ["DAMA-DMBOK2 数据管理知识体系", "NIST Privacy Framework", "NIST AI Risk Management Framework"],
    cases: [
      ["某集团共享服务中心", "同一客户指标在财务、运营和管理驾驶舱中名称相同但口径不同"],
      ["某银行数据治理办公室", "监管报表问题反复出现，却无法定位责任系统和上游变更"],
      ["某零售集团数据平台", "商品主数据在门店、电商和供应链系统中编码不一致"],
      ["某制造企业数据管理部", "设备停机原因编码各工厂自行扩展，集团报表无法汇总"],
      ["某保险公司数据安全团队", "分析人员长期持有宽表权限，敏感字段用途没有定期复核"],
      ["某互联网平台数据委员会", "表血缘只覆盖计算任务，接口和报表消费关系缺失"],
      ["某医药集团合规团队", "临床试验数据的访问目的、保留期限和跨境传输规则未落到系统"],
      ["某能源集团数据质量组", "质量规则数量很多，但没有区分阻断、告警和观察级别"]
    ]
  },
  analytics: {
    label: "数据分析与经营决策",
    short: "分析",
    objects: ["业务对象", "用户或客户", "事件", "指标", "分组", "实验或策略"],
    stages: ["定义决策问题", "确认对象与口径", "建立基线", "拆解变化", "验证假设", "行动与复盘"],
    metrics: ["规模", "转化率", "留存率", "贡献度", "波动区间", "护栏指标"],
    roles: ["业务负责人", "数据分析师", "产品经理", "运营", "实验平台", "决策委员会"],
    systems: ["业务数据库", "埋点平台", "数据仓库", "实验平台", "BI 工具", "行动系统"],
    risks: ["总体平均掩盖分层差异", "分母随筛选条件变化", "多重比较产生假阳性", "相关关系被解释为因果", "行动没有负责人和停止条件"],
    controls: ["对象、粒度、时间和排除项固定", "基线具有可比性", "切分次数预先登记", "实验分流和数据污染已检查", "结论绑定行动与复核日期"],
    standards: ["Trustworthy Online Controlled Experiments", "Google Analytics 指标定义原则", "OECD 复合指标构建方法"],
    cases: [
      ["某电商增长分析团队", "总体转化率只小幅下降，但多个渠道和用户层级的贡献方向相反"],
      ["某内容平台策略组", "推荐点击率提升，长期留存和内容多样性却可能恶化"],
      ["某连锁餐饮经营分析部", "门店营业额下降，需要区分客流、客单、时段和新店结构"],
      ["某 SaaS 产品数据团队", "功能使用率上升，但续费和客服工单显示价值并未同步改善"],
      ["某出行平台城市运营组", "补贴上线后订单增长，自然需求和预算浪费难以分离"],
      ["某银行客户经营团队", "活动响应率提高，但高价值客户被过度触达且投诉上升"],
      ["某物流企业经营分析组", "单票成本下降，时效、破损和临时外包费用却出现反向变化"],
      ["某在线教育产品团队", "试听转化率和续费率对同一策略给出不同结论"]
    ]
  }
};

const DOMAIN_ORDER = [
  ["resume", /简历|履历|CV模板|作品集模板/i],
  ["learning", /学习路线|学习路径|成长路线|升级路线|能力地图|入门路线|训练计划|学习方法/i],
  ["career", /面试|求职|招聘|简历|薪资|职业发展|晋升|向上管理|沟通表达|领导力|职场|岗位解析|转行|offer|作品集/i],
  ["modeling", /企业级建模|数据建模|维度建模|事实表|维度表|一致性维度|总线矩阵|Data Vault|范式建模|雪花模型|星型模型/i],
  ["rag", /RAG|检索增强|向量数据库|Embedding|语义检索|混合检索|重排/i],
  ["agent", /Agent|智能体|工具调用|多Agent|控制平面|沙箱/i],
  ["text-to-sql", /Text[\s-]*to[\s-]*SQL|NL2SQL|自然语言.*SQL/i],
  ["kafka", /Kafka|消费积压|分区副本|Rebalance|消费者组/i],
  ["spark", /Spark|RDD|DataFrame|Shuffle|DAGScheduler|TaskScheduler|MLlib|mapPartition/i],
  ["streaming", /Flink|实时计算|流处理|水位线|Checkpoint|CDC|变更数据捕获/i],
  ["service", /数据服务|API|RESTful|GraphQL|接口部署|服务部署|SLA|SLO/i],
  ["warehouse", /数据仓库|数仓|数据湖|湖仓|ODS|DWD|DWS|ADS|分层建设|主题域/i],
  ["governance", /治理|数据质量|血缘|元数据|主数据|数据标准|分类分级|安全|隐私|合规|权限|审计|成熟度|数据合约/i],
  ["manufacturing", /制造|设备|产线|OEE|工单|批次|MES|质量|供应链|库存|生产|工厂|工业/i],
  ["finance", /银行|保险|证券|基金|信贷|贷款|资本|存款|拨备|偿付|精算|利率|汇率|股票|债券|市盈率|市净率|ROE|ROA|EBITDA|不良|逾期|金融|投资|支付/i],
  ["retail", /零售|电商|广告|直通车|投放|关键词|会员|复购|转化|GMV|GMV|客单|履约|商品|店铺|流量|用户画像|RFM|营销/i],
  ["healthcare", /医疗|医院|患者|临床|检验|药品|医药|医保|问诊|基因组|生物信息|影像/i],
  ["analytics", /分析|指标|看板|漏斗|留存|活动|渠道|经营|实验|A\/B|归因|用户行为|数据运营/i],
  ["ai", /人工智能|机器学习|深度学习|大模型|LLM|Prompt|MLOps|模型评估|微调|多模态|特征工程|推荐系统|自然语言处理|计算机视觉/i],
  ["sql", /SQL|窗口函数|TopN|连续活跃|行列转换|Join|聚合|查询/i],
  ["project", /项目|实战|建设方案|迁移项目|优化项目/i],
  ["industry", /行业|业务|产业链|全景|概览|基础知识/i]
];

const ORG_POOLS = {
  finance: ["某城市商业银行", "某股份制银行分行", "某区域性农商行", "某消费金融公司", "某保险集团", "某证券公司", "某基金管理公司", "某金融科技平台"],
  manufacturing: ["某精密制造工厂", "某新能源材料企业", "某装备制造集团", "某食品加工企业", "某电子组装工厂", "某汽车零部件供应商", "某医药制造企业", "某化工集团"],
  retail: ["某连锁零售集团", "某品牌电商团队", "某内容电商平台", "某即时零售平台", "某会员制商超", "某跨境电商团队", "某生活服务平台的商家团队"],
  healthcare: ["某区域医疗集团", "某三甲医院", "某互联网医院", "某医学影像中心", "某连锁药房", "某医药研发企业"],
  governance: ["某集团数据治理办公室", "某银行数据管理部", "某零售集团数据平台", "某制造企业数据团队", "某保险公司数据安全团队", "某平台企业数据委员会"],
  analytics: ["某电商增长团队", "某内容平台策略组", "某 SaaS 产品团队", "某连锁餐饮品牌", "某出行平台城市运营组", "某物流企业经营分析部"],
  engineering: ["某内容平台数据平台团队", "某物流企业实时计算团队", "某 SaaS 公司工程团队", "某零售集团数据中台", "某银行大数据平台", "某制造企业工业数据团队"],
  ai: ["某企业知识服务团队", "某内容平台算法团队", "某金融机构模型风险团队", "某制造企业智能应用团队", "某 SaaS 公司 AI 产品团队", "某医疗科技企业"],
  industry: ["某跨区域经营企业", "某上市集团数字化中心", "某行业解决方案公司", "某公共服务机构", "某区域产业集团", "某连锁经营企业"]
};

const CODE_ELIGIBLE = new Set([
  "modeling", "rag", "agent", "text-to-sql", "kafka", "spark", "streaming",
  "service", "warehouse", "governance", "sql", "project"
]);

function hashNumber(value) {
  let hash = 2166136261;
  for (const char of String(value)) {
    hash ^= char.codePointAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function pick(items, seed, offset = 0) {
  return items[(seed + offset) % items.length];
}

function dedupe(items) {
  return [...new Set(items.filter(Boolean))];
}

function esc(value) {
  return String(value).replaceAll("|", "\\|").replaceAll("\n", " ");
}

function table(headers, rows) {
  return [
    `| ${headers.map(esc).join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${row.map(esc).join(" | ")} |`)
  ].join("\n");
}

function fence(language, code) {
  return `\`\`\`${language}\n${code.trim()}\n\`\`\``;
}

function identifier(value, fallback = "subject") {
  const result = String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
  return result || fallback;
}

function classifyArticle(profile) {
  const source = `${profile.relativePath} ${profile.title}`;
  for (const [domain, pattern] of DOMAIN_ORDER) {
    if (pattern.test(profile.title)) return domain;
  }
  for (const [domain, pattern] of DOMAIN_ORDER) {
    if (pattern.test(source)) return domain;
  }
  if (profile.relativePath.startsWith("【求职就业专题】")) return "career";
  if (profile.relativePath.startsWith("【学习路线】") || profile.relativePath.startsWith("【学习方法分享】")) return "learning";
  if (profile.relativePath.startsWith("【数据治理与数据管理】")) return "governance";
  if (profile.relativePath.startsWith("【项目实战库】")) return "project";
  if (profile.relativePath.startsWith("【数据开发与数据架构】")) return "warehouse";
  if (profile.relativePath.startsWith("【AI 与大数据】")) return "ai";
  if (profile.relativePath.startsWith("【各行业的基础知识】")) return "industry";
  return profile.relativePath.startsWith("【数据分析与数据运营】") ? "analytics" : "industry";
}

function domainDefinition(domain) {
  if (domain === "engineering") return DOMAIN_DEFINITIONS.warehouse;
  return DOMAIN_DEFINITIONS[domain] || DOMAIN_DEFINITIONS.analytics;
}

function sourceSelection(domain, seed) {
  const common = {
    modeling: [
      ["DAMA 数据管理知识体系", "https://www.dama.org/cpages/body-of-knowledge"],
      ["Kimball 维度建模技术", "https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/"],
      ["TOGAF 企业架构方法", "https://www.opengroup.org/togaf"]
    ],
    finance: [
      ["巴塞尔委员会公开资料", "https://www.bis.org/bcbs/publications.htm"],
      ["IFRS 9 金融工具", "https://www.ifrs.org/issued-standards/list-of-standards/ifrs-9-financial-instruments/"],
      ["中国人民银行统计数据", "http://www.pbc.gov.cn/diaochatongjisi/116219/index.html"]
    ],
    manufacturing: [
      ["ISA-95 标准概览", "https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard"],
      ["ISO 22400 制造 KPI", "https://www.iso.org/standard/54497.html"],
      ["NIST 智能制造", "https://www.nist.gov/programs-projects/smart-manufacturing"]
    ],
    retail: [
      ["OpenRTB 规范", "https://iabtechlab.com/standards/openrtb/"],
      ["实验方法指南", "https://experimentguide.com/"],
      ["Google Analytics 测量原则", "https://support.google.com/analytics/answer/12159447"]
    ],
    governance: [
      ["DAMA-DMBOK2", "https://www.dama.org/cpages/body-of-knowledge"],
      ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"],
      ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"]
    ],
    streaming: [
      ["Apache Kafka 文档", "https://kafka.apache.org/documentation/"],
      ["Apache Flink 文档", "https://nightlies.apache.org/flink/flink-docs-stable/"],
      ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"]
    ],
    rag: [
      ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"],
      ["Microsoft RAG 架构指南", "https://learn.microsoft.com/azure/architecture/ai-ml/guide/rag/"],
      ["OpenAI 检索评估指南", "https://platform.openai.com/docs/guides/retrieval"]
    ],
    ai: [
      ["Google Rules of Machine Learning", "https://developers.google.com/machine-learning/guides/rules-of-ml"],
      ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"],
      ["Google Machine Learning 指南", "https://developers.google.com/machine-learning/guides"]
    ],
    analytics: [
      ["Trustworthy Online Controlled Experiments", "https://experimentguide.com/"],
      ["OECD 复合指标手册", "https://www.oecd.org/en/publications/handbook-on-constructing-composite-indicators-methodology-and-user-guide_9789264043466-en.html"],
      ["Google Analytics 文档", "https://developers.google.com/analytics"]
    ]
  };
  const list = common[domain] || common[domain === "warehouse" || domain === "service" ? "streaming" : "analytics"] || [];
  return [pick(list, seed, seed % Math.max(list.length, 1)), pick(list, seed, (seed + 1) % Math.max(list.length, 1))]
    .filter((item, index, values) => item && values.findIndex((candidate) => candidate?.[1] === item[1]) === index);
}

function topicLead(profile, domain, seed) {
  const def = domainDefinition(domain);
  const openers = [
    `“${profile.topic}”真正要解决的，不是把一个术语解释得更复杂，而是让${def.objects.slice(0, 3).join("、")}之间的业务动作可以被记录、复核并支持决策。`,
    `把“${profile.topic}”放进日常工作，最先要回答的是：谁在什么时点做决定，哪条记录能证明这个决定没有偏离业务事实。`,
    `讨论“${profile.topic}”时，工具只是实现手段。更重要的是对象边界、状态变化、指标口径和失败后的处理方式。`,
    `一个可靠的“${profile.topic}”方案，应当能让业务人员说清结果代表什么，也能让工程人员回到原始事件解释差异。`,
    `“${profile.topic}”常被写成概念清单，但落到${def.label}中，它必须连接角色、流程、系统记录和验收证据。`,
    `如果只能保留“${profile.topic}”的一条实践原则，那就是先固定业务对象与时间窗，再讨论算法、平台或报表。`
  ];
  return pick(openers, seed);
}

function objectRows(profile, domain, seed) {
  const def = domainDefinition(domain);
  return def.objects.slice(0, 5).map((object, index) => [
    object,
    index === 0 ? `围绕“${profile.topic}”识别主对象和唯一标识` : `记录${object}在流程中的状态、时间与责任人`,
    def.controls[index % def.controls.length],
    index < 3 ? "阻断口径不明的发布" : "抽样回查并登记差异"
  ]);
}

function metricRows(profile, domain, seed) {
  const def = domainDefinition(domain);
  return def.metrics.slice(0, 5).map((metric, index) => [
    metric,
    index === 0 ? `先定义“${profile.topic}”对应的对象范围与观察周期` : `按${def.objects[index % def.objects.length]}和时间窗拆分`,
    def.risks[index % def.risks.length],
    `${def.roles[index % def.roles.length]}确认口径与处置`
  ]);
}

function caseLocation(profile, domain, seed, index) {
  const pool = ORG_POOLS[domain] || ORG_POOLS[domainDefinition(domain).short] || ORG_POOLS.industry;
  return pool[(seed + index * 3) % pool.length];
}

function domainCase(domain, seed, index) {
  const def = domainDefinition(domain);
  const raw = def.cases[(seed + index * 2) % def.cases.length];
  return {
    org: caseLocation(domain, domain, seed, index),
    source: raw[0],
    trigger: raw[1],
    object: def.objects[(seed + index) % def.objects.length],
    evidence: def.controls[(seed + index) % def.controls.length],
    risk: def.risks[(seed + index * 2) % def.risks.length],
    metric: def.metrics[(seed + index) % def.metrics.length],
    system: def.systems[(seed + index) % def.systems.length]
  };
}

function caseBlock(profile, domain, seed, index) {
  const item = domainCase(domain, seed, index + 1);
  const lenses = [
    ["发现问题", "先冻结对象、时间和筛选条件", "把异常分组下钻到事件明细", "形成阻断、修复或继续观察的决定"],
    ["验证方案", "在新旧结果间建立可解释的差异桥", "检查正常、边界和反例样本", "只有主指标与护栏同时满足才扩大范围"],
    ["运营复盘", "记录谁在何时采用了什么动作", "观察完整业务周期而不是当天结果", "把一次性修复沉淀成规则、监控和责任"]
  ][index % 3];
  const unexpected = [
    `最初看似是“${item.risk}”，复核后却发现另一个更基础的字段版本没有统一。`,
    `团队先怀疑${item.system}性能不足，直到把${item.object}的事件时间与状态画出来，才确认是链路语义不一致。`,
    `业务方希望直接调整${item.metric}阈值，但抽样明细显示部分对象根本不该进入本主题范围。`
  ][(seed + index) % 3];
  return `### 案例 ${index + 1}：${item.org}如何核对“${profile.topic}”

这是一则脱敏复合示例，用来展示可复用的判断过程，不对应任何单一企业的真实数据。场景起点是：${item.trigger}。团队把“${profile.topic}”落到${item.object}上，并约定${lenses[0]}，避免讨论停留在概念争论。

- **业务问题**：${profile.topic}需要支持“${lenses[2]}”，而不是只产出一张总览。${unexpected}
- **数据证据**：从${item.system}取事件或状态记录，同时核对${item.evidence}；样本覆盖正常、跨期、重复、缺失和被排除对象，并保留查询版本。
- **处理动作**：先做${lenses[0]}，再${lenses[1]}。如果发现差异，按“源系统事实、接入、计算、口径、展示”五层分别定位，不把所有问题都交给加机器解决。
- **示例验收**：示例结果会把主指标${item.metric}、风险项${item.risk}和至少 20 条对象级样本放在同一份验收记录中；结论标注为样例，不作为真实经营事实。
- **可迁移经验**：${lenses[2]}。当同类标题换到另一个业务域时，判断顺序仍然成立，但对象、状态和指标必须重新定义。`;
}

function decisionSection(profile, domain, seed) {
  const def = domainDefinition(domain);
  return `## 先把“${profile.topic}”还原成一项决策

${topicLead(profile, domain, seed)} 这项工作的使用者通常是${def.roles.slice(0, 3).join("、")}。他们需要的不是更多术语，而是一个能触发行动的判断：继续、阻断、重算、补数、调整策略，还是转人工处理。

${table(
    ["决策要素", `“${profile.topic}”需要写清的内容`, "常见错误"],
    [
      ["业务目标", `改善${def.label}中的哪项结果，由谁承担后果`, "只写“提升效率”或“建设平台”"],
      ["对象范围", `${def.objects.slice(0, 4).join("、")}中哪些纳入、哪些排除`, "不同对象被混进同一分母"],
    ["时间规则", "采用事件时间、入账时间还是处理时间", "把发生、到达和更新时间混用"],
      ["证据等级", "总量、分组、对象样本和原始单据分别证明什么", "只有汇总截图，没有明细回查"],
      ["停止条件", "出现什么风险和副作用时必须暂停", "为了完成上线而忽略护栏"]
    ]
  )}`;
}

function mechanismSection(profile, domain, seed) {
  const def = domainDefinition(domain);
  const variant = seed % 3;
  const process = def.stages
    .map((stage, index) => `${index + 1}. **${stage}**：记录${def.objects[index % def.objects.length]}的对象、状态、时间和责任人。`)
    .join("\n");
  return `${pick([
    `## 运行机制：${profile.topic}怎样从业务动作变成可用数据`,
    `## 一条完整证据链如何支撑${profile.topic}`,
    `## ${profile.topic}的流程断点通常出现在哪里`
  ], seed, variant)}

在${def.label}里，“${profile.topic}”通常跨越多个系统。只看最终表，很容易把业务差异误判成系统故障。更可靠的做法是沿下面这条链逐段留下证据。

${process}

${table(
    ["参与角色", "关心什么", "必须留下的记录"],
    def.roles.slice(0, 5).map((role, index) => [
      role,
      index === 0 ? "目标、范围和最终决定" : `“${profile.topic}”执行中的${["口径", "质量", "权限", "时效", "例外"][index % 5]}`,
      `${def.controls[index % def.controls.length]}，并关联${def.systems[index % def.systems.length]}`
    ])
  )}`;
}

function metricSection(profile, domain, seed) {
  return `## 指标不是数字墙：${profile.topic}要怎样验证

围绕“${profile.topic}”，建议把指标分成结果、过程、质量和护栏四组。结果指标回答是否达成目标；过程指标解释变化从哪里来；质量指标防止错误结论；护栏指标提醒团队没有用高成本或高风险换取表面改善。

${table(
    ["观察面", "建议指标", "拆解方式", "容易误判的地方", "处置责任"],
    metricRows(profile, domain, seed)
  )}

> 对任何比率都同时保留分子、分母、样本量和分布。示例中的阈值只能用于说明方法，真实阈值应由${domainDefinition(domain).roles[0]}根据业务容差、历史基线和风险偏好确认。`;
}

function counterexampleSection(profile, domain, seed) {
  const def = domainDefinition(domain);
  const items = [
    `把“${profile.topic}”当成一个静态名词，却没有说明它作用于哪个${def.objects[0]}、哪个状态和哪个时间段。`,
    `只看总体${def.metrics[0]}，忽略分层后方向相反的贡献，最后用一个平均值掩盖真正的执行问题。`,
    `发现异常后直接修改代码或阈值，没有保存输入、版本、样本和现场，导致问题无法复现。`,
    `把${def.systems[0]}和${def.systems[1]}中的同名字段当成同义字段，实际业务时间和含义并不一致。`,
    `验收只展示成功路径，没有检查${def.risks[0]}和一次故障恢复。`
  ];
  return `## 五个反例：${profile.topic}最容易做偏的地方

${items.map((item, index) => `${index + 1}. ${item}`).join("\n")}

这些反例共同说明：${profile.topic}的质量取决于边界和证据，而不是术语数量。评审时可以让最了解原始业务的人随机挑一条异常记录，再从最终结果反走到源系统；如果中途有一跳无法解释，方案就还不能称为闭环。`;
}

function actionSection(profile, domain, seed) {
  const def = domainDefinition(domain);
  return `## 从试点到常态运行

第一轮不要把范围扩到所有部门和所有历史数据。选一个对象清晰、业务愿意参与的${def.label}场景，用两周完成一次小闭环，并把成功与失败都留下记录。

${table(
    ["阶段", `围绕“${profile.topic}”的动作`, "交付物", "退出条件"],
    [
      ["第 1 步：定边界", `确认${def.objects.slice(0, 3).join("、")}、观察期和排除规则`, "一页对象与口径说明", "业务、数据和系统三方能复述同一含义"],
      ["第 2 步：验现状", `抽样核对${def.controls.slice(0, 2).join("、")}`, "基线与异常样本", "问题可以回到原始记录"],
      ["第 3 步：做最小方案", `只修复一个最关键环节，不使用“大而全”平台替代问题定义`, "配置、代码或流程变更", "回放测试和边界样本通过"],
      ["第 4 步：小范围运行", `观察${def.metrics.slice(0, 2).join("、")}和护栏`, "灰度对比与问题清单", "差异可解释，副作用可控"],
      ["第 5 步：固化", `把口径、责任人、告警和复盘节奏登记到平台`, "运行手册与责任矩阵", "人员变更后仍能按文档执行"]
    ]
  )}`;
}

function acceptanceSection(profile, domain, seed) {
  const def = domainDefinition(domain);
  return `## 验收时不要只问“有没有做”

对于“${profile.topic}”，验收至少要覆盖业务、数据、工程、安全和运营五个面。下面的检查表适合评审会逐项过，不适合只在项目结束时补材料。

${table(
    ["验收面", "可观察证据", "不通过时的动作"],
    [
      ["业务", `使用者能说明${profile.topic}支持什么决策，并指出一次实际采用记录`, "回到需求方重写目标"],
      ["数据", `对象、粒度、时间、排除项和${def.controls[0]}均有样本`, "冻结发布并修复口径"],
      ["工程", "重复执行、异常重试、监控、回滚和容量有记录", "缩小范围或补齐控制"],
      ["安全", `权限、用途、敏感字段和审计满足${def.standards[0]}的要求`, "暂停访问并复核授权"],
      ["运营", "有负责人、复盘节奏、停止条件和未解决问题清单", "不得宣布完成"]
    ]
  )}`;
}

function referenceBlock(profile, domain, seed) {
  const sources = sourceSelection(domain, seed);
  const methodText = sources
    .map(([name]) => name)
    .join("、");
  return `## 方法依据与使用边界

本文围绕“${profile.topic}”按公开方法进行原创整理，重点参考${methodText || "行业通行实践"}。没有复制任何付费社区文章的隐藏正文，也不把示例当成真实企业结论。

${sources.length ? sources.map(([name, url]) => `- [${name}](${url})`).join("\n") : ""}

> 文中的组织名称、数据规模、指标变化和处理结果均为脱敏复合示例。正式使用前，需要结合企业制度、系统版本、授权范围与业务验收重新核对。`;
}
