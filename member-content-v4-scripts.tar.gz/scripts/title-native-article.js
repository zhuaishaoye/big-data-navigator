const SOURCE_GROUPS = {
  modeling: [
    ["DAMA-DMBOK2", "https://www.dama.org/cpages/body-of-knowledge"],
    ["TOGAF Standard", "https://www.opengroup.org/togaf"],
    ["Kimball Dimensional Modeling Techniques", "https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/"]
  ],
  finance: [
    ["Basel Committee publications", "https://www.bis.org/bcbs/publications.htm"],
    ["IFRS Foundation", "https://www.ifrs.org/"],
    ["中国人民银行统计数据", "http://www.pbc.gov.cn/diaochatongjisi/116219/index.html"]
  ],
  manufacturing: [
    ["ISA-95 overview", "https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard"],
    ["ISO 22400-2", "https://www.iso.org/standard/54497.html"],
    ["NIST Smart Manufacturing", "https://www.nist.gov/programs-projects/smart-manufacturing"]
  ],
  streaming: [
    ["Apache Kafka documentation", "https://kafka.apache.org/documentation/"],
    ["Apache Flink documentation", "https://nightlies.apache.org/flink/flink-docs-stable/"],
    ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"]
  ],
  spark: [
    ["Apache Spark documentation", "https://spark.apache.org/docs/latest/"],
    ["Spark MLlib guide", "https://spark.apache.org/docs/latest/ml-guide.html"],
    ["Google Rules of Machine Learning", "https://developers.google.com/machine-learning/guides/rules-of-ml"]
  ],
  rag: [
    ["NIST AI Risk Management Framework", "https://www.nist.gov/itl/ai-risk-management-framework"],
    ["Microsoft RAG solution design", "https://learn.microsoft.com/azure/architecture/ai-ml/guide/rag/"],
    ["OpenAI retrieval evaluation guidance", "https://platform.openai.com/docs/guides/retrieval"]
  ],
  service: [
    ["OpenAPI Specification", "https://spec.openapis.org/oas/latest.html"],
    ["Google SRE Workbook", "https://sre.google/workbook/table-of-contents/"],
    ["Microsoft Cloud Design Patterns", "https://learn.microsoft.com/azure/architecture/patterns/"]
  ],
  governance: [
    ["DAMA-DMBOK2", "https://www.dama.org/cpages/body-of-knowledge"],
    ["NIST Privacy Framework", "https://www.nist.gov/privacy-framework"],
    ["Open Data Contract Standard", "https://bitol-io.github.io/open-data-contract-standard/latest/"]
  ],
  sql: [
    ["PostgreSQL window functions", "https://www.postgresql.org/docs/current/tutorial-window.html"],
    ["SQL:2016 standard overview", "https://www.iso.org/standard/63555.html"],
    ["DuckDB SQL documentation", "https://duckdb.org/docs/sql/introduction"]
  ],
  general: [
    ["NIST Big Data Interoperability Framework", "https://www.nist.gov/programs-projects/nist-big-data-interoperability-framework"],
    ["OpenTelemetry Documentation", "https://opentelemetry.io/docs/"],
    ["AWS Well-Architected Framework", "https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html"]
  ]
};

const REGION_CASES = {
  finance: [
    "某城市商业银行零售金融部",
    "某区域性银行资产负债管理团队",
    "某消费金融公司风险管理部",
    "某保险集团精算与财务数据团队",
    "某证券公司经营分析团队"
  ],
  retail: [
    "某全国连锁便利店",
    "某品牌服饰直营网店",
    "某区域商超会员运营团队",
    "某内容电商平台商家运营团队",
    "某即时零售平台履约分析团队"
  ],
  manufacturing: [
    "某精密零部件工厂设备部",
    "某新能源电池产线质量团队",
    "某食品加工集团生产运营中心",
    "某装备制造企业计划部",
    "某电子组装厂工业工程团队"
  ],
  healthcare: [
    "某区域医疗集团运营管理部",
    "某三甲医院门诊办公室",
    "某互联网医院服务运营团队",
    "某医学影像中心质控团队",
    "某连锁药房会员运营团队"
  ],
  technology: [
    "某内容平台数据平台团队",
    "某物流企业实时计算团队",
    "某 SaaS 公司数据产品团队",
    "某出行平台算法工程团队",
    "某在线教育平台增长数据团队"
  ],
  general: [
    "某跨区域经营企业的数据团队",
    "某上市公司数字化运营中心",
    "某集团共享服务中心",
    "某行业解决方案团队",
    "某区域公共服务机构"
  ]
};

const FINANCE_SPECS = [
  {
    match: /不良贷款率/,
    definition: "不良贷款率衡量贷款组合中按既定分类标准被认定为不良的余额占比，分母是贷款余额，不是全部生息资产。迁徙率用于观察正常、关注、次级、可疑和损失类贷款在期间内的上迁与下迁，必须结合五级分类快照、逾期天数、重组标识以及核销和处置记录解释不良率变化。",
    formula: "不良贷款率 = 不良贷款余额 ÷ 各项贷款余额 × 100%",
    numerator: "按五级分类口径纳入次级、可疑、损失类的贷款余额。",
    denominator: "同一时点、同一并表范围、同一币种折算口径下的各项贷款余额。",
    dimensions: ["贷款五级分类", "逾期天数", "担保方式", "客户类型", "产品", "分行", "币种"],
    traps: ["把核销金额直接从未偿余额中剔除却不留过程台账", "用平均余额计算时点不良率", "把重组贷款在观察期内直接恢复为正常类", "并表口径与本行口径混用"],
    case: "某区域银行发现季度不良率上升，先按五级分类、逾期账龄、产品和分行拆解，再分别核对新增下迁、处置回收和核销。数据团队为每笔贷款保存分类版本、逾期快照和处置流水，最终把总变化拆成“新发生不良、存量回收、核销出表、口径调整”四座桥。"
  },
  {
    match: /拨备覆盖率/,
    definition: "拨备覆盖率看贷款损失准备对不良贷款余额的覆盖程度，反映损失吸收能力，但不能单独说明盈利能力和资产质量。",
    formula: "拨备覆盖率 = 贷款损失准备 ÷ 不良贷款余额 × 100%",
    numerator: "符合会计与监管口径的贷款损失准备，包含减值准备及按规则纳入的调整项。",
    denominator: "同一报告时点、同一并表范围的不良贷款余额。",
    dimensions: ["机构", "产品", "五级分类", "拨备方法", "报告期间", "并表范围"],
    traps: ["不同时点的准备与不良余额混搭", "把当期计提额误当准备余额", "忽略核销、转回和汇率变化", "只报覆盖率不看绝对缺口"],
    case: "某银行覆盖率改善但不良余额也快速下降，经营会要求判断改善究竟来自新增计提、核销还是分母收缩。分析团队用准备变动表连接贷款分类迁移，把覆盖率变化拆成计提、核销、回收、下迁与汇率五项，并在报表中同时展示不良余额和准备金额。"
  },
  {
    match: /资本充足率/,
    definition: "资本充足率把合格资本与风险加权资产连接起来，核心不是普通财务比率，而是资本监管口径下的风险承载指标。",
    formula: "资本充足率 = 合格资本净额 ÷ 风险加权资产 × 100%",
    numerator: "按适用监管规则计量的核心一级资本、其他一级资本和二级资本扣减项后的净额。",
    denominator: "信用风险、市场风险和操作风险对应的风险加权资产。",
    dimensions: ["资本层级", "风险类别", "资产组合", "计量方法", "监管主体", "报告时点"],
    traps: ["监管资本与会计权益混用", "风险暴露与风险加权资产混用", "忽略不同机构的规则适用差异", "并表与单体结果混排"],
    case: "某银行资本充足率季度波动，团队先核对资本净额和风险加权资产两条桥。资本侧检查利润留存、分红、其他综合收益和扣减项；资产侧检查风险暴露增长、风险缓释和权重变化，最终把单季变化定位到一个资产组合的计量规则切换，而不是简单归因于利润下降。"
  },
  {
    match: /净资产收益率|ROE/i,
    definition: "ROE衡量股东投入资本产生净利润的效率，关键在于平均权益口径、归母与全部股东权益、可持续经营损益的区分。",
    formula: "ROE = 归母净利润 ÷ 平均归母净资产 × 100%",
    numerator: "利润表中归属于母公司普通股股东的净利润；若用于业务分析，应明确是否剔除非经常性损益。",
    denominator: "期初与期末归母净资产的简单或加权平均值。",
    dimensions: ["报告期", "业务板块", "归母口径", "非经常性损益", "杠杆", "资本占用"],
    traps: ["用期末净资产替代平均净资产", "把少数股东损益纳入归母净利润", "忽略分红与增资的时间权重", "拿不同行业杠杆水平直接比较ROE"],
    case: "某集团ROE上升但经营利润没有同步增长，团队将杜邦关系拆成利润率、资产周转率和权益乘数，发现改善主要来自回购与分红导致权益下降。复盘中把ROE与净利润、平均权益、杠杆和资本成本放在同一页，避免只奖励资本结构变化。"
  },
  {
    match: /存贷利差/,
    definition: "存贷利差描述贷款收益与存款成本之间的静态差额；若讨论银行盈利能力，还要区分净利差和净息差。",
    formula: "简化存贷利差 = 贷款平均收益率 − 存款平均付息率",
    numerator: "生息贷款利息收入除以平均贷款余额，形成贷款收益率。",
    denominator: "计息存款利息支出除以平均计息存款余额，形成存款付息率。",
    dimensions: ["产品", "期限", "客户类型", "基准利率", "重定价日", "分支机构"],
    traps: ["把贷款收益率和净息差混为一谈", "平均余额使用不完整日数", "忽略活期与定期结构变化", "只比较利差却不看不良与资本占用"],
    case: "某银行分支机构存贷利差收窄，团队没有直接压低存款成本，而是按产品、期限和客户群拆分重定价缺口。结果显示对公活期沉淀下降和长期贷款重定价是主要因素，于是分别设置存款结构、贷款定价和客户综合贡献三个观察面。"
  },
  {
    match: /市盈率|PE/,
    definition: "市盈率把股权价值与盈利联系起来，适合理解市场为当前或预期利润支付的价格，但不能脱离盈利质量、周期位置和会计口径解释。",
    formula: "市盈率 = 每股价格 ÷ 每股收益 = 股权市值 ÷ 归母净利润",
    numerator: "指定时点的普通股股权市值或每股价格。",
    denominator: "统一期间的归母净利润、TTM利润或预测利润，必须注明使用哪一种。",
    dimensions: ["市场时点", "TTM或预测期", "归母口径", "行业", "盈利质量", "股本变化"],
    traps: ["拿静态PE和动态PE直接比较", "亏损公司仍用PE得出高低结论", "忽略送转、增发和回购", "用周期顶部利润给周期行业估值"],
    case: "某投资研究团队发现两家公司的PE差异很大，进一步检查发现一家使用TTM利润，另一家使用明年一致预期；同时其中一家刚完成大额并购。团队改用相同日期、相同利润口径和可比资本结构重算，并把盈利波动区间作为第二张图。"
  },
  {
    match: /市净率|PB/,
    definition: "市净率把市场价格与账面净资产连接起来，更适用于资产负债表重、净资产可验证的行业，但账面价值并不等于清算价值。",
    formula: "市净率 = 每股价格 ÷ 每股净资产 = 股权市值 ÷ 归母净资产",
    numerator: "普通股股权市值。",
    denominator: "扣除优先股、永续债和其他权益工具后的归母普通股净资产。",
    dimensions: ["估值日期", "归母权益", "普通股口径", "行业", "资产质量", "ROE"],
    traps: ["未扣除其他权益工具", "把历史成本和公允价值口径混用", "只看PB不看ROE与资产减值", "金融机构不检查资本质量"],
    case: "某机构比较银行股PB时发现差异与账面净资产增速不一致。复核后确认部分样本未统一扣除永续债，且拨备与不良认定口径不同。团队改为同时展示普通股PB、ROE、不良率和拨备覆盖率，避免把低PB直接解释成低估。"
  },
  {
    match: /股息率/,
    definition: "股息率衡量现金分红相对股价的回报，但过去十二个月分红、最近一次年度分红和预期分红是三个不同口径。",
    formula: "股息率 = 每股现金分红 ÷ 每股价格 × 100%",
    numerator: "指定口径下普通股现金分红总额或每股分红。",
    denominator: "与分红期间匹配的股价或指定估值日收盘价。",
    dimensions: ["分红期间", "是否特别股息", "税前税后", "估值日", "派息率", "自由现金流"],
    traps: ["把特别股息当作可持续分红", "用历史分红预测未来而不看现金流", "价格日期与分红期间不匹配", "忽略税率和汇兑"],
    case: "某高股息组合回测看似收益稳定，复核发现样本中多次一次性资产出售分红被当成经常性派息。研究团队把股息拆为经营现金流支持、资产处置支持和融资支持三类，并将派息率、自由现金流和净负债一起纳入筛选。"
  },
  {
    match: /beta|β/i,
    definition: "Beta衡量个股收益对市场收益变动的敏感度，估计结果高度依赖市场基准、时间窗口、收益频率和可比期。",
    formula: "β = Cov(资产收益率, 市场收益率) ÷ Var(市场收益率)",
    numerator: "资产收益与市场收益的协方差。",
    denominator: "市场收益的方差。",
    dimensions: ["市场基准", "收益频率", "观察窗口", "复权方式", "交易时段", "行业"],
    traps: ["用不同指数作为市场基准", "停牌和涨跌停处理不一致", "窗口过短导致噪声过大", "把历史Beta当作未来确定值"],
    case: "某量化团队发现同一股票在两个风险系统中Beta不同，追查后发现一个使用沪深300日收益，另一个使用中证全指周收益，且停牌日填充规则不同。统一基准、频率与缺失值处理后，两个系统才具备比较基础。"
  },
  {
    match: /夏普比率/,
    definition: "夏普比率用单位波动风险获得的超额收益衡量组合表现，必须与无风险利率、收益频率、年化方式和样本期一起解释。",
    formula: "夏普比率 = (组合平均收益 − 无风险收益) ÷ 组合收益标准差",
    numerator: "同一频率下的组合收益减无风险收益。",
    denominator: "同一频率的组合超额收益标准差，再按明确规则年化。",
    dimensions: ["收益频率", "无风险利率", "年化因子", "样本期", "市场状态", "费用口径"],
    traps: ["日频波动直接乘根号252却不说明假设", "扣费前后混用", "只挑表现好的窗口", "非正态收益只看标准差"],
    case: "两个基金展示的夏普比率相差明显，复核发现一个使用三年月收益并扣除费用，另一个使用一年日收益且未扣费。统一窗口和净收益口径后，差异明显缩小；团队同时增加最大回撤和下行波动，避免只用一个综合分数做决策。"
  },
  {
    match: /EBITDA/,
    definition: "EBITDA是息税折旧摊销前利润，常用于跨资本结构和会计政策比较，但它不是现金流，也不等于监管或会计净利润。",
    formula: "EBITDA = 净利润 + 所得税费用 + 利息费用 + 折旧与摊销",
    numerator: "从净利润出发按明确加回项调整。",
    denominator: "通常不需要分母；若计算EBITDA利润率，则分母为营业收入。",
    dimensions: ["报告期", "加回项", "租赁准则", "一次性项目", "汇率", "业务板块"],
    traps: ["把EBITDA直接称为经营现金流", "漏记租赁负债相关利息或折旧", "把资本化支出当作无需考虑", "随意加回重组费用"],
    case: "并购尽调中，两家标的的EBITDA利润率看似接近，但一家把经常性设备更新资本支出资本化，另一家费用化。团队统一租赁、资本化和一次性费用口径，并增加资本支出与营运资金变动，避免高EBITDA低现金流的标的被高估。"
  },
  {
    match: /资产周转率/,
    definition: "资产周转率衡量资产产生收入的效率，核心是收入与平均资产的口径一致性，以及轻资产与重资产模式的不可直接比较性。",
    formula: "资产周转率 = 营业收入 ÷ 平均总资产",
    numerator: "指定期间的营业收入，应明确含税或不含税、总额或净额。",
    denominator: "期初和期末平均总资产；需要时可按月平均。",
    dimensions: ["业务板块", "资产类型", "币种", "并购影响", "季节", "总额净额"],
    traps: ["用期末资产替代平均资产", "重大并购前后不拆同店与并购贡献", "收入确认政策变化未重述", "跨轻重资产行业直接比较"],
    case: "某零售集团资产周转率下降，团队把资产拆成门店、库存、应收和现金，并用同店与新增门店分开计算。结果显示同店资产效率稳定，下降来自新店爬坡期和库存周转变慢，管理层因此调整开店节奏和库存清理计划。"
  },
  {
    match: /毛利率/,
    definition: "毛利率反映营业收入扣除营业成本后的剩余比例，关键在于成本边界、收入总额净额、退款和运费等项目的统一。",
    formula: "毛利率 = (营业收入 − 营业成本) ÷ 营业收入 × 100%",
    numerator: "收入减成本形成的毛利。",
    denominator: "与成本同一范围、同一期间、同一税务口径的营业收入。",
    dimensions: ["产品", "渠道", "客户", "地区", "促销", "成本类型"],
    traps: ["不同渠道有的按总额有的按净额确认收入", "退款与履约成本归属不一致", "把期间费用塞进营业成本", "只报毛利率不报绝对毛利额"],
    case: "某品牌线上毛利率提高但经营利润下降，拆解发现收入净额确认范围变化，同时投流费用上升。团队把毛利桥做成价格、成本、渠道结构、退款与会计口径五项，并把投流、履约和售后列在毛利之外单独观察。"
  },
  {
    match: /偿付能力/,
    definition: "偿付能力描述机构履行到期债务或保险赔付责任的能力，需区分监管偿付能力、会计流动性和内部风险偏好。",
    formula: "不同对象口径不同：保险监管通常看实际资本与最低资本；企业偿债分析可看经营现金流、利息保障和债务期限结构",
    numerator: "按适用监管或信用分析口径确定的可用资本、现金流或流动资产。",
    denominator: "最低资本、到期债务、利息支出或短期负债。",
    dimensions: ["监管体系", "机构范围", "资本层级", "期限", "币种", "压力情景"],
    traps: ["把会计利润等同于偿付能力", "忽略期限错配和流动性折价", "压力测试情景过于乐观", "不同监管制度下直接比较数值"],
    case: "某保险集团在年度压力测试中增加退保率、利率和信用利差三个联动情景。团队不是只算一个最低资本覆盖率，而是检查资产变现、负债久期和再保安排，形成了资本补充、资产调整和业务收缩三类行动阈值。"
  },
  {
    match: /风险溢价/,
    definition: "风险溢价是投资者承担额外风险所要求的超额回报，既可用于市场估值，也可用于信用和项目资本成本。",
    formula: "风险溢价 = 风险资产预期回报 − 对应无风险利率",
    numerator: "与风险资产、期限、币种和现金流匹配的预期回报。",
    denominator: "同一期限、币种和市场状态下的无风险利率。",
    dimensions: ["资产类别", "信用等级", "期限", "市场", "币种", "流动性"],
    traps: ["股票风险溢价与信用利差混用", "期限不匹配", "把历史溢价机械外推", "忽略流动性和交易成本"],
    case: "某集团评估新业务投资门槛时，财务团队原先统一使用一个风险溢价，导致高波动、低流动性项目被低估资本成本。改造后按行业Beta、信用等级、期限和流动性分层，并要求每个项目说明溢价来源与可复核依据。"
  }
];

const MANUFACTURING_SPECS = {
  oee: {
    formula: "OEE = 时间开动率 × 性能开动率 × 良品率",
    focus: "设备综合效率必须把计划时间、停机损失、速度损失和质量损失放在同一条时间账上。",
    dimensions: ["工厂", "产线", "设备", "班次", "产品", "停机原因", "换型", "批次"],
    checks: ["计划生产时间与班次日历一致", "停机区间不重叠", "标准节拍版本按工单生效", "报废与返工均进入质量损失"],
    case: "某精密零部件工厂OEE偏低，团队先核对计划时间，发现设备日历仍包含计划保养；再合并重叠停机记录，并把试生产速度损失和质量返工分开。最后用同一工单核对损失分钟数，确认主要问题是换型等待与微小停机，而不是单一的设备故障。"
  },
  productivity: {
    formula: "生产效率 = 合格产出 ÷ 标准工时投入（也可按实际工时与标准产出双向换算）",
    focus: "生产效率不是“做得越多越快”，而是合格产出、标准工时和产品组合在同一口径下的比较。",
    dimensions: ["产品族", "工单", "班组", "设备", "良品数", "返工", "标准工时"],
    checks: ["标准工时版本有效", "返工不重复计为首次合格产出", "产品组合变化单独展示", "设备与人员工时边界一致"],
    case: "某电子组装厂产量提升但生产效率下降，拆解发现高工时产品占比上升，且返工数量被计入合格产出。团队改用工单级标准工时和首次合格数，补充产品组合指数后，才看清效率变化的真实来源。"
  },
  capacity: {
    formula: "产能利用率 = 实际有效产出 ÷ 可用产能 × 100%",
    focus: "产能利用率要区分理论产能、有效产能和需求可销售量，避免把库存积压误当成有效产出。",
    dimensions: ["产线", "工序", "产品", "班次", "瓶颈设备", "需求计划", "库存"],
    checks: ["产能版本与产品组合匹配", "瓶颈工序不按全厂平均产能计算", "库存增加与可销售量分离", "停机与换型纳入可用产能"],
    case: "某新能源材料工厂产能利用率接近饱和，但订单准时交付仍下降。分析团队按瓶颈工序重算有效产能，并把产品切换损失和待检库存纳入模型，发现真正受限的是检测工序而非主生产线。"
  },
  cycle: {
    formula: "生产周期 = 订单完成时间 − 订单释放时间（可按工单、批次或工序分别计算）",
    focus: "生产周期要明确起止事件，并区分排队、加工、等待、检验、返工和放行时间。",
    dimensions: ["订单类型", "工序", "产品", "批量", "优先级", "等待原因", "返工"],
    checks: ["释放和完成事件定义统一", "跨班跨日时间完整", "暂停与返工分段记录", "工作日历和自然日分开"],
    case: "某装备企业交期变长，团队把生产周期拆成等待排产、缺料、加工、检验和返工五段。总加工时间变化不大，主要增长发生在检验排队，进一步追溯发现某关键部件的新版检验规范增加了复核环节。"
  },
  bottleneck: {
    formula: "瓶颈工序识别 = 最大持续负荷工序；常用负荷率、排队时长、产出增量和约束利用率交叉验证",
    focus: "瓶颈不是一个永远不变的工序，它会随产品组合、班次、设备状态和需求结构迁移。",
    dimensions: ["工序", "设备组", "产品组合", "班次", "排队", "利用率", "换型"],
    checks: ["按工艺路线而非部门归集负荷", "替代设备和外协能力纳入", "产品组合变化重算", "瓶颈移动有历史证据"],
    case: "某汽车零部件厂一直把焊接当作瓶颈，但近月交付问题集中在涂装前等待。按产品组合重算后，涂装换型时间快速增长，焊接到涂装的节拍差扩大。团队据此限制小批量频繁插单，并设置换型窗口。"
  },
  otd: {
    formula: "准时交付率 = 按承诺时间和数量完整交付的订单数 ÷ 应交付订单数 × 100%",
    focus: "准时交付率要同时检查时间、数量和客户确认，不能用发货时间替代客户签收时间而不说明。",
    dimensions: ["客户", "承诺日期", "实际交付", "缺量", "取消", "发运方式", "工厂"],
    checks: ["承诺日期版本保留", "部分交付不直接算完整", "客户变更与内部延期分开", "发运和签收口径明确"],
    case: "某食品集团准时交付率突然改善，复核发现部分订单在延期后重新生成承诺日期。数据团队保留首次承诺、变更后承诺和客户确认三个时间点，并区分完整交付与部分交付，恢复可比口径后再分析真实改善。"
  },
  wip: {
    formula: "在制品库存 = 已投产但尚未完工入库的物料数量或成本；周转天数需除以对应期间日均产出或消耗",
    focus: "在制品既看数量也要看位置、状态和停留时长，不能只用月末余额判断流动性。",
    dimensions: ["工序", "批次", "状态", "停留时长", "产品", "数量", "成本"],
    checks: ["投产与入库事件闭环", "报废和返工状态保留", "盘点差异单独记录", "数量与成本口径不混用"],
    case: "某电池片工厂在制品余额不高，但交付波动明显。团队用批次位置和停留时长重建流转，发现大量物料停在待检状态，平均等待时间远高于加工时间。随后把检验队列和在制品账龄纳入每日运营会。"
  },
  takt: {
    formula: "生产节拍 = 可用生产时间 ÷ 客户需求量；与工位实际周期时间分开比较",
    focus: "生产节拍是需求约束，不是设备越快越好；分析要比较节拍、各工位周期时间和波动。",
    dimensions: ["产品", "客户需求", "班次", "工位", "周期时间", "换型", "停机"],
    checks: ["需求窗口一致", "可用时间扣除计划停机", "周期时间采用稳定状态", "产品组合变化重算节拍"],
    case: "某家电工厂要求全线提速，但客户需求在两周内波动很大。团队先按时段计算需求节拍，再比较各工位周期时间，发现部分瓶颈只在大批量产品出现。最终用柔性排班替代持续超速，减少库存与疲劳风险。"
  }
};

const SPARK_TOPICS = [
  [/MLlib/i, {
    thesis: "Spark MLlib的重点不是会调用几个算法，而是把特征、标签、切分、Pipeline、评估和模型持久化放在可复现实验链路中。",
    mechanism: "典型链路是数据清洗 → 标签定义 → VectorAssembler → StringIndexer/OneHotEncoder → 训练验证切分 → Estimator拟合 → Evaluator评估 → PipelineModel保存。",
    pitfalls: ["先对全量数据做标准化再切分，造成验证集信息泄漏", "离线特征与在线特征定义不一致", "只看AUC，不看业务阈值下的召回、误报和样本分布", "StringIndexer在新数据中遇到未见类别没有处理策略"],
    checks: ["训练、验证和测试按时间或实体隔离", "标签生成时间和特征可得时间满足因果顺序", "Pipeline 包含训练阶段变换", "模型版本绑定数据版本、参数和评估切片"],
    code: `from pyspark.ml import Pipeline
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.feature import StringIndexer, VectorAssembler

train, valid = orders.randomSplit([0.8, 0.2], seed=42)
indexer = StringIndexer(
    inputCol="channel", outputCol="channel_idx", handleInvalid="keep"
)
assembler = VectorAssembler(
    inputCols=["channel_idx", "order_cnt_30d", "avg_amount_30d"],
    outputCol="features",
    handleInvalid="keep",
)
classifier = LogisticRegression(
    featuresCol="features", labelCol="is_repeat_buyer", maxIter=50
)
pipeline = Pipeline(stages=[indexer, assembler, classifier])
model = pipeline.fit(train)
scored = model.transform(valid)

evaluator = BinaryClassificationEvaluator(
    labelCol="is_repeat_buyer", rawPredictionCol="rawPrediction",
    metricName="areaUnderROC",
)
print({"valid_auc": evaluator.evaluate(scored)})
model.write().overwrite().save("models/repeat_buyer_pipeline_v3")`
  }],
  [/Shuffle|数据倾斜|数据不倾斜/i, {
    thesis: "Shuffle问题要同时观察数据分布、分区策略、聚合方式和资源等待；只把 Executor 内存调大，往往只是把失败推迟。",
    mechanism: "Shuffle Write 按分区落盘，下游 Task 拉取相同 Key 的数据。少数热点 Key 会把单个 Reduce Task 拉长；空分区过多又会浪费调度和读放大。",
    pitfalls: ["只看任务总时长，不看 Task 时长分位数", "把 null 或默认值当成正常热点 Key", "扩容后热点仍集中到少数分区", "为了减小文件调大分区数却没有观察小文件"],
    checks: ["按业务键看 Top 占比和分位数", "比较 Shuffle Read/Write、Spill 和 GC", "验证加盐或两阶段聚合前后结果守恒", "记录并行度、文件数和资源成本"],
    code: `from pyspark.sql import functions as F

key_profile = (
    fact.groupBy("merchant_id")
    .agg(F.count("*").alias("row_cnt"), F.sum("amount").alias("amount"))
)
key_profile.orderBy(F.desc("row_cnt")).show(20)

total = key_profile.agg(F.sum("row_cnt").alias("total")).first()["total"]
top_share = key_profile.orderBy(F.desc("row_cnt")).limit(20) \\
    .agg(F.sum("row_cnt").alias("top_rows")).first()["top_rows"] / total
print({"top20_key_share": top_share})`
  }],
  [/RDD|宽依赖|窄依赖|算子|map|flatMap|lazy/i, {
    thesis: "RDD的核心是可分区、不可变、可重算的分布式数据抽象；Transform 延迟执行，Action 才触发作业。",
    mechanism: "窄依赖允许父分区到子分区局部转换，宽依赖需要 Shuffle。血缘能支持容错，但过长血缘会让失败重算成本不可控。",
    pitfalls: ["把 map 与 flatMap 的输入输出数量混为一谈", "在循环中多次触发 Action", "无节制缓存导致内存压力", "长血缘不 checkpoint"],
    checks: ["明确每一步的 Key 和分区变化", "区分 Transform 与 Action", "检查缓存是否真正被复用", "长迭代任务保存中间可信状态"],
    code: `from pyspark import StorageLevel

events = sc.textFile("s3://bucket/events/2026-11-01")
parsed = events.map(lambda line: line.split("\\t")) \\
    .filter(lambda cols: len(cols) == 4) \\
    .map(lambda cols: (cols[1], float(cols[3])))

daily_amount = parsed.reduceByKey(lambda left, right: left + right)
daily_amount.persist(StorageLevel.MEMORY_AND_DISK)
print(daily_amount.take(5))
daily_amount.unpersist()`
  }],
  [/Stage|DAGScheduler|TaskScheduler|任务调度/i, {
    thesis: "Stage 边界由宽依赖决定，DAGScheduler 负责按 Shuffle 边界切分并提交 TaskSet，TaskScheduler 再把任务分配到 Executor。",
    mechanism: "一个 Job 从 Action 触发，回溯 RDD 血缘；遇到 Shuffle 依赖形成新 Stage。上游 Stage 先产出 Shuffle 数据，下游再拉取计算。",
    pitfalls: ["把 Job、Stage、Task 三个层次混淆", "只看 Driver 日志不看 Spark UI", "失败重试与推测执行成本未区分", "本地模式结论直接套到集群"],
    checks: ["从 Action 反推 Job 和 Stage", "定位首个长尾 Stage", "比较任务等待、执行和 Shuffle 时间", "记录推测执行是否造成重复写"],
    code: null
  }],
  [/内存|cache|persist|checkpoint|Block/i, {
    thesis: "Spark 内存管理首先要区分执行内存、存储内存和用户对象开销；缓存不是越多越好，而要证明同一数据集被多次复用。",
    mechanism: "Executor 内执行与存储共享内存池，Block 管理与序列化方式会影响有效容量。缓存淘汰不等于数据永不重算，checkpoint 则通过截断血缘换取恢复点。",
    pitfalls: ["缓存后只使用一次", "忽略序列化开销", "把磁盘缓存当免费扩容", "checkpoint 目录与清理策略缺失"],
    checks: ["统计复用次数和命中", "比较缓存前后 Stage 时间", "监控 Spill、GC 和磁盘 IO", "为 checkpoint 设置生命周期和权限"],
    code: `from pyspark import StorageLevel

feature_frame = build_features().persist(StorageLevel.MEMORY_AND_DISK)
train_count = feature_frame.filter("sample_role = 'train'").count()
valid_count = feature_frame.filter("sample_role = 'valid'").count()
print({"train": train_count, "valid": valid_count})
feature_frame.unpersist()`
  }],
  [/参数|并行度|资源|Executor|Driver|YARN|Standalone|部署模式|Cluster/i, {
    thesis: "资源参数应该由数据量、分区数、单任务成本和 SLO 推导，不能从网上复制一组“万能参数”。",
    mechanism: "Driver 负责调度和应用生命周期，Executor 提供并行计算槽位。并行度决定可同时运行的任务数，但也会影响调度、Shuffle 和小文件成本。",
    pitfalls: ["Executor 数量与每节点内存简单相乘", "Driver 与 Executor 内存边界不清", "并行度远大于有效分区", "只在失败后加资源，不做基线"],
    checks: ["先测单分区数据量和 Task 时长", "观察 CPU、内存、IO 与等待", "区分固定资源与弹性资源", "上线保留最小和最大资源边界"],
    code: null
  }],
  [/SQL|DataFrame|GroupBy|文件|UDF|窗口|二次排序/i, {
    thesis: "Spark SQL 的性能来自 Catalyst 优化、数据布局和运行时执行，不应把 DataFrame API 等同于自动高性能。",
    mechanism: "逻辑计划经过分析和优化形成物理计划；Join 策略、分区裁剪、聚合模式和文件布局共同决定扫描、Shuffle 与输出成本。",
    pitfalls: ["UDF 阻断部分内置优化", "Join 键类型不一致导致隐式转换", "小文件过多拖慢规划与扫描", "只读 explain 文本不看运行指标"],
    checks: ["先看执行计划和分区裁剪", "确认 Join 策略与广播边界", "检查输出文件数量和大小分布", "用相同数据版本比较改造前后"],
    code: `spark.read.parquet("s3://lake/orders/dt=2026-11-01") \\
    .where("order_status = 'PAID'") \\
    .groupBy("province", "category") \\
    .agg({"net_amount": "sum", "order_id": "count_distinct"}) \\
    .explain("formatted")`
  }]
];

const RAG_FOCUS = [
  [/知识库治理|知识库/, "知识库治理的重点不是把文件全部塞进向量库，而是建立文档所有权、版本、生效日期、权限、冲突处理和失效下线机制。"],
  [/Embedding|向量/, "Embedding 质量要同时看语义区分度、领域适配、维度成本、更新策略和跨语言表现；相似度分数本身不是业务正确率。"],
  [/语义搜索|召回|重排|混合检索/, "检索链路应把关键词、向量、过滤和重排分开评测。召回阶段追求覆盖，重排阶段负责校准相关性，最终还要检查引用是否支持答案。"],
  [/向量索引|生命周期/, "向量索引会随文档更新、删除和模型升级持续漂移，索引版本、增量构建、重建窗口和回滚路径必须纳入设计。"],
  [/评估|质量/, "RAG 评估不能只看一个“看起来不错”的回答，而要分层评估解析、召回、重排、引用、拒答和业务任务完成度。"],
  [/RAG|检索增强/, "RAG 的可靠性来自“检索到的证据 + 可追溯引用 + 不知道时拒答”，而不是让模型把所有问题都回答得像真的。"]
];

const RAG_SCENARIOS = [
  {
    key: "agentic-architecture",
    match: /Agentic.?RAG.*架构/i,
    label: "Agentic RAG 架构",
    thesis: "Agentic RAG 的核心不是让模型多循环几次，而是把问题分解、检索动作、证据判断、停止条件和引用核验设计成可观察的状态机。",
    question: "哪些问题需要多步检索，哪些一次检索就应结束，哪些情况下必须停止并转人工",
    caseTitle: "一项跨部门政策比较任务为何连续检索了 11 轮",
    caseStory: "最初版本让模型自由决定是否继续检索，结果它不断改写问题，却始终没有检查证据是否覆盖时间、组织和版本三个条件。改造后把流程拆成“识别缺口、选择检索器、校验证据、决定停止”四个状态，每一轮都要记录新增证据与未解决项。",
    failure: "把检索次数当成推理深度，缺少证据覆盖判断和最大预算",
    artifact: "状态轨迹、每轮查询、新增证据、停止原因和引用支持记录",
    controls: ["问题分解与检索器选择", "多路召回与去重", "证据充分性判断", "重排后引用核验", "预算耗尽时拒答"],
    metrics: ["证据覆盖率", "轮次成本", "引用支持率", "无答案拒答率"],
    exercise: "为同一问题分别构造单步检索、并行多路检索和迭代检索三条路径，比较新增证据与成本"
  },
  {
    key: "agentic-engineering",
    match: /Agentic.?RAG.*工程/i,
    label: "Agentic RAG 工程",
    thesis: "Agentic RAG 工程化的难点在工具契约、运行预算、失败恢复和可观测性；只把检索包装成一个工具，并没有形成可运营的系统。",
    question: "检索工具允许访问什么、失败后如何重试、什么时候熔断、如何复盘一次错误结论",
    caseTitle: "工具调用成功，答案却引用了错误部门制度",
    caseStory: "一次灰度中所有工具调用都返回成功，但答案引用了已失效制度。排查发现工具层只校验接口状态，没有把文档生效时间、用户组织和引用片段带入上下文；重试又把旧结果混入候选。团队随后为工具增加参数约束、结果签名和运行轨迹，并让引用核验失败直接阻断回答。",
    failure: "工具调用成功率掩盖了证据时效与权限问题",
    artifact: "工具入参、返回签名、耗时、重试、预算、引用片段和人工接管记录",
    controls: ["工具白名单与参数校验", "检索超时与熔断", "候选去重与版本过滤", "重排结果签名", "失败回退到拒答或人工"],
    metrics: ["端到端成功率", "重试放大率", "P95 延迟", "单位任务成本"],
    exercise: "注入超时、空结果、重复结果、越权结果和相互冲突结果，检查 Agent 是否能安全结束"
  },
  {
    key: "governance",
    match: /RAG.*治理|知识库治理|知识库.*手册/,
    label: "RAG 知识库治理",
    thesis: "RAG 知识库治理要回答文档谁负责、何时生效、哪些角色可见、冲突如何裁决、下线如何传播；这些问题不清，检索越强，错误传播得越快。",
    question: "一份新文档上线、旧文档作废或权限变化后，Embedding、索引和引用如何同步",
    caseTitle: "新旧制度同时被召回，模型给出了一份不存在的折中规则",
    caseStory: "知识库同时保留两个版本的报销制度，旧版已被标记作废但未从索引删除。模型把两版条款混合后生成了一个看似合理的结论。治理改造把文档版本、生效区间、替代关系和责任部门写入元数据，索引只召回当前有效版本，冲突问题必须展示来源并转人工确认。",
    failure: "只治理原始文档，没有治理索引中的版本和删除传播",
    artifact: "文档 Owner、有效期、替代关系、ACL、索引版本、删除事件和审计日志",
    controls: ["文档所有权与审批", "版本及失效传播", "租户和组织权限过滤", "冲突识别与裁决", "索引重建与回滚"],
    metrics: ["有效版本召回率", "失效文档残留率", "越权候选数", "冲突转人工率"],
    exercise: "抽取一批已下线文档，验证它们在召回、重排、引用和缓存各层都不再出现"
  },
  {
    key: "project",
    match: /RAG.*项目|知识库.*项目/,
    label: "RAG 项目交付",
    thesis: "RAG 项目以业务任务完成、引用可核验和风险可控为验收，不以“已经接入大模型”或演示问答流畅为完成。",
    question: "首期服务哪些任务、哪些问题必须拒答、哪些高风险结果必须进入人工流程",
    caseTitle: "试点演示效果很好，上线后却没人敢用",
    caseStory: "项目组用整理过的 50 个问题做演示，答案引用完整。进入真实部门后，用户问题包含旧制度、跨组织权限和模糊时间，系统无法说明版本，也没有人工接管入口。二期把验收拆成业务任务、检索、引用、拒答和安全五组指标，并把无答案与冲突场景列入首批上线门禁。",
    failure: "验收集只覆盖顺利路径，没有覆盖真实高风险问题",
    artifact: "任务清单、评测集版本、灰度用户、人工接管、采用记录和回滚演练",
    controls: ["业务任务与非目标", "固定评测集", "灰度和用户培训", "人工接管流程", "上线门禁与回滚"],
    metrics: ["任务完成率", "引用支持率", "错误拒答率", "高风险场景人工接管率"],
    exercise: "把试点问题分为正常、冲突、过期、越权、无答案和长文档六类，重新计算上线结论"
  },
  {
    key: "embedding",
    match: /Embedding|嵌入|向量模型/i,
    label: "Embedding 质量管理",
    thesis: "Embedding 质量要由真实查询与文档的相关性标注证明，不能只看模型榜单、向量维度或几条相似度示例。",
    question: "同义、否定、缩写、型号、跨语言和长段落分别在当前 Embedding 下表现如何",
    caseTitle: "相似度很漂亮，业务正例却排不进前三",
    caseStory: "团队用通用中文语料对比两个 Embedding，平均相似度更高的模型在内部产品型号检索上却频繁混淆。复盘发现型号中的数字和后缀没有被保持区分，评测又只抽样了同义句。改造后建立查询-文档相关性集，并按实体、否定、缩写和跨语言切片比较 Recall@K。",
    failure: "用无标注相似度替代检索相关性，忽略领域实体区分",
    artifact: "查询-文档对、相关性等级、相似度分布、切片指标和模型版本",
    controls: ["领域词与实体样本", "正负例构造", "向量归一化", "维度与成本评估", "模型升级回归"],
    metrics: ["Recall@K", "MRR", "负例区分度", "跨语言召回差"],
    exercise: "构造 20 组只差一个型号、否定词或时间条件的难负例，检查召回是否稳定"
  },
  {
    key: "semantic-search",
    match: /语义搜索/,
    label: "向量数据库与语义搜索",
    thesis: "语义搜索不是只把文本变成向量，而是查询理解、候选召回、重排、过滤和结果解释共同构成的搜索产品。",
    question: "用户输入的口语、品牌词、规格、否定条件和权限范围如何进入同一条检索链",
    caseTitle: "搜索“适合高温环境的型号”，结果全是高温关键词但没有合规认证",
    caseStory: "纯向量召回找到了语义相近的描述，却没有强制应用认证、地区和库存过滤。团队把结构化条件前置为过滤，用关键词与向量并行召回，再以重排模型校准相关性；结果页同时显示命中原因，便于运营发现错误。",
    failure: "把语义相似当成业务可售，忽略硬性过滤条件",
    artifact: "查询意图、过滤字段、各路候选、重排分数和点击/转化反馈",
    controls: ["查询改写与实体识别", "关键词和向量混合召回", "结构化过滤", "重排与多样性", "结果解释与反馈"],
    metrics: ["Recall@K", "NDCG", "零结果率", "搜索后转化率"],
    exercise: "选 50 条真实搜索词，分别记录纯关键词、纯向量和混合检索的首屏命中情况"
  },
  {
    key: "vector-engineering",
    match: /向量数据库.*工程|RAG工程实践|混合检索/,
    label: "向量检索工程",
    thesis: "向量检索工程要同时优化召回质量、索引延迟、更新成本、过滤能力和故障回退，单一 QPS 压测不能代表生产可用。",
    question: "索引选型、分片、副本、过滤、更新和重排预算如何共同影响成本与体验",
    caseTitle: "扩容后 QPS 达标，带权限过滤的真实查询仍然超时",
    caseStory: "压测使用无过滤的随机向量，生产查询却同时带租户、地区和时间条件。扩容只提高了无过滤吞吐，没有解决高选择性过滤后的候选不足。团队改为先缩小租户分区，再执行向量召回，并单独压测过滤后 TopK、重排和缓存命中。",
    failure: "用无过滤基准替代真实查询分布，忽略候选选择性和长尾延迟",
    artifact: "查询分布、过滤选择性、索引参数、TopK、重排耗时和缓存命中",
    controls: ["索引与分片选型", "过滤后召回", "增量更新", "重排预算", "降级与回退"],
    metrics: ["过滤后 Recall@K", "P95 查询延迟", "索引更新延迟", "每次查询成本"],
    exercise: "按无过滤、低选择性、高选择性和高并发四组负载分别压测，记录尾延迟与召回变化"
  },
  {
    key: "lifecycle",
    match: /索引治理|索引生命周期|向量数据生命周期|向量索引/i,
    label: "向量索引与数据生命周期",
    thesis: "向量数据会经历上线、更新、重建、下线、删除和模型迁移，索引版本与数据版本必须能相互追溯，才能避免幽灵内容。",
    question: "文档更新后旧向量何时失效，删除请求如何传播，Embedding 模型升级如何双写和回滚",
    caseTitle: "文档已删除三个月，问答仍在引用旧内容",
    caseStory: "源文档系统完成了删除，但向量索引只做新增，没有消费删除事件；缓存又保留旧检索结果。团队建立文档版本到向量主键的映射，引入墓碑标记、异步删除核对、索引别名切换和缓存失效，并在验收中专门检查“已删除内容零召回”。",
    failure: "数据生命周期只覆盖源文件，不覆盖向量、缓存和引用快照",
    artifact: "文档版本、向量主键、索引别名、删除事件、缓存键和回滚点",
    controls: ["增量与全量构建", "删除传播", "索引别名切换", "模型双写迁移", "保留期与审计"],
    metrics: ["删除传播时延", "孤儿向量数", "索引回滚时长", "版本一致率"],
    exercise: "模拟更新、删除、撤权和模型升级四类事件，逐层检查召回、重排、缓存和引用"
  },
  {
    key: "rag-basics",
    match: /RAG|检索增强/,
    label: "RAG 检索增强生成",
    thesis: "标准 RAG 的目标不是让模型无所不知，而是让每个回答建立在可定位、可过滤、可评测的证据上，并在证据不足时明确拒答。",
    question: "文档怎样解析与切分，候选怎样召回和重排，答案怎样引用，什么情况下拒绝回答",
    caseTitle: "答案看起来完整，却找不到一句真正支持结论的原文",
    caseStory: "团队最初只检查回答是否流畅，没有核对引用是否支持结论。抽样后发现引用链接存在，但对应片段只包含相关术语，不能证明答案。改造后把解析、召回、重排、引用和拒答分开评测，引用必须定位到章节或页码，并由人工对高风险答案做抽检。",
    failure: "把链接存在当成引用支持，把回答流畅当成任务完成",
    artifact: "原始文档、Chunk、TopK 候选、重排分数、引用片段和拒答记录",
    controls: ["结构化解析与切分", "混合召回", "重排与去重", "逐句引用", "无答案拒答"],
    metrics: ["Hit@K", "引用支持率", "忠实度", "拒答准确率"],
    exercise: "从真实问题中挑出无答案、版本冲突和长表格三类问题，检查系统是否能明确说明限制"
  }
];

const AGENT_FOCUS = [
  [/安全|沙箱|权限|审计|责任/, "Agent 的权限必须通过工具白名单、参数校验、最小授权、沙箱和高风险动作审批来约束；模型输出不能直接成为执行授权。"],
  [/可观测|评估/, "Agent 可观测性至少记录目标、计划、工具调用、参数、结果、耗时、成本、失败重试和人工接管，而不只是最终回答文本。"],
  [/多Agent|协作/, "多 Agent 不是角色越多越好。只有当任务能按证据、权限或阶段清楚分工，并且冲突可以减少时，协作架构才有价值。"],
  [/控制平面|企业级/, "企业级 Agent 控制平面负责身份、工具注册、策略、预算、审计、灰度、回滚和人工审批，是运行时治理层，而不是一个大提示词。"],
  [/RAG|检索/, "Agentic RAG 把检索变成可迭代动作，但每轮查询都需要预算、停止条件、来源核验和引用追踪。"],
  [/Agent|智能体/, "Agent 的价值在于根据观察选择下一步动作，但必须设置最大步数、工具边界、失败恢复和可结束条件。"]
];

const DATA_SERVICE_FOCUS = [
  [/部署/, "数据服务部署要把镜像、配置、数据库迁移、密钥、健康检查、灰度、回滚和容量边界一起管理，不能只把应用进程启动起来。"],
  [/网关/, "数据服务网关集中处理路由、鉴权、限流、熔断、审计和版本分流，但业务权限不能只依赖网关。"],
  [/GraphQL/, "GraphQL 数据服务要控制查询深度、复杂度、字段权限和 N+1 查询，避免客户端任意组合拖垮底层数据源。"],
  [/RESTful|REST/, "REST 数据服务的稳定性取决于资源语义、版本、错误码、幂等、分页和缓存约定，而不是只看 URL 是否好看。"],
  [/编排/, "服务编排要区分同步调用、异步任务和补偿事务；每一步都要有超时、重试、幂等和失败可见性。"],
  [/监控/, "数据服务监控应覆盖请求成功率、尾延迟、超时、限流、缓存命中、数据新鲜度和业务口径异常。"],
  [/API|接口/, "数据 API 的契约要写清资源、字段、粒度、权限、分页、错误和版本；接口能返回数据不等于可以安全被业务使用。"],
  [/实时/, "实时数据服务要同时保证事件新鲜度、结果一致性和降级能力；延迟目标必须按分位数定义。"],
  [/数据服务|服务/, "数据服务把表结构变化、查询成本和权限风险暴露给更多调用方，因此契约、SLO、审计和回滚比一次性查询更重要。"]
];

function hashNumber(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function pick(items, seed, offset = 0) {
  return items[(seed + offset) % items.length];
}

function esc(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

function table(headers, rows) {
  return [
    `| ${headers.map(esc).join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${row.map(esc).join(" | ")} |`)
  ].join("\n");
}

function list(items, ordered = false) {
  return items.map((item, index) => `${ordered ? `${index + 1}.` : "-"} ${item}`).join("\n");
}

function fence(language, code) {
  return `\`\`\`${language}\n${String(code).trim()}\n\`\`\``;
}

function caseRegion(profile) {
  const contextKey = profile.context?.key || "general";
  const pool = REGION_CASES[contextKey] || REGION_CASES.general;
  return pick(pool, profile.seed);
}

function sourceBlock(profile, group, extra = []) {
  const sources = [
    ...extra,
    ...(SOURCE_GROUPS[group] || SOURCE_GROUPS.general)
  ].filter((item, index, all) => (
    all.findIndex((candidate) => candidate[1] === item[1]) === index
  )).slice(0, 4);
  return [
    `## “${profile.topic}”的核对资料`,
    "",
    ...sources.map(([name, url]) => `- [${name}](${url})`),
    "",
    `核对“${profile.topic}”时，优先使用与其直接相关的现行文档，并记录版本、生效日期、适用范围和限制。文中的组织与数字仅作脱敏情境示例。`
  ].join("\n");
}

function sectionTitle(profile, variant) {
  const sets = [
    ["问题边界", "判断链路", "工作现场", "可执行方案", "验收证据"],
    ["先定义对象", "再拆指标", "案例复盘", "实现细节", "上线检查"],
    ["核心结论", "机制解释", "常见误区", "实践路径", "复盘清单"],
    ["从决策倒推", "数据与证据", "场景演练", "落地动作", "完成标准"]
  ];
  return pick(sets, profile.seed, variant);
}

function enterpriseModelingArticle(profile) {
  const topic = profile.topic;
  return `# ${profile.title}

> [!abstract] 企业级建模的对象不是“表越多越完整”
> ${topic}要解决的是跨业务域、跨系统、跨时间仍能保持一致语义的问题。概念模型负责统一业务语言，逻辑模型负责稳定实体关系，物理模型负责落地性能和存储约束；三者混在一起，就会得到一张看似万能、实际无法治理的大宽表。

## 1. 先把模型分成三层，而不是直接建表

${table(
    ["建模层", "回答的问题", "主要产物", "评审责任人", "不能替代什么"],
    [
      ["概念模型", "企业有哪些核心业务对象，它们如何关联", "业务对象、关系、定义边界", "业务负责人与数据架构师", "字段类型和索引设计"],
      ["逻辑模型", "对象以什么粒度记录，键和关系如何稳定表达", "实体、关系、事实粒度、维度、业务规则", "业务分析师与模型师", "具体数据库的物理优化"],
      ["物理模型", "数据如何分区、存储、更新和访问", "表、分区、索引、文件格式、生命周期", "数据开发与平台工程", "业务定义是否正确"]
    ]
  )}

概念模型用业务语言回答“客户、账户、订单、产品、设备分别是什么”，不急着决定字段类型。逻辑模型把“客户与账户是一对多”“订单行是金额事实的最小粒度”等规则写清。物理模型才决定按哪一列分区、是否冗余维度、采用增量合并还是快照。

## 2. 业务域和一致性维度先于事实表

企业模型常常从“客户域、产品域、订单域、履约域、财务域”开始，但业务域不是部门名单。判断一个域是否成立，要看它是否拥有稳定对象、明确生命周期、责任人和跨流程共享的语义。

一致性维度是跨事实复用的公共语言。例如：

${table(
    ["一致性维度", "为什么需要统一", "常见冲突", "企业级处理方式"],
    [
      ["客户", "零售、服务、财务都按客户分析，但同一自然人、企业或会员可能多套编号", "手机号变更、集团母子关系、匿名身份", "建立主体映射、有效期和合并拆分审计"],
      ["产品", "销售、库存、财务对同一商品的理解不同", "SKU、SPU、物料号、会计科目多套编码", "保留业务粒度并建立跨编码映射，不强行压成一个字段"],
      ["组织", "跨期比较必须使用当时组织或统一映射", "部门合并、门店关闭、历史回溯改口径", "使用缓慢变化维度，保留生效区间"],
      ["时间", "不同系统有发生、入账、审核和更新时间", "时区、自然日、财务期间混用", "每个事实明确业务时间和入仓时间，不共享一个模糊更新时间"],
      ["币种与单位", "集团汇总需要统一计量", "汇率日期、数量单位、能耗单位不同", "保存原币原单位，同时记录换算规则和汇率版本"]
    ]
  )}

一致性维度并不意味着全公司只能有一张维表。更现实的做法是统一业务定义、主键和有效期，再按访问频率拆分物理维表。关键是任何派生维都能回到同一个语义源。

## 3. 事实粒度用一句话写死

事实表的每一行必须能用一句话描述。下面四种粒度的业务含义完全不同：

${table(
    ["候选事实", "一行代表什么", "可加性", "适合回答", "不能直接回答"],
    [
      ["订单事实", "一个订单的支付结果", "支付金额可加，优惠需防重复", "订单数、客单价、支付转化", "商品行级毛利"],
      ["订单行事实", "一个订单中的一个商品行", "数量与分摊金额可加", "商品、品类、SKU分析", "订单级履约成本"],
      ["事件事实", "用户或设备发生的一次动作", "通常只可计数", "漏斗、路径、时延分析", "日末余额"],
      ["周期快照", "一个账户或设备在一个时点的状态", "不能跨时点相加", "余额、库存、设备状态", "期间发生额"]
    ]
  )}

“企业级”不是把所有粒度塞在一张表，而是让每个粒度有稳定主键、明确增量规则和可追溯来源。当业务需要跨粒度分析时，通过一致性维度和桥接表连接，而不是复制后各算一套。

## 4. 星型模型、雪花模型和宽表各有边界

星型模型把事实和公共维度分开，便于复用和治理；雪花模型把维度继续规范化，适合层级复杂、变化频繁的组织或产品；宽表把常用维度预先连接，查询方便，但更新成本和一致性风险更高。

${table(
    ["方案", "优势", "代价", "适合场景"],
    [
      ["星型模型", "语义清晰、复用高、易做一致性维度", "查询需要 Join，模型设计门槛更高", "跨业务域共享的核心事实"],
      ["雪花模型", "复杂层级和变化规则更容易维护", "Join 层数多，使用门槛较高", "组织、产品、科目等复杂维度"],
      ["宽表", "查询简单、性能可控", "冗余大、更新复杂、容易口径漂移", "固定分析场景与稳定指标服务"],
      ["Data Vault 风格", "历史可审计、扩展灵活", "结构复杂，需要较强工程治理", "多源、变化频繁、审计要求高的企业数据底座"]
    ]
  )}

选择标准不是“哪个更先进”，而是使用频率、变更频率、数据量、查询延迟和治理成本。宽表可以作为服务层，但不应成为唯一事实来源。

## 5. 案例：从“客户经营模型”拆到可落地粒度

某跨区域零售与服务集团的 ${caseRegion(profile)} 需要回答“哪些客户持续贡献价值、哪些门店和渠道在流失”。最初的方案是把会员、订单、优惠券、门店、线上行为和客服工单拼成一张客户宽表。结果是：

- 客户最新等级覆盖历史等级，过去月份随今天的会员规则变化；
- 订单日快照与交易流水相加，导致金额重复；
- 匿名浏览、登录会员与家庭成员共用账号无法解释；
- 活动归因窗口变化后，同一订单同时归给多个渠道。

重做模型时，团队先确定四个粒度：客户主体、身份映射、交易事件、日末会员状态。身份映射保留来源、置信度、生效区间和拆分记录；交易事件只记录一次真实发生；日末快照只描述当日状态，不参与金额求和；渠道归因作为独立桥接关系，允许版本切换。

最终形成的是“客户主体与身份维度 + 交易事实 + 会员周期快照 + 渠道归因关系”的组合，而不是一张无限扩展的表。这个例子说明企业级模型的核心是隔离不同语义，再用稳定维度连接。

## 6. 缓慢变化维度必须写清历史

Type 1 覆盖适用于纠错或不需要历史的属性；Type 2 通过有效期保留历史变化；若只保存最新部门、最新产品分类，过去月份就可能在重跑后改变。企业模型至少要明确：

1. 哪个字段的变化需要保留历史，哪个只是数据纠错。
2. 同一业务日出现多次变化时，以事件时间、审核时间还是入仓时间为准。
3. 关店、合并、撤销和重新启用如何表达，是否允许一条记录对应多个前任实体。
4. 维度变化是否触发事实重算，哪些下游报表需要版本说明。
5. 变更审批、影响分析和回滚由谁负责。

## 7. 模型评审要拿业务问题当测试用例

评审不是逐字段说“看起来可以”，而是准备一组能够击穿模型的业务问题：

| 评审问题 | 期望证据 | 不通过时的信号 |
| --- | --- | --- |
| 同一客户换手机号后，历史消费能否连续观察 | 身份映射表与有效期 | 只剩新账号，历史断裂 |
| 门店关闭后，历史营业额是否仍归原门店 | SCD2门店维度与事实时间关联 | 历史被改到当前组织 |
| 跨月退款是否冲减原交易所在期间 | 退款事件与原订单桥接 | 只冲减退款月，利润被扭曲 |
| 一个商品更换品类后，去年同期如何比较 | 品类历史与报表口径声明 | 重跑结果随当前维度变化 |
| 采购单位和财务金额能否相互对账 | 数量、单价、币种和汇率版本 | 只保留一个“最终金额” |

模型通过的标准不是“SQL能跑”，而是业务、数据、财务、安全和下游消费者能够共同解释边界。

## 8. 版本影响分析是企业级模型的生命线

任何影响粒度、主键、状态或维度有效期的变更都不能按普通字段发布处理。至少需要：

- 识别上游源字段、下游表、指标、API、报表和模型特征；
- 使用历史样本比较旧模型和新模型，量化重复、缺失、金额和对象数量差异；
- 准备影子表、双跑和灰度范围，不允许直接覆盖核心事实；
- 为指标口径、数据合同和模型文档发布新版本；
- 明确回滚时间点、数据恢复范围和对外通知对象。

${fence("yaml", `model_contract:
  name: customer_transaction_fact
  grain: one row per completed order event
  primary_key: [order_id, event_seq]
  business_time: paid_at
  ingestion_time: ingested_at
  dimensions:
    customer: dim_customer_versioned
    store: dim_store_scd2
    product: dim_product_versioned
  change_policy:
    additive_fields: forward_compatible
    grain_or_key_change: breaking
    backfill_required: true
  owners:
    business: customer_operations
    data: enterprise_modeling_team
  quality_gates:
    - order_line_amount_reconciles
    - customer_mapping_is_unique_for_event_time
    - no_duplicate_event_sequence`)}

## 9. 一页完成标准

“${topic}”不是一份漂亮的 ER 图。完成时应能回答：核心业务对象是什么、每个事实一行代表什么、跨域靠哪些一致性维度连接、历史变化如何保留、宽表从哪里派生、模型变更影响哪些下游，以及谁有权批准破坏性变更。只要这些问题还需要靠某位资深同事口头解释，模型就还没有达到企业级。

${sourceBlock(profile, "modeling")}`;
}

function financeMetricArticle(profile) {
  const spec = FINANCE_SPECS.find((item) => item.match.test(profile.topic)) || {
    definition: `${profile.topic}需要先确定资本、收益或风险的计量对象，再统一期间、范围和口径。`,
    formula: `${profile.topic}的公式必须同时写出分子、分母和适用期间。`,
    numerator: "由业务与财务共同确认的上行口径。",
    denominator: "与分子时间、范围和币种一致的比较基数。",
    dimensions: ["报告期", "机构", "产品", "币种", "并表范围", "会计与监管口径"],
    traps: ["时点与期间混用", "并表与单体混用", "会计口径与监管口径未标注", "只看比率不看分子和分母变化"],
    case: "某金融机构在月度经营会上发现指标变化与业务直觉不一致。团队先冻结报告期、机构范围和币种，再分别核对分子、分母及口径变更，并把变化拆成业务发生、价格或汇率、分类调整和重述四类，形成了可复核的指标桥。"
  };
  const includeSql = /不良贷款率|拨备覆盖率|资本充足率/.test(profile.topic);
  return `# ${profile.title}

> [!abstract] 先确认它在回答什么风险或收益问题
> ${spec.definition}

## 1. 公式只是最后一行

**标准表达：** ${spec.formula}

${table(
    ["口径组成", "必须写清的内容", "与“" + profile.topic + "”有关的检查"],
    [
      ["分子", spec.numerator, "是否包含调整项、冲销项或监管扣减"],
      ["分母", spec.denominator, "是否与分子具有相同时点、范围、币种和对象集合"],
      ["时间", "时点余额、期间平均余额或年末余额", "同比、环比和年化规则不可混用"],
      ["范围", "单体、并表、业务线或资产组合", "并表抵销、内部交易和少数股东权益"],
      ["版本", "会计政策、监管规则和指标版本", "旧报表是否重述，是否保留下载快照"]
    ]
  )}

如果报表只显示一个百分数，使用者无法判断改善来自真实经营、分母收缩、分类迁移还是规则变化。可靠做法是同时输出分子、分母、比率和变动桥。

## 2. ${profile.topic}最容易被误读的地方

${list(spec.traps)}

这些错误的共同点是“结果看起来合理”。因此指标发布前必须保留一组可回查样本：正常对象、边界对象、冲销或核销对象、口径切换前后的同一对象。只有样本能够从报表追到明细和源系统，指标才有解释力。

## 3. 拆解路径：从总变化走到一手证据

${table(
    ["分析层", "要回答的问题", "建议维度", "一手证据"],
    [
      ["规模", `分子和分母各自变化多少，谁对${profile.topic}贡献最大`, spec.dimensions.slice(0, 2).join("、"), "余额、金额、数量及对象数"],
      ["结构", "业务组合、期限或风险分类是否改变", spec.dimensions.slice(2, 5).join("、"), "分组明细与分类版本"],
      ["价格", "利率、汇率、价格或折扣如何影响结果", "利率、汇率、价格、期间", "利率表、汇率表、定价记录"],
      ["迁移", "对象从哪个状态进入或离开", "期初状态、期末状态、事件类型", "状态迁移表与事件时间线"],
      ["调账", "核销、重述、冲正或监管调整影响多少", "调整类型、审批号、生效日", "调整单与审批记录"]
    ]
  )}

建议把变化写成桥接关系：期初值 + 新增 − 减少 + 迁移 + 价格或汇率影响 ± 口径调整 = 期末值。桥接不平，不允许用“其他”消化差额。

## 4. 案例：${caseRegion(profile)}的指标复盘

${spec.case}

这个案例可复用的不是具体结论，而是顺序：先固定时点和范围，再拆分子分母，然后按业务结构、状态迁移和口径变更解释，最后抽取原始记录。对于“${profile.topic}”，任何跨越期间的比较都必须同时检查分子、分母和样本，而不是只盯比率。

## 5. 数据模型应保留“怎么变成这个数”

至少需要四类数据：

- **对象明细：**账户、贷款、投资、保单、合同或其他承担风险与收益的主体；
- **期间快照：**期末余额、分类状态和参数版本，不能被最新状态覆盖；
- **事件流水：**新增、偿还、核销、处置、重估、汇率折算和调整；
- **口径元数据：**指标版本、适用机构、生效日期、数据来源和责任签字。

如果当前系统只有结果表，先不要补一堆派生指标。优先补齐快照日期、状态版本、对象主键和调整事件，否则后续每个报表都会重新解释一次。

${includeSql ? `## 6. 一段能回到对象的核对 SQL

下面示例以贷款指标为例。重点不是 SQL 方言，而是同时保留时点、分类、范围和变动原因：

${fence("sql", `WITH snapshot AS (
  SELECT
    loan_id,
    report_date,
    branch_id,
    product_code,
    classification_code,
    outstanding_amount,
    loss_provision_amount,
    risk_weighted_asset,
    accounting_scope,
    currency,
    rule_version
  FROM finance_loan_snapshot
  WHERE report_date = DATE '2026-09-30'
    AND accounting_scope = 'CONSOLIDATED'
),
metric AS (
  SELECT
    SUM(CASE
      WHEN classification_code IN ('SUBSTANDARD', 'DOUBTFUL', 'LOSS')
      THEN outstanding_amount ELSE 0
    END) AS npl_balance,
    SUM(outstanding_amount) AS loan_balance,
    SUM(CASE WHEN classification_code IN ('SUBSTANDARD', 'DOUBTFUL', 'LOSS')
      THEN loss_provision_amount ELSE 0 END) AS npl_provision,
    SUM(risk_weighted_asset) AS rwa
  FROM snapshot
)
SELECT
  npl_balance / NULLIF(loan_balance, 0) AS npl_ratio,
  npl_provision / NULLIF(npl_balance, 0) AS provision_coverage,
  rwa AS risk_weighted_asset,
  npl_balance,
  loan_balance
FROM metric;`)}

发布前还要用不同会计范围、币种和分类版本重跑，确认比率不会随未声明筛选条件漂移。` : `## 6. “${profile.topic}”不一定需要一段 SQL

这类指标更适合先做一张可复核的计算卡：估值日、利润或分红期间、无风险利率、样本窗口、年化因子和费用口径要全部写明。若没有稳定的对象级基础数据，先写代码只会把口径争议藏进代码。

建议用下面的计算记录替代“截图式结果”：

| 字段 | 示例值 | 来源 |
| --- | --- | --- |
| 指标版本 | ${profile.topic}-v2026.11 | 指标平台 |
| 计算期间 | 2025-10-01 至 2026-09-30 | 财务或行情数据 |
| 输入口径 | 与标题一致的分子分母说明 | 数据字典 |
| 价格或参数日期 | 估值日收盘或期末汇率 | 行情或财务系统 |
| 复核样本 | 至少一个正常、一个边界、一个异常对象 | 对象级明细 |`}

## 7. 发布检查

- 报表标题包含指标全称、期间、机构范围、币种和年化说明。
- 分子分母来自同一数据快照，比率旁同时展示原始金额和对象数。
- 分类迁移、核销、重述、汇率和规则切换有独立桥接项。
- 每个关键分组都能抽取对象明细并回到源系统。
- 监管、会计、风险与经营分析使用不同口径时，界面必须明确标识。
- 指标变化触发预警前，先检查数据完整性和口径版本，不直接通知业务处罚或考核。

${sourceBlock(profile, "finance")}`;
}

function manufacturingMetricArticle(profile) {
  const key = /设备综合效率|OEE/.test(profile.topic) ? "oee" :
    /生产效率/.test(profile.topic) ? "productivity" :
      /产能利用率/.test(profile.topic) ? "capacity" :
        /生产周期/.test(profile.topic) ? "cycle" :
          /瓶颈工序/.test(profile.topic) ? "bottleneck" :
            /准时交付率/.test(profile.topic) ? "otd" :
              /在制品/.test(profile.topic) ? "wip" : "takt";
  const spec = MANUFACTURING_SPECS[key];
  const oee = key === "oee";
  return `# ${profile.title}

> [!abstract] ${profile.topic}不是一个单独的看板数字
> ${spec.focus}

## 1. 计算口径

**核心公式：** ${spec.formula}

${oee ? `OEE 的三个因子必须来自同一条设备时间账：

${table(
    ["因子", "计算方式", "典型损失", "需要保留的原始证据"],
    [
      ["时间开动率", "实际运行时间 ÷ 计划生产时间", "故障、换型、缺料、计划外停机", "设备状态、停机区间、原因码、工单"],
      ["性能开动率", "(理论节拍 × 实际产量) ÷ 实际运行时间", "微停、降速、空转、小停顿", "标准节拍版本、产量、速度、短停事件"],
      ["良品率", "合格品数 ÷ 总产出数", "报废、返工、试生产、质量降级", "首检、终检、返工、报废和批次记录"]
    ]
  )}

示意计算：某设备计划生产 480 分钟，故障和换型损失 60 分钟，实际运行 420 分钟；按标准节拍理论可生产 840 件，实际产出 756 件；其中合格 718 件。则时间开动率约 87.5%，性能开动率 90%，良品率约 95.0%，OEE 约 74.8%。这些数字只用于说明计算，不代表任何真实工厂业绩。` : spec.focus}

## 2. 把“${profile.topic}”放回制造现场

${table(
    ["分析对象", "主键或事件", "时间语义", "数据源", "常见断点"],
    [
      ["工单", "work_order_id", "创建、释放、开工、完工", "ERP / MES", "计划变更覆盖原版本"],
      ["工序", "operation_id", "进站、出站、暂停、返工", "MES / 工艺系统", "跨班次事件不连续"],
      ["设备", "equipment_id", "运行、待机、故障、保养", "SCADA / IoT", "停机区间重叠或未闭环"],
      ["批次", "batch_id", "投料、检验、放行、报废", "QMS / WMS", "批次与工单关系缺失"],
      ["产出", "good_qty / scrap_qty", "生产完成或质检确认", "MES / QMS", "返工被重复计为合格产出"]
    ]
  )}

“${profile.topic}”依赖的维度应至少覆盖${spec.dimensions.join("、")}。这些维度中，设备、工艺路线和组织关系经常变化，必须保留事件当时版本。

## 3. 一个能解释变化的例子

${spec.case}

这个场景的判断顺序是：先确认日历、工单和事件时间，再核对标准参数版本，随后把损失按原因分段，最后才讨论设备改造、人员绩效或算法。若一开始就把低值归因于“员工效率”，通常会错过换型、缺料、待检和标准节拍失真的影响。

## 4. 指标拆解与责任边界

${table(
    ["问题", "观察指标", "下钻证据", "责任团队"],
    [
      ["计划时间是否真实", "计划工时、日历版本、计划停机", "班次日历与设备状态", "生产计划与设备管理"],
      ["损失是否重复", "停机分钟、事件区间、原因码", "同设备同时间重叠检查", "设备与 MES 团队"],
      ["速度是否可比", "标准节拍版本、实际周期", "产品、工单、工艺参数", "工业工程与工艺"],
      ["质量损失是否完整", "一次合格率、返工、报废", "批次检验和返工记录", "质量与生产"],
      ["改善是否有效", "主指标、产量、成本和交付", "改造前后同产品同班次对比", "运营与财务"]
    ]
  )}

## 5. 数据质量门禁

${list(spec.checks.map((item) => `${item}。`))}

另外建议做一次“分钟守恒”：计划时间 = 运行 + 停机 + 待机 + 计划保养；重大损失区间不能互相重叠。OEE 或效率指标只要出现时间账不平，就不能进入经营考核。

## 6. 上线后的使用方式

${profile.topic}应该进入日运营会或周改善会，但不应成为单一排名工具。建议每次会议只讨论三个问题：损失最大的工序在哪里、证据能否回到工单和设备事件、下一项改善的验证窗口是什么。连续三个月没有行动闭环的指标，应从大屏移回分析台账。

${sourceBlock(profile, "manufacturing")}`;
}

function kafkaArticle(profile) {
  return `# ${profile.title}

> [!abstract] 消费积压不是“消费者太慢”这么简单
> Kafka Lag 是“最新可消费位点”和“消费者已提交位点”的差值。它既能反映真实流量增长，也可能由消费阻塞、Rebalance、Broker 异常、下游超时、毒消息或位点提交错误造成。

## 1. 先把 Lag 算清

${fence("text", `partition_lag = end_offset - committed_offset
topic_lag = sum(partition_lag for all assigned partitions)
clear_minutes = topic_lag / max(consume_rate - produce_rate, 1)`)}

总 Lag 下降不代表业务恢复：如果生产速率也在下降，Lag 会自然缩小；如果只有少数分区积压，可能是 Key 分布倾斜；如果所有消费者同时从旧位点重放，可能是消费组或位点管理问题。

## 2. 故障现场：先止血，再定位

${table(
    ["观察面", "关键问题", "证据", "首选动作"],
    [
      ["生产端", "消息量、单条大小、分区分布是否突变", "Broker Topic 指标、分区 Offset", "限制上游突发流量或启用降级"],
      ["消费端", "处理耗时、线程池、外部依赖是否阻塞", "消费耗时分布、错误日志、下游延迟", "暂停非核心分支，保护主链路"],
      ["Rebalance", "消费者是否频繁加入、离开或超时", "Generation、心跳、poll 间隔、处理时长", "修复会话超时与处理模型，避免盲目扩容"],
      ["Broker", "磁盘、网络、Leader 切换和副本同步是否异常", "Broker 指标、ISR、磁盘 IO", "隔离异常节点并确认副本安全"],
      ["Sink", "数据库、对象存储或搜索服务是否限流", "写入延迟、错误码、连接池", "熔断、批量重试和幂等写入"],
      ["毒消息", "是否同一 Offset 反复失败阻塞分区", "异常堆栈、消息 Key、Schema 版本", "隔离到死信 Topic，修复合规后重放"]
    ]
  )}

止血目标是保护数据完整性和核心业务，不是把 Lag 数字瞬间清零。对于资金、订单状态或安全事件，宁可延迟消费也不能跳消息。

## 3. 案例：促销日的实时订单链路

某内容电商平台的 ${caseRegion(profile)} 在大促开始后看到订单 Topic Lag 持续上升。第一反应是给消费者扩容，但新增实例触发了更多 Rebalance，Lag 反而抖动。

团队改用四步处理：

1. **冻结变更：**停止继续扩缩容，记录当前消费组实例、分区分配和提交位点。
2. **分区诊断：**按单分区 Lag、消费速率和生产速率排序，发现 3 个高热 SKU 分区占大部分积压。
3. **下游定位：**消费者在同步调用库存服务，库存接口 P99 从 120ms 升到 2.3s，线程池被占满。
4. **降级恢复：**将库存校验改为异步补偿，写入按订单事件 ID 幂等；新增消费者前先确认分区数、单实例吞吐和 Rebalance 策略。

恢复后团队没有只记录“Lag 清零”，而是增加了消费延迟、失败率、重复率、外部依赖超时和回放完成率。通过故障回放验证：关闭一个 Broker、注入重复消息、制造 Sink 超时后，系统仍能恢复且不丢订单状态。

## 4. 一段可执行的 Lag 采样代码

${fence("python", `from kafka import KafkaConsumer, TopicPartition

TOPIC = "orders.events.v2"
GROUP = "order-enrichment-v4"
consumer = KafkaConsumer(
    bootstrap_servers=["broker-a:9092", "broker-b:9092"],
    group_id=GROUP,
    enable_auto_commit=False,
)

partitions = [
    TopicPartition(TOPIC, p)
    for p in consumer.partitions_for_topic(TOPIC)
]
end_offsets = consumer.end_offsets(partitions)
rows = []
for partition in partitions:
    committed = consumer.committed(partition) or 0
    rows.append({
        "partition": partition.partition,
        "committed": committed,
        "end": end_offsets[partition],
        "lag": end_offsets[partition] - committed,
    })

rows.sort(key=lambda row: row["lag"], reverse=True)
print({
    "topic": TOPIC,
    "group": GROUP,
    "total_lag": sum(row["lag"] for row in rows),
    "hottest": rows[:5],
    "cold_partitions": [row for row in rows if row["lag"] == 0][:5],
})`)}

采样结果要与消费速率、生产速率和实例处理耗时一起保存。只有 Lag 数字，无法判断积压是在缩小还是扩大。

## 5. 扩容前必须回答的五个问题

1. 当前分区数能否承载新增实例，新增实例是否会分走有效分区？
2. 单条消息平均处理耗时和 P99 分别是多少，瓶颈在 CPU、网络还是外部依赖？
3. 消费者是否在 poll 线程内执行长时间任务，从而触发会话超时？
4. Sink 是否支持幂等写，重放是否会造成重复订单、重复扣款或重复消息？
5. 业务允许的恢复目标是什么：最大延迟、最大回放时间还是“绝不丢消息”？

扩容只是手段。若依赖下游限流，扩容会把压力更快传递到数据库；若消息热点集中在少数 Key，更多实例也无法均衡处理。

## 6. 上线验收

- Lag 监控同时保留分区、消费组、生产速率、消费速率和预计清空时间。
- 消费失败有明确重试上限，毒消息进入隔离链路而不是无限阻塞。
- 消费逻辑按业务主键幂等，重放不改变最终状态。
- Rebalance、Broker 故障、Sink 超时、Schema 变更和断点恢复都有演练记录。
- 积压恢复后做源目标对账，核对事件数、业务主键、金额和状态。
- 项目复盘记录“哪种扩容有效、哪种无效”，形成下一次故障的决策卡。

${sourceBlock(profile, "streaming")}`;
}

function sparkArticle(profile) {
  const matched = SPARK_TOPICS.find(([pattern]) => pattern.test(profile.topic));
  const spec = matched?.[1] || {
    thesis: `${profile.topic}要从数据分区、依赖关系、任务调度和资源使用四个层面解释，而不是只背参数。`,
    mechanism: "Spark 作业由 Action 触发，依据 RDD/DataFrame 血缘形成 Stage，再按分区拆成 Task 在 Executor 上执行。",
    pitfalls: ["只记API名称，不解释触发条件和代价", "用单机结果推断集群行为", "只看总耗时，不看任务分位数和 Shuffle", "把参数调优当成架构修复"],
    checks: ["说明输入数据规模和分区", "定位宽依赖与 Shuffle", "观察任务倾斜、Spill和GC", "用相同数据对比优化前后"],
    code: null
  };
  const layout = profile.seed % 2 === 0
    ? ["问题是什么", "运行机制", "容易答错的地方", "案例与证据", "面试或工作中的应用"]
    : ["一句话结论", "机制拆解", "反例与边界", "现场诊断", "如何验证掌握"];
  return `# ${profile.title}

> [!abstract] 一句话结论
> ${spec.thesis}

## 1. ${layout[0]}：${profile.topic}

${profile.topic}不是孤立知识点。理解它至少要回答四个问题：它发生在 Driver、Executor 还是 Shuffle 服务；由哪个 Action 或依赖关系触发；代价体现在 CPU、内存、网络还是磁盘；如何用 Spark UI、日志或数据分布证明判断成立。

## 2. ${layout[1]}

${spec.mechanism}

${table(
    ["观察层", "这一层看什么", "证据", "不成立的信号"],
    [
      ["逻辑计划", "过滤、投影、连接和聚合是否能下推", "explain formatted", "扫描全部列或过早 Shuffle"],
      ["物理计划", "Join、聚合和交换策略", "物理计划、广播大小、分区数", "广播对象过大或空分区过多"],
      ["运行时", "任务时长、输入输出、Spill和GC", "Spark UI Stages / SQL", "少数Task远慢于中位数"],
      ["数据分布", "Key、空值、分区和历史增长", "Top Key占比、分位数", "热点长期集中且持续增长"],
      ["业务结果", "行数、金额、去重对象是否守恒", "优化前后对账表", "性能提升但结果发生变化"]
    ]
  )}

## 3. ${layout[2]}

${list(spec.pitfalls.map((item) => `${item}。`))}

尤其不要把“参数变大”当成机制解释。资源增加可能缩短任务，但无法修复错误 Join、Key 倾斜、重复计算或错误分区。面试中如果只回答参数，通常会被追问数据分布和失败复现。

## 4. ${layout[3]}：${caseRegion(profile)}的一次排查

团队接到“作业从 20 分钟变成 90 分钟”的反馈后，先确认问题发生在固定输入还是一段特定日期。对比 Spark UI 发现 Shuffle Read 增长不大，但少数 Task 的 CPU 时间是中位数的十几倍，且同一批任务发生大量 Spill。

进一步检查业务 Key，发现一个默认商户 ID 承载了大量测试订单；同时上游新增字段导致分区键类型发生变化。修复不是简单增加内存，而是清理测试数据、统一 Join 类型、对热点 Key 做两阶段聚合，并用总金额、订单数和去重用户数验证结果不变。优化后仍保留 P95 Task 时间、Spill 和资源成本，防止只看最短一次运行。

${spec.code ? `## 5. ${layout[4]}：可复跑的验证骨架

${fence("python", spec.code)}` : `## 5. ${layout[4]}：验证是否真正理解

可以用下面的问题自测：如果数据量扩大 10 倍、分区数不变、热点 Key 更集中，上述机制会怎样变化？如果新增一个 Executor，瓶颈会转移还是消失？如果结果正确但延迟不达标，下一步先看数据分布还是参数？能够把答案落到 Stage、Task、Shuffle 和对账证据上，才算掌握“${profile.topic}”。`}

## 6. 交付检查

${list(spec.checks.map((item) => `${item}。`))}

有效的 Spark 方案应留下输入数据版本、执行计划、关键指标、优化动作和业务对账。仅凭“运行成功”或“速度更快”截图，无法证明结论可复现。

${sourceBlock(profile, "spark")}`;
}

function ragEvaluationCode(scenario) {
  if (["semantic-search", "embedding", "vector-engineering"].includes(scenario.key)) {
    return `def evaluate_retrieval(cases, retriever, k=5):
    report = {"recall_at_k": 0, "mrr": 0, "zero_result": 0}
    by_slice = {}
    for case in cases:
        hits = retriever.search(
            case.query,
            top_k=k,
            filters=case.hard_filters,
        )
        ids = [hit.document_id for hit in hits]
        matched = case.expected_ids & set(ids)
        report["recall_at_k"] += len(matched) / max(len(case.expected_ids), 1)
        report["mrr"] += next(
            (1 / (index + 1) for index, doc_id in enumerate(ids)
             if doc_id in case.expected_ids),
            0,
        )
        report["zero_result"] += not bool(hits)
        bucket = by_slice.setdefault(case.slice, {"n": 0, "recall": 0})
        bucket["n"] += 1
        bucket["recall"] += len(matched) / max(len(case.expected_ids), 1)
    n = max(len(cases), 1)
    report["recall_at_k"] /= n
    report["mrr"] /= n
    report["zero_result"] /= n
    return {"overall": report, "slices": by_slice}`;
  }
  if (scenario.key === "lifecycle" || scenario.key === "governance") {
    return `def verify_index_lifecycle(source_db, index_client, as_of):
    active = {
        row.document_id: (row.version, row.content_hash)
        for row in source_db.list_active(as_of=as_of)
    }
    indexed = {
        item.document_id: (item.version, item.content_hash)
        for item in index_client.scan(alias="rag-current")
    }
    missing = sorted(set(active) - set(indexed))
    ghost = sorted(set(indexed) - set(active))
    stale = sorted(
        document_id for document_id in set(active) & set(indexed)
        if active[document_id] != indexed[document_id]
    )
    assert not missing, f"missing vectors: {missing[:20]}"
    assert not ghost, f"deleted or unauthorized vectors: {ghost[:20]}"
    assert not stale, f"stale vectors: {stale[:20]}"
    return {"active": len(active), "missing": 0, "ghost": 0, "stale": 0}`;
  }
  if (scenario.key === "agentic-architecture" || scenario.key === "agentic-engineering") {
    return `def evaluate_agentic_trace(trace, evaluator):
    budget = {"steps": 6, "retrieval_calls": 4, "latency_ms": 8000}
    checks = {
        "budget_respected": (
            len(trace.retrieval_calls) <= budget["retrieval_calls"]
            and trace.latency_ms <= budget["latency_ms"]
        ),
        "evidence_added": evaluator.new_evidence_count(trace) > 0,
        "stopped_with_reason": trace.stop_reason in {
            "evidence_sufficient", "budget_exhausted", "manual_review"
        },
        "citations_supported": bool(trace.citations) and all(
            citation.supported for citation in trace.citations
        ),
    }
    if not checks["evidence_added"] and trace.stop_reason == "evidence_sufficient":
        checks["false_convergence"] = False
    return checks`;
  }
  return `from dataclasses import dataclass

@dataclass(frozen=True)
class Case:
    query: str
    expected_docs: frozenset[str]
    allowed_roles: frozenset[str]
    answerable: bool

def evaluate_rag(cases, retriever, answerer, role):
    result = {
        "recall_at_5": 0.0,
        "rerank_ndcg": 0.0,
        "citation_supported": 0.0,
        "correct_refusal": 0.0,
        "permission_leaks": 0,
    }
    for case in cases:
        candidates = retriever.recall(
            case.query,
            filters={"roles": case.allowed_roles & {role}},
            k=30,
        )
        result["permission_leaks"] += sum(
            bool(set(item.allowed_roles) - {role}) for item in candidates
        )
        ranked = retriever.rerank(case.query, candidates)[:5]
        result["recall_at_5"] += bool(case.expected_docs & {
            item.document_id for item in ranked
        })
        answer = answerer.answer(case.query, ranked)
        result["citation_supported"] += bool(answer.citations) and all(
            citation.supported for citation in answer.citations
        )
        result["correct_refusal"] += (
            not answer.answered if not case.answerable else answer.answered
        )
    total = max(len(cases), 1)
    for key in ("recall_at_5", "citation_supported", "correct_refusal"):
        result[key] = round(result[key] / total, 4)
    return result`;
}

function ragArticle(profile) {
  const scenario = RAG_SCENARIOS.find((item) => item.match.test(profile.topic)) ||
    RAG_SCENARIOS.at(-1);
  const focus = RAG_FOCUS.find(([pattern]) => pattern.test(profile.topic))?.[1] ||
    scenario.thesis;
  const chain = [
    ["任务识别", scenario.question, "意图、适用范围、时间和组织过滤条件", "任务理解错误率"],
    ["候选召回", `围绕“${profile.topic}”并行执行关键词、Embedding 和结构化过滤`, "TopK、过滤字段、索引版本", "Hit@K、来源覆盖"],
    ["重排", "按问题相关性、权威性、时效和组织适用性重新排序", "重排分数、截断位置、去重结果", "NDCG、人工相关性"],
    ["证据核验", `检查${scenario.controls.join("、")}是否满足`, scenario.artifact, "证据覆盖率"],
    ["生成与引用", "逐段限定证据，引用定位到章节或页码", "引用片段、页码、文档版本", "引用支持率、忠实度"],
    ["拒答与接管", "无证据、版本冲突或权限不足时停止", "拒答类型、转人工原因", "拒答准确率"]
  ];
  return `# ${profile.title}

> [!abstract] ${scenario.label}：先约束证据，再追求答案
> ${scenario.thesis}

## 1. ${scenario.label}究竟要完成什么任务

${focus} 对“${profile.topic}”而言，第一项交付不是模型接口，而是把任务边界写成可以验收的契约：

${table(
    ["设计项", "本主题必须回答", "推荐证据", "对应指标"],
    [
      ["使用者与任务", scenario.question, "任务清单、用户角色和失败样本", "任务完成率"],
      ["证据边界", `当前内容来自${scenario.artifact}`, "来源、版本、权限和有效期", "有效证据覆盖率"],
      ["失败边界", scenario.failure, "反例集、冲突集和越权集", "高风险错误数"],
      ["行动边界", "回答只提供建议、摘要，还是允许触发后续动作", "审批与人工接管记录", "自动执行错误率"],
      ["成本边界", "允许多少轮检索、重排和生成", "轮次、Token、延迟和费用", "单位任务成本"]
    ]
  )}

## 2. 一条针对“${profile.topic}”的检索链

标准 RAG 也必须分清召回与重排，复杂链路还要记录每次检索新增了哪些证据。对“${profile.topic}”，建议按下面的顺序定位问题：

${table(
    ["阶段", "关键动作", "保留什么", "验收指标"],
    chain
  )}

${scenario.key.startsWith("agentic")
    ? "Agentic 架构还需要终止条件。每一轮都应比较“新增有效证据是否值得新增成本”；如果连续两轮没有带来新证据，继续改写问题通常只是在放大费用，而不是提高质量。"
    : "如果召回层没有找到正确证据，重排和生成无法补救。因此先看正确文档是否进入候选，再判断重排是否把它排到前面，最后才检查回答有没有忠实引用。"}

## 3. 文档、Embedding、索引和权限要一起治理

${scenario.label}最常见的误判，是把内容问题当成模型问题。实际落地应同时保存四类版本：源文档版本、解析分段版本、Embedding 模型版本和向量索引版本。

${table(
    ["治理对象", "必须记录", "失败时会怎样", "验收动作"],
    [
      ["文档", "Owner、生效时间、替代关系、密级和适用组织", "旧制度被当成新制度，越权内容进入候选", "抽取更新、作废和撤权样本"],
      ["Chunk", "标题路径、页码、表格结构和上下文窗口", "条款被截断，引用无法定位", "人工检查长表格与否定句"],
      ["Embedding", "模型、维度、归一化方法和训练/发布时间", "模型升级后新旧向量不可比较", "同集回归并双写迁移"],
      ["索引", "别名、分片、增量位点、重建时间和回滚点", "删除不传播，产生幽灵内容", "验证删除后零召回"],
      ["权限", "租户、角色、地区、用途和字段级限制", "候选在生成前已经越权", "越权样本必须为零"]
    ]
  )}

检索前必须执行权限与有效期过滤。只在最终答案处隐藏敏感段落并不可靠，因为模型已经在上下文中看到了内容，引用和缓存也可能继续传播。

## 4. 工作现场：${scenario.caseTitle}

${scenario.caseStory}

这个问题暴露的不是单一模型缺陷，而是 **${scenario.failure}**。团队按以下顺序修复：

1. 冻结当前回答样本，按阶段拆成解析、召回、重排、引用、拒答和权限六类；
2. 用${scenario.artifact}重建一次可复现轨迹，确认错误最早出现在哪一层；
3. 针对“${profile.topic}”补充正常、冲突、过期、无答案和越权样本；
4. 把验收指标设为${scenario.metrics.join("、")}，不以平均回答满意度替代；
5. 在灰度环境比较新旧链路，确认引用支持、P95 延迟和单位成本都能解释。

一个反向练习是：${scenario.exercise}。如果系统只能解释成功样本，不能解释为什么停止、拒答或转人工，链路仍不具备生产可控性。

## 5. 可复跑的离线评测

下面不是某个框架的固定模板，而是本主题应保留的最小证据。生产接入时还要替换为真实文档主键、版本、权限过滤和人工标注。

${fence("python", ragEvaluationCode(scenario))}

评测集需要单独保存，并覆盖相似文档、版本冲突、跨语言、否定表达、长表格、扫描件、空结果和越权问题。每次更换解析器、Embedding、重排模型、提示词或索引参数，都在同一评测集上比较召回、重排、引用、拒答和成本。

## 6. “${profile.topic}”的上线门槛

${list([
    "每个答案都能定位到文档、版本、页码或章节；链接存在不等于引用支持结论。",
    "检索前完成租户、角色、地区、有效期和用途过滤，越权内容不进入候选上下文。",
    "无答案、冲突、过期和权限不足都有明确拒答或人工接管类型。",
    "解析、召回、重排、引用和拒答分别有指标，不只看最终回答满意度。",
    `围绕${scenario.metrics.join("、")}建立基线、灰度和回滚条件。`,
    "Embedding 或索引升级支持双写、别名切换和旧版本回滚，删除事件能够传播到向量与缓存。",
    "高风险用途保留人工确认，不把模型回答直接当成制度、医疗、法律或财务结论。"
  ])}

${sourceBlock(profile, "rag")}`;
}

function agentArticle(profile) {
  const focus = AGENT_FOCUS.find(([pattern]) => pattern.test(profile.topic))?.[1] ||
    "Agent 的工程难点在可控执行，而不是让模型写得像一个“智能员工”。";
  const security = /安全|沙箱|权限|审计|责任/.test(profile.topic);
  return `# ${profile.title}

> [!abstract] 从“会回答”走向“会执行”，风险边界必须同步扩大
> ${focus}

## 1. Agent 的哪一部分值得做成 Agent

普通问答适合一次性生成；固定流程更适合工作流；只有当任务需要根据观察逐步选择工具、遇到异常能改变路径，并且结果可以验证时，Agent 才有明显价值。

${table(
    ["任务特征", "普通工作流", "Agent", "判断依据"],
    [
      ["步骤固定", "优先", "通常不需要", "每一步可预先编排"],
      ["需要多轮检索与验证", "可部分实现", "适合", "下一步取决于检索结果"],
      ["高风险写操作", "审批后工作流", "只能受限使用", "必须有权限、幂等和人工确认"],
      ["长任务和异常恢复", "需要|状态机", "适合但更复杂", "要有检查点、预算和停止条件"],
      ["答案质量可自动评测", "可上线", "可灰度", "有稳定回归集和指标"],
      ["目标模糊且无法验证", "不宜自动化", "不宜", "不能把“看起来完成”当成功"]
    ]
  )}

## 2. 计划、工具与终止条件

一个可运行的 Agent 至少包含：

1. **目标状态：**什么条件下可以结束，什么是明确失败。
2. **允许工具：**每个工具的参数、权限、超时、成本和幂等规则。
3. **观察格式：**工具返回哪些证据，错误如何分类，何时需要重试。
4. **预算：**最大步数、Token、金额、时间和外部 API 调用次数。
5. **人工接管：**哪些动作必须审批，哪些异常必须停止。
6. **审计记录：**计划、调用、参数、结果、版本、责任人和最终动作。

没有终止条件的 Agent 不是自动化，而是无限循环；没有工具白名单的 Agent 不是助手，而是未授权执行器。

## 3. ${security ? "权限与沙箱是运行时约束" : "案例：一个可审计的运营分析 Agent"}

${security ? `Agent 安全不能只在提示词里写“不要做危险操作”。真正的控制点在运行时：

- 模型只能看到已授权的工具清单和字段级权限；
- 工具参数经过 Schema 校验，金额、客户和日期范围有上限；
- 写操作先在沙箱或事务中演练，再由人工或策略引擎批准；
- SQL 只允许只读账号、查询超时和扫描量上限；
- 敏感结果脱敏后再进入模型上下文；
- 每次调用绑定用户、会话、Agent 版本和审批记录。

沙箱也不是绝对安全。必须限制网络、文件系统、可用包和运行时间，并防止通过工具返回内容进行提示注入。` : `某物流企业的 ${caseRegion(profile)} 需要 Agent 每日分析延误原因。团队没有让 Agent 直接写数据库，而是提供四个只读工具：查询延误分组、读取线路事件、获取天气摘要、生成待确认分析草稿。

Agent 的目标是“找出影响最大的两个可干预原因，并为每个原因附三条事件证据”，最大 8 步。遇到数据权限不足、指标版本冲突或查询扫描量过高时必须停止并请求人工确认。每条结论记录工具调用和样本 ID，运营人员确认后才能生成改善任务。`}

## 4. 多 Agent 什么时候才有必要

多 Agent 的常见收益来自权限隔离、上下文隔离和并行探索，不是角色名称更多。一个“规划 Agent + 检索 Agent + 审核 Agent”只有在工具权限不同、审核标准独立、并行能明显缩短时延时才值得拆。

如果所有 Agent 共享同一模型、同一提示词和同一工具集，却互相转交任务，通常只是增加成本和失败点。更简单的工作流或状态机可能更可靠。

## 5. 评估与可观测性

${table(
    ["指标", "例子", "失败时怎么处理"],
    [
      ["任务成功率", "完成目标且通过验收的会话占比", "按任务类型和工具分层分析"],
      ["工具正确率", "工具选择、参数、权限和返回解析", "记录错误类型与修正成本"],
      ["证据充分性", "结论是否有可回查工具结果", "证据不足时拒答或转人工"],
      ["安全拦截", "越权、高风险写入、提示注入", "必须阻断并审计"],
      ["延时和成本", "P95步数、Token、API调用和等待", "设置预算和降级路径"],
      ["人工接管", "触发原因、频率、最终处理", "高频场景应回到工作流或规则"]
    ]
  )}

## 6. 最小运行骨架

${fence("python", `from dataclasses import dataclass

@dataclass
class Step:
    tool: str
    arguments: dict
    approved: bool = False

def run_agent(question, planner, tools, policy, max_steps=8):
    trace = []
    state = {"question": question, "observations": []}
    for step_no in range(max_steps):
        action = planner(state)
        if action["type"] == "finish":
            return {"status": "completed", "action": action, "trace": trace}
        if action["tool"] not in policy.allowed_tools:
            return {"status": "blocked", "reason": "tool_not_allowed", "trace": trace}
        if policy.requires_approval(action) and not action.get("approved"):
            return {"status": "awaiting_approval", "action": action, "trace": trace}
        result = tools[action["tool"]](**action["arguments"])
        trace.append({
            "step": step_no,
            "tool": action["tool"],
            "arguments": policy.redact(action["arguments"]),
            "result_digest": policy.digest(result),
        })
        state["observations"].append(result)
    return {"status": "budget_exhausted", "trace": trace}`)}

## 7. 上线标准

- 每类任务有明确成功与失败定义，不把模型自评当唯一验收。
- 所有工具经过白名单、参数校验、超时、幂等和审计。
- 高风险动作必须人工确认，Agent 不能自行扩大权限。
- 有最大步数、成本、时间和并发预算。
- 评测集覆盖正常、歧义、权限、注入、工具异常和中途恢复。
- 失败能停在安全状态，并能从轨迹解释“为什么这样做”。

${sourceBlock(profile, "rag")}`;
}

function textToSqlArticle(profile) {
  return `# ${profile.title}

> [!abstract] 自然语言问题看起来简单，难点在业务语义和查询安全
> Text-to-SQL 不是“让大模型写一句 SELECT”。可靠链路必须识别用户意图、绑定数据表与字段、处理指标口径、生成与校验 SQL、执行权限过滤，并控制扫描成本。

## 1. 从问题到 SQL 的六道关

${table(
    ["阶段", "要解决什么", "典型失败", "需要的证据"],
    [
      ["意图解析", "问的是趋势、排名、明细还是原因", "把“为什么下降”误当成只看总量", "意图标签与澄清问题"],
      ["Schema Linking", "找到正确的表、字段、关联和粒度", "选了同名不同域字段", "候选表、字段说明、Join路径"],
      ["指标映射", "把业务词映射到已批准指标口径", "“活跃”和“下单”被混用", "指标版本、过滤条件、时间窗"],
      ["SQL 生成", "生成可执行且语义正确的查询", "重复计算、笛卡尔积、错用窗口", "AST、参数、解释说明"],
      ["安全校验", "限制库表、列、行、扫描量和超时", "越权访问客户手机号", "权限策略与执行计划"],
      ["纠错回归", "根据错误分类修正，而不是盲重试", "错误列被反复猜测", "错误类型、修复轨迹、回归样本"]
    ]
  )}

## 2. Schema 不是一份字段清单

为了让模型选对表，语义层至少要提供：

- 表的业务域、粒度、主键、时间字段和更新频率；
- 字段中文名、类型、枚举、单位、空值含义和敏感等级；
- 表间可批准的关联路径与基数；
- 指标定义、同义词、默认过滤、排除项和版本；
- 示例问题、黄金 SQL、结果断言和常见反例；
- 用户可访问的租户、组织、区域和数据类型。

如果只有 \`table_name\` 和 \`column_name\`，模型很容易生成语法正确但业务错误的结果。Text-to-SQL 的上限往往由语义层质量决定。

## 3. 案例：经营分析助手的错误链

某零售集团的 ${caseRegion(profile)} 上线内部查询助手。用户问“上个月华东新客贡献的净销售额是多少，和去年同期比”，第一版系统生成了 SQL，但结果比经营看板高出 18%。

复盘发现四个问题：

1. “新客”被解释成首次访问用户，而经营口径是首次完成支付；
2. 华东使用当前门店所在区域回溯历史，导致历史订单被重新归属；
3. 净销售额没有扣除退款和优惠分摊；
4. 系统在日期范围外多读了一个分区，扫描成本翻倍。

团队把问题拆成“指标口径、时间、组织版本、退款、扫描预算”五类。修复后，生成 SQL 前先展示已解析的对象、指标和时间范围，执行前通过 AST 校验表权限和分区，结果旁显示黄金查询对账。对于歧义问题，系统主动要求用户确认，而不是猜一个答案。

## 4. 不让模型直接执行任意 SQL

${fence("python", `import sqlglot
from sqlglot import exp

ALLOWED_TABLES = {
    "dws_sales_daily",
    "dim_region_scd2",
    "dim_customer_versioned",
}
BLOCKED_COLUMNS = {"phone", "id_card", "bank_card"}

def validate_sql(sql: str, user_scope: dict) -> None:
    statements = sqlglot.parse(sql, read="spark")
    if len(statements) != 1:
        raise ValueError("只允许一条只读查询")
    tree = statements[0]
    if not isinstance(tree, exp.Select):
        raise ValueError("只允许 SELECT")

    tables = {table.name.lower() for table in tree.find_all(exp.Table)}
    if not tables <= ALLOWED_TABLES:
        raise PermissionError(f"未授权表: {tables - ALLOWED_TABLES}")

    columns = {column.name.lower() for column in tree.find_all(exp.Column)}
    if columns & BLOCKED_COLUMNS:
        raise PermissionError("查询包含敏感字段")

    required_scope = user_scope["region_codes"]
    if required_scope and "region_code" not in sql:
        raise PermissionError("缺少租户/区域过滤条件")`)}

生产环境还应使用只读账号、服务端强制行级权限、最大扫描字节数、超时和结果行数上限。不能依赖模型自己在 SQL 里追加权限条件。

## 5. 评估要比较“答案”而不只是 SQL 文本

同一个问题可以由不同 SQL 得到相同正确结果，因此评测应分三层：

${table(
    ["层级", "指标", "示例"],
    [
      ["结构", "表字段命中、权限通过、AST合法、扫描量", "是否选中正确指标表"],
      ["结果", "黄金结果差异、排序、空值、时间范围", "总和、分组和明细一致"],
      ["解释", "能否说明口径、限制和假设", "主动提示组织历史版本"],
      ["安全", "越权、注入、危险函数和拒绝率", "用户跨租户查询被阻断"],
      ["体验", "澄清次数、首答正确率、纠错轮数", "歧义问题不盲猜"]
    ]
  )}

建议准备 300 到 1000 条脱敏业务问题，覆盖同义词、口径冲突、时间、组织变更、空值、TopN、比率、退款和权限。每次修改 Schema 描述、提示词、模型或校验器都要回归。

## 6. 实施顺序

1. 先做 20 个高频、低风险、结果可验证的问题；
2. 建立指标和 Join 的语义层，不直接暴露全部物理表；
3. 先回答问题，再显示 SQL 和口径，让用户能确认；
4. 对查询做服务端权限、成本和只读校验；
5. 引入黄金 SQL 和结果对账，不做纯文本相似度评估；
6. 最后才开放更复杂的问题和写操作。

${sourceBlock(profile, "service")}`;
}

function dataServiceArticle(profile) {
  const focus = DATA_SERVICE_FOCUS.find(([pattern]) => pattern.test(profile.topic))?.[1] ||
    "数据服务把内部数据能力暴露给更多调用方，接口契约、权限、SLO和回滚比一次性查询更关键。";
  const deploy = /部署/.test(profile.topic);
  return `# ${profile.title}

> [!abstract] 能返回数据，只是数据服务的最低要求
> ${focus}

## 1. 服务契约先于代码

${table(
    ["契约项", "必须写清", "失败后果"],
    [
      ["资源与粒度", "一行代表什么，主键是什么，默认排序", "调用方重复累计或错配对象"],
      ["字段", "类型、单位、时区、枚举、空值含义", "金额、日期和状态解释不一致"],
      ["时间", "数据更新到哪个分区，业务时间还是处理时间", "把旧数据当实时结果"],
      ["权限", "调用者、租户、行级范围和数据用途", "越权读取或跨租户泄露"],
      ["分页与限量", "游标、最大页大小、超时、结果上限", "全量拉取拖垮服务"],
      ["错误码", "可重试、不可重试、权限、限流和业务校验", "调用方盲重试放大故障"],
      ["版本", "兼容字段、废弃字段、迁移窗口", "客户端升级时出现隐性中断"]
    ]
  )}

接口文档不只是请求示例。它要说明数据多久更新一次、某个字段为空代表“未发生”还是“无权限”、金额是原币还是本币，以及哪些错误可以重试。

## 2. ${deploy ? "部署不是把进程拉起来" : "运行时分层"}

${deploy ? `数据服务部署至少包含六个可回滚阶段：

1. **构建：**固定依赖、镜像、配置和数据库迁移版本；
2. **配置：**密钥从安全存储注入，普通配置按环境区分；
3. **启动：**健康检查区分存活和就绪，避免未连上数据源就接流量；
4. **灰度：**按租户、调用方或小流量发布，观察错误率和尾延迟；
5. **切换：**DNS、网关或服务发现只在一个验证窗口后切流；
6. **回滚：**保留上一镜像、配置、Schema兼容和缓存清理方案。

如果数据库迁移不可逆，必须采用扩展-迁移-收缩策略，先增加兼容字段，再迁数据，最后删除旧字段。` : `数据服务通常分为接入层、语义与权限层、查询执行层、缓存层和数据源层：

${table(
    ["层次", "职责", "常见风险", "控制点"],
    [
      ["接入层", "鉴权、路由、限流、TLS", "绕过网关注入参数", "统一认证与WAF"],
      ["语义层", "指标、粒度、版本和字段映射", "同名指标口径冲突", "指标版本与签名"],
      ["权限层", "租户、行级、列级和用途过滤", "只在客户端过滤", "服务端强制策略"],
      ["执行层", "SQL生成、超时、扫描量和结果限制", "大查询拖垮仓库", "成本和并发预算"],
      ["缓存层", "热点查询和结果复用", "缓存绕过权限或返回旧版本", "缓存键包含权限与数据版本"],
      ["数据层", "表、视图、物化和新鲜度", "上游变更未通知", "数据合约与血缘"]
    ]
  )}`}

## 3. 错误码、幂等和重试

${fence("json", `{
  "code": "DATA_NOT_READY",
  "message": "请求分区尚未完成质量门禁",
  "retryable": true,
  "retry_after_seconds": 300,
  "request_id": "req_7f3a...",
  "data_version": "sales_daily@2026-11-06T02:15:00+08:00",
  "trace_id": "trace_91b4..."
}`)}

可重试错误应包含建议等待时间；权限、参数和业务校验错误不应自动重试。写接口必须使用幂等键，防止调用方超时后重复提交。每次响应保留请求 ID、数据版本和查询版本，方便对账和追责。

## 4. 案例：${caseRegion(profile)}的一次发布事故

某经营分析 API 发布新版本后，部分租户看到销售额偏低，但接口成功率仍接近 100%。排查发现缓存键只包含查询参数，没有包含租户权限和数据版本，导致不同租户共享了同一条缓存结果；同时新版本默认只读取最近一个完整分区，而部分财务数据延迟到达。

修复采用四个动作：把租户、权限摘要、数据版本和指标版本放入缓存键；返回体显式提供数据截止时间；新增分区完成度检查作为就绪条件；按租户灰度并保留上一版本30分钟。事故后补充了“结果级对账”，不再只用 HTTP 200 判断服务健康。

## 5. SLO 与监控

${table(
    ["指标", "建议定义", "动作"],
    [
      ["可用性", "成功请求 ÷ 有效请求", "连续低于目标时暂停发布"],
      ["尾延迟", "P95/P99请求耗时", "按调用方和查询类型定位"],
      ["数据新鲜度", "当前时间减数据截止时间", "超阈值返回 DATA_NOT_READY"],
      ["错误率", "5xx、超时、数据未就绪分别统计", "区分可重试与不可重试"],
      ["成本", "扫描字节、执行时长、缓存命中", "超过预算限流或拒绝"],
      ["业务一致性", "核心字段与黄金数据集对账", "差异阻断或降级"],
      ["权限事件", "拒绝、越权尝试和异常导出", "触发安全审计"]
    ]
  )}

## 6. 发布检查

- OpenAPI 或 GraphQL Schema 有版本、废弃策略和兼容性测试。
- 鉴权和行级过滤在服务端执行，缓存键包含权限与数据版本。
- 所有查询有超时、扫描量、返回行数和并发限制。
- 返回数据包含截至时间、指标版本和请求追踪 ID。
- 灰度按租户或调用方进行，上一版本和配置可回滚。
- 核心字段有结果对账，健康检查不仅看进程是否存活。
- 发布公告写清影响范围、迁移时间和调用方责任。

${sourceBlock(profile, "service")}`;
}

function sqlArticle(profile) {
  const topic = profile.topic;
  const window = /窗口|TopN|连续活跃|排名|累计|同比|环比/.test(topic);
  return `# ${profile.title}

> [!abstract] SQL 的价值在于把业务问题变成可验证的集合运算
> ${topic}应从输入粒度、时间窗口、空值、并列规则和执行成本开始，而不是先拼函数。

## 1. 先确定一行数据代表什么

${table(
    ["问题", "如果答错会怎样", "本主题检查点"],
    [
      ["输入粒度", "重复计数、窗口计算多发散", "订单、订单行、用户日或事件"],
      ["时间字段", "同一指标跨期或未来数据泄漏", "业务时间、分区时间、更新时间"],
      ["过滤位置", "排名或累计结果包含不该出现的对象", "WHERE发生在窗口前还是后"],
      ["并列规则", "TopN数量不稳定", "RANK、DENSE_RANK、ROW_NUMBER"],
      ["空值与边界", "首日、末日或未有事件对象缺失", "COALESCE、外连接和日期骨架"]
    ]
  )}

## 2. ${window ? "窗口函数的关键是分区、排序和帧" : "从集合语义理解查询"}

${window ? `窗口函数不会减少行数，它在保留明细的同时增加计算列。三个核心组成是：

- \`PARTITION BY\`：在哪些业务对象内部计算；
- \`ORDER BY\`：窗口内顺序，决定排名、累计或前后行；
- 窗口帧：只对累计、移动平均等函数生效。

如果先 \`GROUP BY\` 再排名，输入已经从明细变成聚合结果；如果先排名再过滤，要使用子查询或 CTE。` : `SQL 查询可以拆成输入集合、过滤、关联、聚合、窗口和输出六步。执行顺序不等同于书写顺序，WHERE、聚合后 HAVING 和窗口后过滤不能互换。`}

## 3. 可运行示例

${window ? fence("sql", `WITH order_line AS (
  SELECT
    order_id,
    user_id,
    order_time,
    pay_amount,
    ROW_NUMBER() OVER (
      PARTITION BY order_id
      ORDER BY updated_at DESC
    ) AS version_no
  FROM dwd_order_line
  WHERE dt >= DATE '2026-10-01'
    AND dt <  DATE '2026-11-01'
    AND is_deleted = 0
),
dedup AS (
  SELECT * FROM order_line WHERE version_no = 1
),
daily AS (
  SELECT
    user_id,
    CAST(order_time AS DATE) AS order_date,
    SUM(pay_amount) AS daily_amount
  FROM dedup
  GROUP BY user_id, CAST(order_time AS DATE)
),
ranked AS (
  SELECT
    user_id,
    order_date,
    daily_amount,
    SUM(daily_amount) OVER (
      PARTITION BY user_id
      ORDER BY order_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_amount,
    LAG(daily_amount) OVER (
      PARTITION BY user_id ORDER BY order_date
    ) AS previous_day_amount,
    RANK() OVER (
      PARTITION BY order_date ORDER BY daily_amount DESC
    ) AS amount_rank
  FROM daily
)
SELECT *
FROM ranked
WHERE amount_rank <= 10
ORDER BY order_date, amount_rank;`) : fence("sql", `WITH scoped AS (
  SELECT
    user_id,
    order_id,
    paid_at,
    net_amount
  FROM dwd_order
  WHERE dt BETWEEN DATE '2026-10-01' AND DATE '2026-10-31'
    AND pay_status = 'PAID'
),
per_user AS (
  SELECT
    user_id,
    COUNT(DISTINCT order_id) AS order_cnt,
    SUM(net_amount) AS net_amount
  FROM scoped
  GROUP BY user_id
)
SELECT
  CASE WHEN order_cnt >= 3 THEN '高频' ELSE '普通' END AS user_segment,
  COUNT(*) AS user_cnt,
  SUM(net_amount) AS total_amount,
  AVG(net_amount) AS avg_amount
FROM per_user
GROUP BY CASE WHEN order_cnt >= 3 THEN '高频' ELSE '普通' END
ORDER BY total_amount DESC;`)}

## 4. 案例：${caseRegion(profile)}的排名口径争议

运营团队要求每天列出“金额最高的10个商品”，两个系统却给出不同名单。原因不是 SQL 写错，而是：

- 一个系统按支付时间，另一个按退款后净额；
- 一个用 \`ROW_NUMBER\`，另一个用 \`RANK\`，并列时数量不同；
- 一个先按商品汇总，另一个在订单行排名；
- 测试订单与跨期退款过滤规则不一致。

团队最终把需求写成“每个自然日，按退款后净额汇总到SKU，过滤测试订单，使用DENSE_RANK，并列全部展示”。同时约定当SKU跨多个类目时使用主类目历史版本。口径明确后，不同引擎才可能得到相同名单。

## 5. 性能与验证

- 在窗口前尽量过滤和减少列，但不要误删业务需要的边界行。
- 大表连续多次窗口计算可先做一次聚合或临时持久化。
- 检查分区裁剪、Join键类型、数据倾斜和输出文件数量。
- 用正常、空值、并列、跨月、重复时间和无事件对象做回归。
- 结果验收同时看总量、对象数、分组差异和抽样明细。

${sourceBlock(profile, "sql")}`;
}

function governanceArticle(profile) {
  const title = profile.topic;
  const isQuality = /质量|异常检测|监控|漂移/.test(title);
  const isLineage = /血缘|元数据|目录|影响分析/.test(title);
  const isSecurity = /安全|隐私|权限|合规|分类分级|Ranger|HIPAA|脱敏/.test(title);
  const isMaster = /主数据|标准|OneID|语义|合约|指标口径/.test(title);
  const orientation = isQuality
    ? "质量治理的产出不是告警数量，而是能够在发布前阻止错误、在事故中定位范围、在复盘后减少同类问题。"
    : isLineage
      ? "血缘的价值不是画一张关系图，而是回答“这次变更会影响谁、数据从哪来、哪个版本可追”。"
      : isSecurity
        ? "安全与合规的控制点必须落在数据访问、用途、导出、审计和删除流程中，而不是只写在制度文档里。"
        : isMaster
          ? "主数据与标准的难点是跨系统统一语义，同时保留合并、拆分、映射和版本历史。"
          : "数据治理只有在能够改变发布、访问、使用或责任分配时才产生价值。";
  const methods = isQuality ? [
    ["规则", "完整性、唯一性、时间、枚举、范围和跨表平衡", "规则负责人、SQL与阈值"],
    ["画像", "空值、重复、分布、历史和异常批次", "字段画像与样本"],
    ["门禁", "阻断、严重、观察分级", "发布记录与豁免"],
    ["响应", "定位范围、冻结分区、修复、重跑", "事故单与对账"],
    ["复盘", "根因、影响、改进和回归样本", "复盘与复测"]
  ] : isLineage ? [
    ["资产", "表、字段、任务、指标、API和模型", "稳定资产ID"],
    ["关系", "读写、派生、引用和责任人", "任务与解析证据"],
    ["版本", "数据集、代码、规则和指标版本", "版本时间线"],
    ["影响", "字段变更会传播到哪些下游", "影响清单与消费确认"],
    ["运行", "血缘更新是否及时准确", "覆盖率与断链告警"]
  ] : isSecurity ? [
    ["分类", "数据是什么、敏感等级和适用法规", "分类分级结果"],
    ["用途", "谁因什么业务目的使用", "用途登记与审批"],
    ["权限", "行列级、租户、环境和导出限制", "策略与访问日志"],
    ["保护", "加密、脱敏、令牌化与密钥", "技术配置和抽检"],
    ["响应", "泄露、误用、撤回和删除", "演练与审计"]
  ] : [
    ["对象", "主数据实体、编码、来源和责任人", "对象模型与Owner"],
    ["映射", "多源ID、置信度、有效期和合并拆分", "映射表与证据"],
    ["语义", "指标、字段、枚举和版本", "数据合同"],
    ["采用", "哪些系统和流程真正使用标准", "调用与变更记录"],
    ["运营", "争议、例外、质量与版本", "例会与问题闭环"]
  ];
  return `# ${profile.title}

> [!abstract] 从控制效果倒推治理设计
> ${orientation}

## 1. “${title}”要改变哪一个动作

${table(
    ["如果没有治理", "业务风险", "治理后应改变什么", "验证方式"],
    [
      ["同名指标多处实现", "同一会议出现不同数字", "指标发布前必须有唯一语义和版本", "黄金结果与下游使用清单"],
      ["数据变更无人通知", "报表停摆或决策延迟", "破坏性变更需影响分析和迁移窗口", "变更前影响名单与消费方确认"],
      ["异常只能在群里反馈", "发现晚、责任不清", "规则绑定资产、Owner、等级和动作", "演练故障能否在SLA内闭环"],
      ["敏感字段全域可见", "越权、导出和合规风险", "服务端行列过滤、用途审批与审计", "权限测试和越权拒绝率"],
      ["标准停留在文档", "系统继续各说各话", "标准进入接口、模板和发布门禁", "新建资产合规率"]
    ]
  )}

## 2. 工作对象与控制链

${table(
    ["环节", "核心工作", "必要证据", "失败信号"],
    methods
  ).split("\n").join("\n")}

## 3. 案例：${caseRegion(profile)}的治理落地

${isQuality ? `某银行的 ${caseRegion(profile)} 每天收到数千条质量告警，但真正阻断发布的问题很少。团队先按资金、客户、监管和经营影响重分级，把“非空率轻微波动”从阻断改为观察，把主键重复、金额不平、账龄状态非法和历史分区被覆盖设为阻断。

随后为每条规则绑定资产、负责人、规则版本、失败样本和处置时限。上线前用历史故障回放，确认门禁能在 10 分钟内定位受影响分区；发布后统计误报、漏报和人工核验成本。三个月后告警数量下降，但关键问题拦截率提高，治理才开始被业务认可。` : isLineage ? `某制造集团的 ${caseRegion(profile)} 在修改物料表字段时，下游报表、特征任务和供应商接口连续失败。原血缘只记录表级关系，无法说明字段经过哪些转换进入哪个指标。

团队从任务 SQL、调度依赖和 API 定义中抽取字段级血缘，为每条边保存解析来源、代码版本和置信度；对动态 SQL 增加人工登记和样例校验。字段变更发布前自动生成影响清单，要求关键消费者确认。上线后，血缘覆盖率不是唯一指标，断链数、变更拦截数和影响分析耗时同样进入治理报告。` : isSecurity ? `某互联网医疗平台的 ${caseRegion(profile)} 发现客服分析账号可以访问患者诊断明细。问题不是缺少制度，而是权限颗粒度过粗、导出通道未限制、用途审批与实际访问脱节。

团队先按数据类别和用途拆分角色，将诊断、处方和支付列设为列级权限；跨院区访问增加组织过滤；批量导出进入独立审批和脱敏流程；所有查询绑定用户、用途、租户和追踪ID。随后用越权、过期账号、导出超限和撤回请求做红队测试，确保控制点在服务端生效。` : `某零售集团的 ${caseRegion(profile)} 有 7 个系统各自维护会员等级。营销按当前等级圈选，财务按历史等级回溯，客服又使用另一套状态，导致同一会员在不同报表中被分成不同人群。

项目没有直接合并全部会员表，而是建立主体ID、身份映射、等级版本和消费规则。每个系统保留原始编码，统一层记录映射来源、置信度、有效期和合并拆分审计；指标和人群圈选必须引用带版本的主体与等级。治理的验收标准不是“只有一张表”，而是同一会员在指定时点能够得到一致解释。`}

## 4. 发布与运行检查

- 每个关键资产有业务Owner、技术Owner、敏感等级和生命周期。
- 规则、标准、权限和血缘都进入版本管理。
- 阻断性问题不能通过修改阈值静默放过，例外必须有审批与到期日。
- 变更前自动识别字段、指标、API、模型和报表影响。
- 事故后能定位受影响对象、分区和下游，并完成可复核恢复。
- 治理指标同时包含采用率、问题闭环、误报、成本和业务影响。

## 5. 实施顺序

${list([
  `选择“${title}”中一个会造成真实后果的场景，不做全公司大而全盘点。`,
  "画清数据对象、责任人和现有控制点，确定最小可行规则。",
  "把控制嵌入开发、发布、访问或消费流程，而不是单独维护表格。",
  "用历史事故和边界样本验证控制是否真正生效。",
  "把例外、误报和维护成本纳入运营，定期删除无效规则。"
], true)}

${sourceBlock(profile, "governance")}`;
}

function userProfileArticle(profile) {
  return `# ${profile.title}

> [!abstract] 用户画像不是标签越多越好
> 画像系统的核心是身份统一、标签口径、特征时效、使用授权和效果评估。没有身份证据、标签版本和使用边界的“人群包”，只会把业务偏差放大。

## 1. 身份层和标签层分开

${table(
    ["层次", "解决什么", "关键表", "主要风险"],
    [
      ["身份", "匿名设备、登录账号、会员、支付和客服身份如何关联", "身份映射、合并审计", "错并导致隐私泄露和权益错误"],
      ["事实", "浏览、搜索、下单、支付、退款、服务等行为", "事件明细、订单与账户事实", "重复事件和跨期状态"],
      ["标签", "在明确时间窗和规则下形成的属性", "标签定义、标签快照", "规则更新后历史被覆盖"],
      ["人群", "按资格、排除、授权和频控圈选的人", "人群版本与命中明细", "口径漂移、超频和越权"],
      ["应用", "推荐、营销、客服和风控如何使用", "场景登记与实验记录", "用途超出授权或无停止条件"]
    ]
  )}

身份映射必须保留来源、置信度、生效时间和拆分记录。仅凭设备共用一个 Wi-Fi 或家庭手机号就合并账号，可能把不同用户的行为混在一起。

## 2. 标签定义卡

每个标签至少写清：

- 标签名称、编码、业务解释和不允许的使用方式；
- 对象粒度是用户、账户、设备还是家庭；
- 观察窗口、更新频率、时区和特征可得时间；
- 计算规则、数据源、排除项、空值和边界；
- 版本、Owner、质量规则和有效期；
- 敏感等级、允许场景、审批和审计。

例如“高价值会员”可能是过去 180 天净消费、复购次数和退款率的组合，也可能是当前资产等级。两个定义都能成立，但必须拥有不同编码，不能共用一个名字。

## 3. 实时特征与离线画像的一致性

${table(
    ["检查面", "离线画像", "实时特征", "一致性要求"],
    [
      ["身份", "批处理主体映射", "登录或设备映射", "同一时点的映射版本一致"],
      ["事件", "日分区去重", "事件流迟到和重复", "共同主键与去重规则"],
      ["时间窗", "历史完整窗口", "滑动窗口", "窗口单位和时区一致"],
      ["空值", "无行为与无权限不同", "未命中与系统错误不同", "显式状态区分"],
      ["刷新", "T+1或小时级", "秒级", "延迟目标按分位数记录"]
    ]
  )}

离线与实时不一致不一定是程序错误，也可能是数据可见时间不同。关键是把差异显式记录，避免模型或运营把不同窗口的结果混成一个标签。

## 4. 案例：${caseRegion(profile)}的会员经营画像

团队最初用手机号作为主身份，结果家庭共用账号和高频换号用户被错误合并。改造后建立身份映射：会员ID优先，登录账号次之，设备只在可验证条件下临时关联；每次合并保留证据和人工申诉入口。

标签层按 RFM、品类偏好、价格敏感、渠道偏好和服务风险拆分。每个标签保存快照，不覆盖历史；高敏感标签设置单独用途审批。营销人群圈选先执行资格、授权、频控和黑名单，再计算人数。上线后使用对照人群和护栏指标评估，不以短期点击率替代真实增量。

## 5. 人群圈选流程

${fence("sql", `WITH eligible_user AS (
  SELECT
    user_id,
    member_level,
    last_order_date,
    net_amount_180d,
    refund_rate_180d
  FROM dws_user_profile_snapshot
  WHERE snapshot_date = DATE '2026-11-01'
    AND consent_marketing = 1
    AND is_blacklisted = 0
    AND member_level IN ('SILVER', 'GOLD')
),
target AS (
  SELECT user_id
  FROM eligible_user
  WHERE net_amount_180d >= 2000
    AND refund_rate_180d < 0.15
    AND last_order_date >= DATE '2026-08-01'
),
excluded AS (
  SELECT user_id FROM marketing_contact_log
  WHERE contact_date >= DATE '2026-10-25'
)
SELECT
  COUNT(*) AS eligible_cnt,
  COUNT(DISTINCT target.user_id) AS target_cnt,
  COUNT(DISTINCT target.user_id) - COUNT(DISTINCT excluded.user_id) AS send_cnt
FROM target
LEFT JOIN excluded USING (user_id);`)}

真实系统还必须执行地区、年龄、频控、退订和用途权限过滤。人数差异要能按资格、标签、排除和授权四层解释。

## 6. 评估和隐私边界

- 标签命中率不等于业务价值，必须评估增量、成本、体验和长期影响。
- 禁止用敏感标签进行不公平定价、歧视性推荐或未经授权的用途。
- 身份合并错误要支持申诉、拆分和历史结果影响分析。
- 模型特征保留版本和血缘，可删除请求能够传播到画像与派生特征。
- 画像上线后监控覆盖率、漂移、偏差、误命中、撤权和下游调用。

${sourceBlock(profile, "governance")}`;
}

function careerArticle(profile) {
  const resume = profile.kind === "resume";
  const learning = profile.kind === "learning";
  const type = resume ? "简历" : learning ? "学习" : "职业判断";
  return `# ${profile.title}

> [!abstract] 把“${profile.topic}”从一个抽象要求变成可验证的动作
> ${type}类问题最怕堆口号。真正有用的是明确目标岗位或场景、当前差距、练习任务、反馈来源、证据和停止条件。

## 1. 先定义你要解决的具体问题

${table(
    ["问题", "模糊表达", "可验证改写", "证据"],
    [
      ["目标", "我想提升数据能力", "在 6 周内独立完成一次从需求到复盘的分析", "项目仓库与复盘记录"],
      ["对象", "学习大数据", "掌握窗口函数、分区和指标对账在零售订单分析中的使用", "可复跑SQL与结果解释"],
      ["差距", "基础不够", "无法说明为什么选这个Join和指标粒度", "错题、评审意见和修正版本"],
      ["行动", "多看资料", "每周完成两个真实问题并请同行盲评", "周计划与评审记录"],
      ["结果", "变强了", "能在 20 分钟内解释对象、口径、异常和取舍", "模拟面试或答辩录音"]
    ]
  )}

## 2. ${resume ? "简历不是项目清单，而是证据索引" : learning ? "学习路径不是收藏夹" : "职业能力不是职位名称"}

${resume ? `一条有效的项目描述应包含：背景、你的责任边界、关键动作、判断依据和结果。结果可以是人工步骤减少、问题定位更快、数据质量提升或决策被采用，但必须能解释口径，不能编造客户数字。

把“负责数据开发”改写成“为订单主题建立事件级事实表，处理支付、退款和跨期归属，使用总量、分组和抽样三层对账；个人负责模型评审、SQL实现和上线回滚方案”。后者没有夸大，却能让面试官追问真实细节。` : learning ? `有效的学习单元不是“看完一章”，而是完成一个小闭环：读概念 → 用自己的话解释 → 在小型数据上实现 → 制造一个失败 → 修正并复盘。每次只改变一个条件，才能知道结果为什么变化。

例如学习“${profile.topic}”时，可以选一份脱敏订单数据，完成指标定义、查询、异常样本和五分钟讲解。把资料摘要、代码、错误和修正放在同一份作品记录里，比收藏几十篇文章更有用。` : `职业判断体现在不确定情境中能否确定优先级、沟通边界和交付结果。把“沟通能力强”换成一次具体经历：你如何在需求冲突时确认目标、列出取舍、推动负责人决策，并记录最终影响。

能力提升应绑定真实任务。每季度选择一项会改变工作结果的能力，例如指标口径治理、实时链路排障、跨团队评审或业务表达，并为它设置可观察的输出，而不是只参加课程。`}

## 3. 案例：${caseRegion(profile)}的一次能力提升

一位数据工程师希望转向数据架构岗位，但简历只写“参与多个数据项目”。复盘后发现，他真正做过的工作包括：梳理支付与退款粒度、设计历史组织维度、推动下游消费方确认字段变更、在故障中完成回滚。问题不是经历少，而是没有把决策和证据写出来。

他做了三件事：

1. 选一个项目画出源系统、事实粒度、维度和下游影响；
2. 记录一次失败评审，说明原方案为什么错、如何修正；
3. 用 30 分钟向非数据同事讲清口径与风险，并收集反馈。

两周后，简历从“参与项目”变成“负责模型边界与变更影响分析”，面试问题也从泛泛的工具清单转向真实取舍。

## 4. 30 天行动设计

| 周次 | 重点 | 产出 | 检查 |
| --- | --- | --- | --- |
| 第1周 | 定义目标与差距 | 岗位要求拆解、能力差距表 | 每条差距有证据，不凭感觉 |
| 第2周 | 完成一个小任务 | 代码、文档或分析记录 | 别人能复跑 |
| 第3周 | 主动获取反馈 | 评审意见、盲评、模拟面试 | 至少修改一版 |
| 第4周 | 形成可展示证据 | 作品说明、简历要点、答辩稿 | 能解释边界和失败 |

## 5. 常见误区

- 把工具数量当能力，不说明使用场景和判断。
- 学习只看输入，没有输出和反馈。
- 简历写团队成果，却不说明个人责任边界。
- 追求“完美项目”，长期不做小闭环。
- 只准备成功案例，不准备失败、取舍和重做方案。

## 6. 自测

围绕“${profile.topic}”，请用 90 秒回答：你要解决谁的什么问题；为什么现在做；你做了什么判断；哪项证据证明结果；如果失败，你怎么发现和修正。回答中如果只有形容词，没有对象、动作和证据，就继续缩小目标。

${sourceBlock(profile, "governance")}`;
}

function industryArticle(profile) {
  const context = profile.context;
  const metric = context.metricDefs?.[profile.seed % context.metricDefs.length] || ["核心业务量", "按业务对象计数", "volume"];
  return `# ${profile.title}

> [!abstract] 先看业务如何创造价值，再看数据如何记录
> ${profile.topic}不能只背名词。要说明参与者、业务流程、收入与成本、风险约束、系统记录和数据指标之间的关系。

## 1. 业务链条

${context.scene}。主要参与者包括${context.participants.join("、")}，流程通常经过${context.stages.join(" → ")}。

${table(
    ["环节", "业务动作", "产生什么记录", "关键问题"],
    context.stages.slice(0, 6).map((stage, index) => [
      stage,
      `${context.participants[index % context.participants.length]}负责推进该环节`,
      `${context.entities[index % context.entities.length][0]}相关事件或状态`,
      index === 0 ? "对象是否唯一" : index < 3 ? "状态和时间是否连续" : "结果能否回到原始事件"
    ])
  )}

## 2. 核心指标

**${metric[0]}：**\`${metric[1]}\`

这个公式只是起点。实际分析还要明确对象范围、时间窗、分子分母、排除项和业务动作。以“${profile.topic}”为例，至少要同时看规模、结构、时效、质量和风险，而不是单看一个总量。

${table(
    ["观察面", "可看指标", "业务用途", "防止误读"],
    [
      ["规模", context.metricDefs.slice(0, 2).map(([name]) => name).join("、"), "判断需求和资源", "同时看对象数和样本"],
      ["结构", context.metricDefs.slice(2, 4).map(([name]) => name).join("、"), "发现人群或业务组合变化", "不要用总体掩盖分层"],
      ["效率", "周期、转化率、利用率", "定位流程瓶颈", "区分业务时间和处理时间"],
      ["质量", context.controls.slice(0, 2).join("、"), "判断结果是否可用", "规则通过不等于业务正确"],
      ["风险", context.risks.slice(0, 2).join("、"), "设置边界和审批", "风险指标不能只看平均值"]
    ]
  )}

## 3. 一个工作场景

某${context.label}企业的 ${caseRegion(profile)} 发现“${profile.topic}”相关结果出现波动。团队先确认业务对象和时间窗，再检查${context.controls.slice(0, 3).join("、")}。进一步按${context.dims.slice(0, 4).join("、")}拆分后，发现变化并非来自单一总量，而是部分对象状态迁移和统计范围变化共同造成。

处理时没有直接修改指标阈值，而是先冻结发布、抽取正常与异常对象回查原始单据，再把变化拆成业务新增、状态变化、跨期、重复和口径调整。恢复后同时观察主指标、样本量和风险护栏，避免改善一个数字却恶化另一个环节。

## 4. 系统与数据陷阱

${table(
    ["系统", "记录什么", "常见问题"],
    (context.systems || []).slice(0, 6).map((system, index) => [
      system,
      index < 3 ? "业务事件、状态和操作记录" : "主数据、结果或对账信息",
      context.risks[index % context.risks.length]
    ])
  )}

## 5. 如何继续学习“${profile.topic}”

1. 画一张业务流程图，标出参与者、对象、状态变更和异常出口。
2. 选一组指标写出公式、时间、范围和样本量。
3. 找三个真实业务问题，检查需要哪些系统字段才能回答。
4. 追踪一条记录从创建到结束，记录每个系统的时间和状态差异。
5. 用一个小案例说明“数据正常”为什么仍可能“业务结论错误”。

${sourceBlock(profile, "governance")}`;
}

function analyticsArticle(profile) {
  const topic = profile.topic;
  const funnel = /漏斗|路径|转化|留存|复购|活跃|流失/i.test(topic);
  return `# ${profile.title}

> [!abstract] 分析结论要能落到一个可干预环节
> ${topic}不是把指标放进图表，而是定义比较对象、时间窗、基准和行动阈值，并检验变化是否真的由某个环节造成。

## 1. 分析设计

${table(
    ["设计项", "本主题要写清", "常见错误"],
    [
      ["问题", "要支持哪个业务决策", "只说“看一下情况”"],
      ["对象", "用户、会话、订单、商品或门店", "不同粒度混算"],
      ["时间", "观察窗、比较窗、归因窗", "跨期和节假日未处理"],
      ["基准", "历史、对照组、同层或预算", "只看目标值不看基线"],
      ["分组", "渠道、人群、品类、地区", "为找结论反复切分"],
      ["动作", "谁在何时调整什么", "结论没有负责人"]
    ]
  )}

## 2. ${funnel ? "漏斗和分层要使用同一对象" : "指标拆解要遵守计算关系"}

${funnel ? `漏斗每一步必须说明“同一批对象”还是“各步独立对象”。如果访问用户、下单用户和支付用户分别去重，可以直接算步骤人数；如果要看路径转化，则要保留会话或用户路径，并处理跨天、重复进入和归因窗口。` : `如果指标由比率构成，分母变化和分子变化要分开讲。分层贡献可用“总体变化 = 各层占比变化 × 各层水平变化”解释，但业务上仍要回到具体动作与样本。`}

## 3. 案例：${caseRegion(profile)}的一次复盘

${funnel ? `业务发现“${topic}”下降，但总体只降低 12%。团队先按渠道、新老用户、终端和时间段拆解，发现老客支付转化稳定，下降集中在新客的详情页到加购环节。

随后检查埋点版本、页面加载和活动配置，确认新版详情页把优惠信息放在首屏以下。团队用同周期对照流量验证，并关注客单价、退款率和客服咨询作为护栏。调整后不是立刻宣布“提升”，而是先观察完整结算周期，区分实验效果和季节性。` : `业务体量上升，但“${topic}”相关效率指标反而变差。团队先核对指标公式和数据质量，再按商品结构、渠道和用户层级做贡献拆解。结果显示新增低毛利业务占比上升，同时退款处理周期变长。

分析没有停留在“结构变化”，而是继续量化如果结构不变、流程不变和两者同时改善，指标分别会怎样变化。最终形成三条行动：优化低毛利业务的履约策略、缩短退款处理节点、对高价值人群保持独立观察。`}

## 4. 统计与因果边界

- 描述性变化不能直接称为因果。
- 有实验时检查分流、样本、曝光和污染。
- 无实验时使用可比基线、安慰剂或稳健性检验，并明确假设。
- 多重比较和反复切片会增加偶然发现，重要结论需要复现。
- 结果同时报告效应大小、样本量、区间或误差，不只报显著性。

${funnel ? fence("sql", `WITH session_funnel AS (
  SELECT
    session_id,
    MAX(CASE WHEN event_name = 'view' THEN 1 ELSE 0 END) AS viewed,
    MAX(CASE WHEN event_name = 'add_cart' THEN 1 ELSE 0 END) AS added_cart,
    MAX(CASE WHEN event_name = 'pay' THEN 1 ELSE 0 END) AS paid,
    MIN(event_time) AS first_seen_at
  FROM dwd_user_event
  WHERE dt BETWEEN DATE '2026-11-01' AND DATE '2026-11-07'
  GROUP BY session_id
)
SELECT
  COUNT(*) AS sessions,
  SUM(viewed) AS view_sessions,
  SUM(added_cart) AS cart_sessions,
  SUM(paid) AS paid_sessions,
  SUM(added_cart) * 1.0 / NULLIF(SUM(viewed), 0) AS view_to_cart,
  SUM(paid) * 1.0 / NULLIF(SUM(added_cart), 0) AS cart_to_pay
FROM session_funnel;`) : ""}

## 5. 结论模板

> 在【时间窗】内，【对象/分组】的【主指标】从【基线】变化到【结果】。排除数据质量、口径和外部因素后，最可能的可干预环节是【环节】。建议【责任人】在【时间】前执行【动作】，并用【主指标】、【护栏指标】和【样本】验证。若出现【停止条件】，则暂停并复盘。

${sourceBlock(profile, "governance")}`;
}

function architectureArticle(profile) {
  const topic = profile.topic;
  return `# ${profile.title}

> [!abstract] 架构方案的价值在于约束取舍
> ${topic}要回答的是业务目标、数据规模、实时性、一致性、成本、安全和组织能力之间如何取舍。只画组件图，不写约束和失败路径，无法评审。

## 1. 先写非目标

一个可评审的“${topic}”方案，先要说明这一次不解决什么：不追求所有业务实时，不把全部历史迁到新引擎，不统一所有团队接口，也不以某个产品名替代目标。非目标能防止项目在实施中无限扩张。

${table(
    ["约束", "必须量化", "对方案的影响", "评审证据"],
    [
      ["数据规模", "日增、存量、峰值和增长", "存储、分区和计算选型", "容量基线"],
      ["时效", "批、分钟或秒级，按分位数", "是否引入流处理和缓存", "端到端延迟测试"],
      ["一致性", "可重复读、最终一致或严格事务", "幂等、补偿和对账", "故障回放"],
      ["可用性", "SLO、RTO、RPO", "副本、跨区和恢复", "演练记录"],
      ["成本", "计算、存储、网络、人力", "物化、压缩和保留策略", "单位数据成本"],
      ["安全", "分类分级、租户、地域和审计", "隔离、加密和权限", "红队与审计"]
    ]
  )}

## 2. 方案要用“数据流 + 控制流”表达

${table(
    ["层", "输入", "处理", "输出", "关键控制"],
    [
      ["接入", "业务库、日志、事件、第三方", "全量快照、CDC、流式事件", "原始层与事件时间", "Schema、顺序、重复和延迟"],
      ["处理", "原始与标准层", "清洗、关联、聚合、特征", "主题事实与指标", "幂等、质量门禁和版本"],
      ["存储", "事实、维度和中间结果", "湖、仓、OLAP或搜索", "服务数据集", "生命周期、分区和权限"],
      ["服务", "指标与明细", "API、查询层、缓存", "业务应用", "SLO、限流和审计"],
      ["运维", "日志、指标、血缘、成本", "监控、告警、回滚", "事故与优化记录", "责任、演练和复盘"]
    ]
  )}

## 3. 案例：${caseRegion(profile)}的架构评审

团队准备为“${topic}”引入新平台，初版方案列了十几个组件，却没有回答为什么现有链路无法满足目标。评审后把问题重写为：订单数据必须在下单后 5 分钟内可查，日终财务对账要求可重放，查询只开放给授权租户，峰值成本不能超过预算。

在约束明确后，方案被拆成三条路径：实时链路只服务可容忍最终一致的运营查询；财务事实保留批处理可重放版本；租户权限在服务层强制执行。这样既没有为了一个看板复制全量数据，也能在流任务故障时退回到批结果。团队还定义了降级状态：实时数据未就绪时明确返回截止时间，而不是悄悄展示旧数据。

## 4. 失败路径先于成功路径

- 上游 Schema 变化如何发现、阻断和兼容？
- 流任务延迟或中断时，用户看到什么状态？
- 下游消费者是否能在新旧版本间切换？
- 分区被误覆盖后，多久、从哪个版本恢复？
- 跨租户权限或密钥泄露如何阻断和审计？
- 成本在峰值翻倍时，哪些任务可以降级？

## 5. 评审结论

好的架构评审不会只得出“同意建设”。应明确：保留什么、替换什么、分几个阶段、每阶段验证什么、什么条件下停止。对于“${topic}”，必须用测试和运行证据证明方案，而不是用组件数量证明先进。

${sourceBlock(profile, "modeling")}`;
}

function projectArticle(profile) {
  return `# ${profile.title}

> [!abstract] 项目交付以证据结束，不以“系统上线”结束
> ${profile.topic}要先写清范围、对象、成功标准和停止条件，再安排数据、技术、质量、安全和运营活动。

## 1. 项目边界

${table(
    ["项目要素", "本主题需要明确", "验收证据"],
    [
      ["业务目标", "支持哪个决策或流程", "决策记录与使用日志"],
      ["范围", "包含哪些系统、对象和时间", "范围图与非目标"],
      ["成功标准", "主指标、护栏、时效和采用", "基线与上线后结果"],
      ["质量", "关键规则、样本与阻断条件", "门禁结果"],
      ["安全", "权限、敏感数据与审计", "权限测试和审计记录"],
      ["回滚", "触发条件、时间目标与责任人", "演练报告"]
    ]
  )}

## 2. 里程碑

| 阶段 | 核心问题 | 交付 | 未通过 |
| --- | --- | --- | --- |
|  discovery | 问题是否真实、值不值得做 | 问题陈述与基线 | 返回需求方 |
| 设计 | 对象、链路、口径和边界 | 模型、接口与质量方案 | 不进入开发 |
| 实施 | 是否可重复、可观测、可恢复 | 代码、血缘、监控 | 修复后重测 |
| 验收 | 结果能否回到原始记录 | 对账、抽样与回滚演练 | 缩减范围 |
| 运营 | 谁在使用、效果和副作用 | 采用记录与复盘 | 停止或迭代 |

## 3. 案例：${caseRegion(profile)}的“${profile.topic}”

项目中期发现需求不断增加，但主链路质量未达标。团队暂停新功能，把范围冻结为一组核心对象和两个业务动作，先完成总量、分组和抽样对账。之后用影子发布观察一周，确认延迟和结果稳定，再开放第二批用户。

复盘时没有把进度压力归为个人问题，而是发现项目缺少变更评审和停止条件。后续把“新增需求必须说明替代哪个现有需求”写入流程，并为每个里程碑设置可退回的验收门。

## 4. 风险清单

- 口径争论拖到开发后期才暴露；
- 只验证总量，不验证对象和明细；
- 发布没有灰度和回滚，出事后只能停机；
- 数据质量问题被当作开发缺陷，不追溯源系统；
- 使用率低却继续扩展功能；
- 项目成功标准只写“按时上线”。

## 5. 复盘模板

用四页完成复盘：目标与基线、实际结果与差异、原因与证据、下一阶段动作。差异必须区分数据问题、方案偏差、执行问题、外部变化和测量错误。每个改进项写负责人、截止时间和验证方式。

${sourceBlock(profile, "governance")}`;
}

function aiGeneralArticle(profile) {
  return `# ${profile.title}

> [!abstract] AI 项目的核心问题是任务、数据和评估
> ${profile.topic}应先明确输入、输出、使用者和错误成本，再讨论模型、参数和工程平台。

## 1. 任务定义

${table(
    ["要素", "需要回答", "失败信号"],
    [
      ["使用者", "谁在什么流程使用输出", "没有明确负责人"],
      ["输入", "文本、图像、表格还是多源数据", "输入边界和权限不清"],
      ["输出", "分类、生成、检索、决策建议", "输出无法被验证"],
      ["错误成本", "误报、漏报、幻觉或延迟的后果", "所有错误被等同处理"],
      ["基线", "规则、人工或简单模型表现", "没有基线就追求复杂模型"],
      ["验收", "质量、安全、延迟和成本", "只看演示截图"]
    ]
  )}

## 2. 数据与评估

数据要区分训练、验证、测试和线上反馈；评估要按业务切片查看，不能只报一个平均分。对于“${profile.topic}”，建议至少建立：

- 正常、边界、冲突和无答案样本；
- 按用户、场景、语言和风险等级的切分；
- 人工标注规范与争议处理；
- 模型版本、提示词、数据和评估集的关联；
- 失败样本的复现、修复和回归。

## 3. 工作场景

某内容平台的 ${caseRegion(profile)} 先从一个低风险、可人工复核的任务开始，而不是直接自动化全部流程。团队用规则作为基线，逐步加入模型，并记录模型输出被采纳、修改和拒绝的原因。每次升级都在固定评测集与真实灰度上比较，不只看离线分数。

## 4. 工程与治理

上线需要模型服务、提示词或配置版本、数据权限、缓存、超时、降级、日志、成本和人工接管。高风险场景要有人审、拒答和审计；训练或反馈数据要满足授权、最小必要和可删除要求。

## 5. 完成标准

- 任务和使用边界清楚；
- 有可复现基线与人评标准；
- 失败样本能定位到数据、模型、提示或工程；
- 新版本可灰度、可监控、可回滚；
- 不把平均分和演示效果当作生产结论。

${sourceBlock(profile, "rag")}`;
}

function genericEngineeringArticle(profile) {
  return `# ${profile.title}

> [!abstract] 用约束、对象和证据解释“${profile.topic}”
> 工程主题如果只停留在术语和工具名，就很难迁移。更可靠的方式是先说明它解决什么约束，再说明输入输出、失败方式和验证证据。

## 1. 问题与边界

${table(
    ["维度", "本主题要明确", "可用于验收的证据"],
    [
      ["目标", "降低延迟、提高质量、统一语义或减少人工", "基线与目标值"],
      ["对象", "数据、任务、服务、模型或组织流程", "对象清单与主键"],
      ["输入输出", "从哪里来、经过什么处理、给谁用", "接口、数据契约与样本"],
      ["失败", "丢失、重复、延迟、越权或结果错误", "故障注入与回放"],
      ["成本", "计算、存储、网络、维护和沟通", "单位成本与容量"],
      ["责任", "谁定义、谁开发、谁审批、谁运营", "责任矩阵"]
    ]
  )}

## 2. 机制解释

“${profile.topic}”可以拆成一条控制链：输入被校验后进入处理，处理过程保留版本和状态，结果在发布前经过质量与权限检查，上线后通过监控和反馈形成闭环。任何一环没有证据，系统就只能依赖个人经验运行。

## 3. 案例：${caseRegion(profile)}

团队最初把问题归因于工具性能，扩容后症状短暂缓解又再次出现。复盘后发现输入数据重复、状态语义混乱且缺少失败回放。修复从对象、时间和状态开始，再调整处理逻辑与容量。上线时用正常、重复、迟到、异常和恢复五类样本验证，形成可重复的验收资产。

## 4. 实施步骤

${list([
  "写清目标、非目标和主要使用者。",
  "列出对象、输入输出、状态和失败后果。",
  "建立最小基线，不先引入复杂方案。",
  "把质量、权限、幂等、监控和回滚纳入设计。",
  "用边界样本和故障回放验证，不只演示成功路径。",
  "上线后记录采用情况、成本和下一轮改进。"
], true)}

## 5. 完成标准

当另一位工程师能根据文档复跑结果、解释失败并完成回滚；当业务方能说明结果对应哪个对象和版本；当系统能阻止已知高危错误，才算真正落地。

${sourceBlock(profile, "governance")}`;
}

function buildTitleNativeArticle(profile) {
  const topic = profile.topic;
  if (/企业级建模方法论|企业级数据建模|企业数据建模/.test(topic)) {
    return enterpriseModelingArticle(profile);
  }
  if (profile.specialty?.key === "finance-metric" || FINANCE_SPECS.some((item) => item.match.test(topic))) {
    return financeMetricArticle(profile);
  }
  if (profile.specialty?.key === "manufacturing-metric" || /设备综合效率|OEE/.test(topic)) {
    return manufacturingMetricArticle(profile);
  }
  if (/Kafka|消息积压|消费积压|消费者组|消费组|Rebalance|ISR|offset|Lag/i.test(topic)) {
    return kafkaArticle(profile);
  }
  if (profile.specialty?.key === "spark" || /Spark|RDD|DataFrame|Shuffle|数据倾斜|Executor|Driver|Partitioner|DAGScheduler|TaskScheduler|reduceByKey|groupByKey|cache|persist|checkpoint|MLlib/i.test(topic)) {
    return sparkArticle(profile);
  }
  if (profile.specialty?.key === "rag" || /RAG|向量数据库|Embedding|语义搜索|重排|混合检索/.test(topic)) {
    return ragArticle(profile);
  }
  if (profile.specialty?.key === "agent" || /Agent|智能体|控制平面|工具调用/.test(topic)) {
    return agentArticle(profile);
  }
  if (profile.specialty?.key === "text-to-sql" || /Text[\s-]*to[\s-]*SQL|NL2SQL|自然语言.*SQL/.test(topic)) {
    return textToSqlArticle(profile);
  }
  if (profile.specialty?.key === "data-service" || /数据服务|数据API|RESTful|GraphQL|GraphQL数据服务/.test(topic)) {
    return dataServiceArticle(profile);
  }
  if (profile.specialty?.key === "sql" || /SQL|窗口函数|TopN|连续活跃|行列转换/.test(topic)) {
    return sqlArticle(profile);
  }
  if (/用户画像|画像数据开发|标签体系|OneID|RFM/.test(topic)) {
    return userProfileArticle(profile);
  }
  if (profile.kind === "career" || profile.kind === "resume" || profile.kind === "learning") {
    return careerArticle(profile);
  }
  if (["data-quality", "lineage", "master-data", "security", "ai-governance"].includes(profile.specialty?.key)) {
    return governanceArticle(profile);
  }
  if (/血缘|元数据|数据质量|数据标准|主数据|权限|隐私|合规|分类分级|数据合约/.test(topic)) {
    return governanceArticle(profile);
  }
  if (/漏斗分析|用户路径|用户画像|留存|复购|转化率|活动效果|渠道分析|用户行为|经营看板|分析思维/.test(topic)) {
    return analyticsArticle(profile);
  }
  if (/架构|数据仓库|数据湖|湖仓|数据中台|云原生|Kubernetes|微服务|数据网格|Data Mesh|Data Fabric|数据建模|维度建模/.test(topic)) {
    return architectureArticle(profile);
  }
  if (profile.kind === "project" || /项目|实战案例/.test(topic)) {
    return projectArticle(profile);
  }
  if (profile.kind === "ai" || /机器学习|深度学习|大模型|LLM|Prompt|模型评估|微调|多模态/.test(topic)) {
    return aiGeneralArticle(profile);
  }
  if (profile.kind === "industry") {
    return industryArticle(profile);
  }
  if (profile.kind === "analytics") {
    return analyticsArticle(profile);
  }
  if (profile.kind === "engineering") {
    return genericEngineeringArticle(profile);
  }
  return genericEngineeringArticle(profile);
}

function buildNativeSpecializedArticle(profile) {
  const topic = profile.topic;
  const specialty = profile.specialty?.key;

  if (/企业级建模方法论|企业级数据建模|企业数据建模/.test(topic)) {
    return enterpriseModelingArticle(profile);
  }
  if (specialty === "finance-metric" || FINANCE_SPECS.some((item) => item.match.test(topic))) {
    return financeMetricArticle(profile);
  }
  if (specialty === "manufacturing-metric" || /设备综合效率|OEE/.test(topic)) {
    return manufacturingMetricArticle(profile);
  }

  // Technical topics take priority even when they sit under a career or learning section.
  if (/Kafka|消息积压|消费积压|消费者组|消费组|Rebalance|ISR|offset|Lag/i.test(topic)) {
    return kafkaArticle(profile);
  }
  if (specialty === "spark" || /Spark|RDD|DataFrame|Shuffle|数据倾斜|Executor|Driver|Partitioner|DAGScheduler|TaskScheduler|reduceByKey|groupByKey|cache|persist|checkpoint|MLlib/i.test(topic)) {
    return sparkArticle(profile);
  }
  if (/RAG|检索增强|向量数据库|Embedding|语义搜索|混合检索|重排|向量索引|向量数据生命周期|知识库治理/i.test(topic)) {
    return ragArticle(profile);
  }
  if (/AI.?Agent|Agent架构|Agent开发|Agent控制|Agent安全|Agent可观测|智能体.*(?:开发|架构|控制|安全)/.test(topic)) {
    return agentArticle(profile);
  }
  if (/Text[\s-]*to[\s-]*SQL|NL2SQL|自然语言.*SQL/.test(topic)) {
    return textToSqlArticle(profile);
  }
  if (/数据服务(?:设计|开发|治理|API)|数据API|RESTful数据服务|GraphQL数据服务/.test(topic)) {
    return dataServiceArticle(profile);
  }
  if (/SQL窗口函数|窗口函数|连续活跃|连续登录|行列转换|TopN|同比环比.*SQL|SQL.*(?:优化|排查|模板)/i.test(topic)) {
    return sqlArticle(profile);
  }
  if (/用户画像(?:数据开发|工程|标签)|画像数据开发|标签体系.*开发|OneID.*开发|RFM.*开发/.test(topic)) {
    return userProfileArticle(profile);
  }

  return null;
}

module.exports = {
  buildTitleNativeArticle,
  buildNativeSpecializedArticle
};
