<div class="lab-paywall" role="group" aria-label="会员阅读提示">
<div class="lab-paywall-symbol" aria-hidden="true"><span class="lab-paywall-lock"></span></div>
<span class="lab-paywall-tier">pro · 会员内容</span>
<p class="lab-paywall-document">01-IPO承销业务详解</p>
<h2 class="lab-paywall-title">这篇内容需要会员权益</h2>
<p class="lab-paywall-copy">有效会员可完整阅读这篇文章。你也可以继续浏览知识库中的免费内容。</p>
<div class="lab-paywall-actions">
<a class="lab-paywall-primary" href="https://pro.ss-data.cc/membership?returnTo=%2Fknowledge%2F%25E3%2580%2590%25E5%2590%2584%25E8%25A1%258C%25E4%25B8%259A%25E7%259A%2584%25E5%259F%25BA%25E7%25A1%2580%25E7%259F%25A5%25E8%25AF%2586%25E3%2580%2591%2F01-%25E9%2587%2591%25E8%259E%258D%25E8%25A1%258C%25E4%25B8%259A%2F03-%25E6%258A%2595%25E8%25B5%2584%25E9%2593%25B6%25E8%25A1%258C%25E6%259C%258D%25E5%258A%25A1%2F01-IPO%25E6%2589%25BF%25E9%2594%2580%25E4%25B8%259A%25E5%258A%25A1%25E8%25AF%25A6%25E8%25A7%25A3">查看会员权益</a>
<a class="lab-paywall-signin" href="https://pro.ss-data.cc/auth/signin?callbackUrl=%2Fknowledge%2F%25E3%2580%2590%25E5%2590%2584%25E8%25A1%258C%25E4%25B8%259A%25E7%259A%2584%25E5%259F%25BA%25E7%25A1%2580%25E7%259F%25A5%25E8%25AF%2586%25E3%2580%2591%2F01-%25E9%2587%2591%25E8%259E%258D%25E8%25A1%258C%25E4%25B8%259A%2F03-%25E6%258A%2595%25E8%25B5%2584%25E9%2593%25B6%25E8%25A1%258C%25E6%259C%258D%25E5%258A%25A1%2F01-IPO%25E6%2589%25BF%25E9%2594%2580%25E4%25B8%259A%25E5%258A%25A1%25E8%25AF%25A6%25E8%25A7%25A3">登录后继续</a>
<a class="lab-paywall-secondary internal-link" data-href="Welcome" href="https://pro.ss-data.cc/knowledge/Welcome">继续阅读免费内容</a>
</div>
</div>
