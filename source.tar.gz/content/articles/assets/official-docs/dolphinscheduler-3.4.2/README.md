<div class="lab-paywall" role="group" aria-label="会员阅读提示">
<div class="lab-paywall-symbol" aria-hidden="true"><span class="lab-paywall-lock"></span></div>
<span class="lab-paywall-tier">pro · 会员内容</span>
<p class="lab-paywall-document">README</p>
<h2 class="lab-paywall-title">这篇内容需要会员权益</h2>
<p class="lab-paywall-copy">有效会员可完整阅读这篇文章。你也可以继续浏览知识库中的免费内容。</p>
<div class="lab-paywall-actions">
<a class="lab-paywall-primary" href="https://pro.ss-data.cc/membership?returnTo=%2Fknowledge%2Fassets%2Fofficial-docs%2Fdolphinscheduler-3.4.2%2FREADME">查看会员权益</a>
<a class="lab-paywall-signin" href="https://pro.ss-data.cc/auth/signin?callbackUrl=%2Fknowledge%2Fassets%2Fofficial-docs%2Fdolphinscheduler-3.4.2%2FREADME">登录后继续</a>
<a class="lab-paywall-secondary internal-link" data-href="Welcome" href="https://pro.ss-data.cc/knowledge/Welcome">继续阅读免费内容</a>
</div>
</div>
