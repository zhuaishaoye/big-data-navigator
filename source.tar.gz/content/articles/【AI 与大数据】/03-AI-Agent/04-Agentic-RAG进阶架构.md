<div class="lab-paywall" role="group" aria-label="会员阅读提示">
<div class="lab-paywall-symbol" aria-hidden="true"><span class="lab-paywall-lock"></span></div>
<span class="lab-paywall-tier">pro · 会员内容</span>
<p class="lab-paywall-document">04-Agentic-RAG进阶架构</p>
<h2 class="lab-paywall-title">这篇内容需要会员权益</h2>
<p class="lab-paywall-copy">有效会员可完整阅读这篇文章。你也可以继续浏览知识库中的免费内容。</p>
<div class="lab-paywall-actions">
<a class="lab-paywall-primary" href="https://pro.ss-data.cc/membership?returnTo=%2Fknowledge%2F%25E3%2580%2590AI%2520%25E4%25B8%258E%25E5%25A4%25A7%25E6%2595%25B0%25E6%258D%25AE%25E3%2580%2591%2F03-AI-Agent%2F04-Agentic-RAG%25E8%25BF%259B%25E9%2598%25B6%25E6%259E%25B6%25E6%259E%2584">查看会员权益</a>
<a class="lab-paywall-signin" href="https://pro.ss-data.cc/auth/signin?callbackUrl=%2Fknowledge%2F%25E3%2580%2590AI%2520%25E4%25B8%258E%25E5%25A4%25A7%25E6%2595%25B0%25E6%258D%25AE%25E3%2580%2591%2F03-AI-Agent%2F04-Agentic-RAG%25E8%25BF%259B%25E9%2598%25B6%25E6%259E%25B6%25E6%259E%2584">登录后继续</a>
<a class="lab-paywall-secondary internal-link" data-href="Welcome" href="https://pro.ss-data.cc/knowledge/Welcome">继续阅读免费内容</a>
</div>
</div>
