const { execFileSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

const siteRoot = __dirname;
const sourceRoot = path.resolve(__dirname, "..");

execFileSync("npm", ["run", "build:pages"], {
  cwd: sourceRoot,
  env: process.env,
  stdio: "inherit"
});

const sourceDist = path.join(sourceRoot, "dist");
const targetDist = path.join(siteRoot, "dist");
fs.rmSync(targetDist, { recursive: true, force: true });
fs.cpSync(sourceDist, targetDist, { recursive: true });
